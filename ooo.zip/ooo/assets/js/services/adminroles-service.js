/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("adminRolesService",['$q', '$http','ajaxService', 'stateService', 'utilityService','urlService', 'loginService',function($q,$http, ajaxService, stateService, utilityService,urlService, loginService){
		return	{
			 getAllOrdersDetails:function(request){
		    	  var url = urlService.getAllOrders();
		          return ajaxService.doGet(url, request);
		      },
		      orderStatusChange:function(request){
		    	  var url = urlService.orderStatusChange();
		    	  return ajaxService.doPost(url,{},request);
		      },
		      addMoneyToWallet:function(request){
		    	  var url = urlService.addMoneyToUser();
		    	  return ajaxService.doPost(url, {},request);
		      },
		      getUsersReq:function(request){
		    	  var url = urlService.getAllUsersUrl();
		    	  return ajaxService.doGet(url,request);
		      },
		      getBuyerDemands: function(request){
		    	  var url = urlService.getUserDemands();
		    	  return ajaxService.doGet(url,request);
		      }
		};
	}]);
    
	return services;
});