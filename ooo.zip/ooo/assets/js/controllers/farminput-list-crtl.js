'use strict';

define([ 'angular', 'controllers-module', 'underscore' ], function(angular,
		controllers, underscore) {

	// Add Attribute Controller    non edit- A,I    edit-D,R
	controllers.controller("farmInputCtrl", [
			'$scope',
			'$rootScope',
			'$state',
			'farmInputService',
			'stateService',
			'utilityService',
			'$stateParams',
			'$timeout',
			'$sessionStorage',
			function($scope, $rootScope, $state, farmInputService,
					stateService, utilityService, $stateParams,$timeout,$sessionStorage) {
				var vm = this;
				vm.sortType = 'productName';
				vm.sortReverse = false;
				vm.farmType = $sessionStorage.userInfo.farmType ||1;
				$sessionStorage.userInfo ? $sessionStorage.userInfo.farmType = vm.farmType : $state.go('login'); 
				init();
			//	vm.deleteFarmInput = deleteFarmInput;
				//vm.updateFarmInput = updateFarmInput;
				vm.createFarmInputHandler = createFarmInputHandler;
				
		        
				vm.farmTypeChanged = function() {
					$sessionStorage.userInfo ? $sessionStorage.userInfo.farmType = vm.farmType : 2;
		        	if(vm.farmType == 2) {
		        		getEquipments();
		        	} else {
		        		getfarmInputs();
		        	}
		        	
		        }

				$scope.gridOptions = {
						enableColumnMenu: true,
						enableFiltering: true,
			            paginationPageSizes: [10, 50, 100],
			            paginationPageSize: 10,
			            rowHeight: 40,
						rowEditWaitInterval: -1,
					    columnDefs: [
					      { field:"productName", displayName:'origo.orderPlacement.ProductTitle',  headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableHiding: false, enableSorting: true,enableFiltering:true,
					    	      cellTooltip:
					              function (row, col) {
					                 return  row.entity.productName!=null?row.entity.productName:"";
					               }
					      },
					      { field: 'category',displayName:'origo.demand.category', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableHiding: false, enableSorting: true,enableFiltering:true,
					            	cellTooltip:
				                      function (row, col) {
				                       return  row.entity.category!=null?row.entity.category:"";
				                      }
					      },
					      /*{ field: 'productDesc' ,displayName:'origo.farminput.description', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true,enableHiding: false, enableSorting: true,enableFiltering:false,
				                    	  cellTooltip:
				                    		  function (row, col) {
				                               return  row.entity.productDesc!=null?row.entity.productDesc:"";
				                           }
				          },*/
					      { field: 'unitPrice',displayName:'origo.cart.price', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableHiding: false,type:'number',enableSorting: true,enableFiltering:false},
					      { field: 'status' ,displayName:'origo.wallet.status', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true,enableHiding: false, enableSorting: true,enableFiltering:true},
					      { field: 'stockQuantity',displayName:'origo.submitdemand.quantity', headerCellFilter:'translate', enableCellEdit: false,type:'number',enableColumnMenu: true, enableHiding: false,enableSorting: true,enableFiltering:true },
					      { field: 'storeLocatorDTO.storeName' ,displayName:'origo.farminput.availableAt', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true,enableHiding: false, enableSorting: true,enableFiltering:true,
					    	  cellTooltip:
	                    		  function (row, col) {
	                               return  row.entity.storeLocatorDTO.storeName!=null?row.entity.storeLocatorDTO.storeName:"";
	                           }  
					      },
					      { field: 'actions', displayName: 'origo.demand.actions', headerCellFilter:'translate',enableCellEdit: false, enableColumnMenu: true , enableSorting: true, enableHiding: false,enableFiltering:false,
					    	  cellTemplate: '<span  title="Edit" type="button" class="edit-input-item inline"  data-ng-click="grid.appScope.updateFarmInput(row);$event.stopPropagation();">Edit</span>'
					      },
					      
					   ]
				  };
				
				function init() {
					vm.farmType== 1?getfarmInputs():getEquipments();
					changeCurrentSelector();
				}
				function changeCurrentSelector(){
			    	if($rootScope.currentSelector==undefined){
			    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
			    	}else{
			    		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
			    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
			    	}
			    	$rootScope.currentSelector = $rootScope.toState.name;
			    }
				 $scope.updateFarmInput=function(row) {
					farmInputService.productId = row.entity.productId;
					farmInputService.action = "update";
					$sessionStorage["farmInputAction"] = "update";
					$sessionStorage["farmInputProductId"] = row.entity.productId;
					//$state.go('farminput');
					$state.go('admin',{"id":"farminput"},{reload:true});
				}

				function getfarmInputs() {
					$rootScope.dataLoading = true;
					$rootScope.dataStillLoading = true;
					getFarmInputRequest().then(getFarmInputResponse);
				}
				function getFarmInputRequest() {
					var request= angular.extend({},{
						catagoryType:"Farm Input"
					})
					return farmInputService.getFarmInputRequest(request);
					$rootScope.dataLoading = true;
				}
				
				function getEquipments() {
					$rootScope.dataLoading = true;
					$rootScope.dataStillLoading = true;
					getEquipmentsRequest().then(getFarmInputResponse);
				}
				function getEquipmentsRequest() {
					var request= angular.extend({},{
						catagoryType:"Equipment"
					})
					return farmInputService.getFarmInputRequest(request);
					$rootScope.dataLoading = true;
				}
												
				function getFarmInputResponse(response) {
					var data1 = response.body;
					if (data1.applicationStatusCode == 1047) {
						 vm.data = data1.data;
						 for(var item=0;item<vm.data.length;item++){
							 vm.data.actions;
						 }
						 $scope.gridOptions.data = vm.data;
						 $timeout(function() {
				   		 	$(window).resize();
				   		 	$rootScope.dataLoading = false;
				   		 	$rootScope.dataStillLoading = false;
						 }, 600);
					}
				}

				function deleteFarmInputResponse(response) {
					var item = response.body;
					if (item.applicationStatusCode == 1042) {
						getfarmInputs();
					}
				}
				 $scope.deleteFarmInput=function(row) {
					    var index = $scope.gridOptions.data.indexOf(row.entity);
					    $scope.gridOptions.data.splice(index, 1);
					var delData = {
						productId : row.entity.productId
					}
					deleteFarmInputRequest(delData).then(
							deleteFarmInputResponse);
				}
				function deleteFarmInputRequest(request) {
					return farmInputService.deleteFarmInputRequest(request);
				}

				function createFarmInputHandler() {
					farmInputService.action = "create";
					$sessionStorage["farmInputAction"] = "create";
					//$state.go('farminput');
					$state.go('admin',{"id":"farminput"},{reload:true});
				}

			} ]);
});