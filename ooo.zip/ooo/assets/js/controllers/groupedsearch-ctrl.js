/**
 * advance search which will search based on the filter and displays all the product 
 */
'use strict';

define(['angular',
    'controllers-module',
    'underscore'
], function(angular, controllers, underscore) {
    controllers.controller("GroupedSearchCtrl", ['$scope', '$rootScope', '$state', 'setupAllSearchService', 'stateService', 'utilityService', '$stateParams', 'setupAdvancedSearchService', '$timeout', '$sessionStorage', '$q', function($scope, $rootScope, $state, setupAllSearchService, stateService, utilityService, $stateParams, setupAdvancedSearchService, $timeout, $sessionStorage, $q) {
        var vm = this;
        var categorySet = new Array();
        var selectedCatList = [];
        $scope.loading = true;
        vm.pinCodeValidate = pinCodeValidate;
        init();
        vm.advSearchClick = advSearchClick;
        vm.productDtlsResp = productDtlsResp;
        vm.watchOnCategoryChange = watchOnCategoryChange;
        vm.prepareFilterRequestObject = prepareFilterRequestObject;
        vm.showPinInvalidMsg = false;
        vm.pinStateValidate = pinStateValidate;
        vm.goToAdvViewAll = goToAdvViewAll;
        vm.locationFilterError = false;
        var farmInputPriceRange = [{
            Name: "300 and below",
            value: "0 TO 300"
        }, {
            Name: "301 - 500",
            value: "301 TO 500"
        }, {
            Name: "501 - 900",
            value: "501 TO 900"
        }, {
            Name: "901 and above",
            value: "901 TO *"
        }];

        var equipmentPriceRange = [{
            Name: "10000 and below",
            value: "0 TO 10000"
        }, {
            Name: "10001 - 50000",
            value: "100001 TO 50000"
        }, {
            Name: "50001 - 100000",
            value: "50001 TO 100000"
        }, {
            Name: "100001 and above",
            value: "100001 TO *"
        }]
        function init() {
        	populateUserInfoFromSession();
            //pinCode //state
            vm.EnterInPinCodeField = EnterInPinCodeField;
            vm.showPinNotExists = false;
            vm.waitingForPageToLoad = false;

            $rootScope.dataLoading = true;
            $rootScope.dataStillLoading = true;

            vm.prodDisplay = true;
            vm.hideViewAll = true;
            vm.catValue = $stateParams.catlevel;
            vm.searchQueryDisplay = true;
            vm.searQuery = $stateParams.srchtxt;
            if (vm.searQuery === '') {
                vm.searchQueryDisplay = false;
            }
            console.log(vm.searchFields);
            vm.searchFields = $stateParams.type;
            vm.priceRange = [];

            //varibale required for Filter search
            vm.sortField = "";
            vm.selectedPriceRange = [];
            selectedCatList = [];
            vm.selectedBrands = [];
            vm.selectedGrades = [];
            vm.selection = {
                brands: {},
                grades: {},
                price: {}

            };
            vm.rowcount = 10;
            vm.start = 0;
            vm.rows = vm.rowcount;
            vm.filterListData = {};
            if ($sessionStorage['stateList']) {
                vm.statesList = angular.copy($sessionStorage['stateList']);
                
            } else {
               
                callStateDetails().then(processStateDataResponse);
            }

            if ($sessionStorage['filterlist']) {
                getFilterListFromSession();
            } else {
                callListFilter().then(processFilterList);
            }
      
            angular.element('.srchDrpDown').val($stateParams.type);
            changeCurrentSelector();
        }
        function changeCurrentSelector(){
        	var presentSelector = $stateParams.type;
        	if($rootScope.currentSelector==undefined){
        		angular.element("#"+presentSelector).addClass('currentSelected');
        	}else{
        		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
        		angular.element("#"+presentSelector).addClass('currentSelected');
        	}
        	$rootScope.currentSelector = presentSelector;
        }

        /*$q.all([$scope.request1, $scope.request2]).then(function(values) {
    	 $rootScope.dataLoading = false;
    	 $rootScope.dataStillLoading = false;
 	 });
    */
        vm.parentCheckChange = function(item) {
        	if(item.isChecked == false){
            	for (var i in item.subCategory) {
                    item.subCategory[i].isChecked = false;
                    if (item.subCategory[i].subCategory) {
                        vm.parentCheckChange(item.subCategory[i]);
                    }
                }
            }
        };
        //TO Add in advance search page
        function advSearchClick() {
            var srchText = angular.element('#srchtxt').val();
            vm.searchFields = angular.element('.srchDrpDown').val();
            $state.go('advancedsearchdetails', {
                "srchtxt": srchText,
                "type": vm.searchFields,
                "brands": null,
                "grades": null,
                "prices": null,
                "catlevel": false
            }, {
                reload: true
            });
        };

        function pinCodeValidate() {
            if ($scope.pinForm.pin.$valid && !$scope.pinForm.pin.$pristine) {
                if ($sessionStorage['filterPinCode'] != vm.pinCodefilter)
                    $sessionStorage['filterPinCode'] = -1;
                pinStateValidate();
            }
        }

        function pinStateValidate() {
        	 vm.locationFilterError = false;
            if (vm.locationfilter && vm.locationfilter.toString().trim().length > 0) {
                
                var pinPattern = new RegExp("^[0-9]{6}$");
               if(pinPattern.test(vm.locationfilter)){
            	   vm.pinCodefilter = vm.locationfilter;
            	   vm.filterstateID = null;
            	   prepareFilterRequestObject();
               }else{
            	   var state = vm.statesList.filter(function(value){
            		   return value.stateName.toLowerCase() == vm.locationfilter.toLowerCase();
            	   });
            	   
            	   if(state.length>0){
            		   vm.pinCodefilter = null;
                	   vm.filterstateID = state[0].stateId;
                	   prepareFilterRequestObject();
            	   }else{
            		   vm.locationFilterError = true;
            	   }
               }
                //callVerifyPinWithState(vm.pinCodefilter).then(processWhizapiResponse);
            } else {
            	vm.pinCodefilter = null;
            	vm.filterstateID = null;
                prepareFilterRequestObject();
            }

        }

        function prepareFilterRequestObject() {
            /*if ($sessionStorage['filterStateId'] != vm.filterstateID)
                $sessionStorage['filterStateId'] = -1;*/
            vm.showPinInvalidMsg = false;
            vm.showPinNotExists = false;

            $scope.loading = true;
            $rootScope.dataLoading = true;
            $rootScope.dataStillLoading = true;

            $scope.attrFilterListRequest = callAttributeFilterList()
            $scope.attrFilterListRequest.then(processAttributeFilterList);
            $q.all([$scope.attrFilterListRequest]).then(function(values) {
                prepareBrands();
                prepareGrades();
                preparePriceRange();
                vm.start = 0;
                if (vm.rowcount != 0)
                    vm.rows = vm.rowcount;
                prepareCategoryLevelObject();
                var requestObject = {
                    category: vm.categories,
                    categoryLevelDTOs: selectedCatList,
                    priceRange: vm.selectedPriceRange,
                    grades: vm.selectedGrades,
                    brands: vm.selectedBrands,
                    searchText: vm.searQuery,
                    start: vm.start,
                    rows: vm.rows,
                    sortField: vm.sortField,
                    season: vm.season,
                    state_id: vm.filterstateID,
                    pin: vm.pinCodefilter
                };

                var catArray = [];
                categorySet.forEach(function(value) {
                    if (catArray.indexOf(value) === -1)
                        catArray.push(value);
                });
                $state.transitionTo('advancedsearchdetails', {
                    "srchtxt": vm.searQuery,
                    "type": vm.categories,
                    "brands": vm.selectedBrands,
                    "grades": vm.selectedGrades,
                    "prices": vm.selectedPriceRange,
                    "catlevel": catArray,
                    "pin": vm.pinCodefilter,
                    "state": vm.filterstateID,
                    "season": vm.season
                }, {
                    location: true,
                    inherit: true,
                    relative: $state.$current,
                    notify: false
                });
                callGroupedSearchDetails(requestObject).then(processGroupedSearchResponse);
                console.log(requestObject);
            });

        }

        function callVerifyPinWithState(pin) {
            $scope.loading = true;
            return setupAdvancedSearchService.verifyPinWithState(pin);
        }

        function processWhizapiResponse(response) {
            $scope.loading = false;
            $rootScope.dataLoading = false;
            $rootScope.dataStillLoading = false;
            if (response.ResponseCode === 0) {
                var state = response.Data[0].State;
                var stateId = vm.statesList.filter(function(v) {
                    return v.stateName == state;
                })[0].stateId.toString();
                if (stateId === vm.filterstateID) {
                    vm.showPinInvalidMsg = false;
                    prepareFilterRequestObject();
                } else {
                    vm.showPinInvalidMsg = true;
                }
            }
            if (response.ResponseCode === 20) {
                vm.showPinInvalidMsg = true;
            }

        }

        function CategoryNodes(level1, level2, level3, level4) {
            this.level1 = level1;
            this.level2 = level2;
            this.level3 = level3;
            this.level4 = level4;
        }

        function LevelList(parent, child) {
            this.parent = parent;
            this.child = child;
        }

        function callStateDetails() {
            return setupAllSearchService.getStatesDetails();
        }

        function callAttributeFilterList() {
            var request = {
                category: vm.categories,
                level1: '*',
                pin: vm.pinCodefilter,
                season: vm.season,
                state_id: vm.filterstateID
            }
            return setupAdvancedSearchService.getAttributeFilterList(request);
        }
        vm.setSortCriteria = function(field) {
            vm.sortField = field;
            prepareFilterRequestObject();
        }
        vm.watchFunction = function() {
            prepareFilterRequestObject();
        }

        function goToAdvViewAll(groupName, index) {
            var sp = false;
            var bs = false;
            if (index == 0)
                sp = true;
            if (index == 1)
                bs = true;
            var catArray = [];
            categorySet.forEach(function(value) {
                if (catArray.indexOf(value) === -1)
                    catArray.push(value);
            });

            $state.go('advancedsearchviewall', {
                "srchtxt": vm.searQuery,
                "type": vm.categories,
                "level": groupName,
                "cats": catArray,
                "brands": vm.selectedBrands,
                "prices": vm.selectedPriceRange,
                "grades": vm.selectedGrades,
                "pin": vm.pinCodefilter,
                "state": vm.filterstateID,
                "season": vm.season,
                "sp": sp,
                "bs": bs
            });
        }

        function getFlagCount(objectList) {
            var count = 0;
            objectList.forEach(function(value, index) {
                if (value.isChecked)
                    count++;
            });
            return count;
        }

        function prepareBrands() {
            vm.selectedBrands.splice(0, vm.selectedBrands.length);
            for (var brand in vm.selection.brands) {
            	var isObjectExist = vm.attributefilter[0].filterLists.filter(function(v) {
                    return v.name == brand;
                });
                if (vm.selection.brands[brand] && isObjectExist.length>0)
                    vm.selectedBrands.push(brand);
            }

        }

        function preparePriceRange() {
            vm.selectedPriceRange.splice(0, vm.selectedPriceRange.length);
            for (var sprice in vm.selection.price) {
            	var isObjectExist = vm.priceRange.filter(function(v) {
                    return v.value == sprice;
                });
            	if (vm.selection.price[sprice] && isObjectExist.length>0)
                    vm.selectedPriceRange.push(sprice);
            }
        }

        function prepareGrades() {
            vm.selectedGrades.splice(0, vm.selectedGrades.length);
            for (var grade in vm.selection.grades) {
            	var isObjectExist = vm.attributefilter[1].filterLists.filter(function(v) {
                    return v.name == grade;
                });
                if (vm.selection.grades[grade] && isObjectExist.length>0)
                    vm.selectedGrades.push(grade);
            }
        }

        function EnterInPinCodeField(event) {
            if (event.which === 13) {
                vm.pinCodeValidate();
            }
        }
        //Calling Filtered Result
        function callFilteredResult(requestObject) {
            return setupAdvancedSearchService.getFilteredSearchDetails(requestObject);
        }
        //Calling grouped Result
        function callGroupedSearchDetails(requestObject) {
            return setupAdvancedSearchService.getGroupedSearchDetails(requestObject);
        }
        //For filterList
        function callListFilter() {
            return setupAdvancedSearchService.getFilterList();
        }
        //For filterList response
        function processFilterList(response, $scope) {
            $sessionStorage['filterlist'] = angular.copy(response.body.data[0]);
            vm.filterListData = response.body.data[0];
            angular.element("#srchtxt").val($stateParams.srchtxt);
            angular.element(".srchDrpDown").val($stateParams.type);
            if ($stateParams.type != "*") {
                vm.categories = $stateParams.type;
                watchOnCategoryChange(vm.categories);
            }
        }

        function processAttributeFilterList(response) {
            vm.attributefilter = response;
            console.log(vm.attributefilter);
        }

        function processStateDataResponse(response) {
            var body = response.body || {};
            vm.statesList = body.data;
            $sessionStorage['stateList'] = angular.copy(vm.statesList);
            setupAllSearchService.statesList = vm.statesList;
            populateUserInfoFromSession();
        }

        function populateUserInfoFromSession() {
            if ($sessionStorage["userInfo"]) {
                if (!$sessionStorage['filterPinCode']) {
                	vm.locationfilter = $sessionStorage["userInfo"].shippingAddress.pinCode;
                    $sessionStorage['filterPinCode'] = angular.copy(vm.pinCodefilter);
                } else {
                    if ($sessionStorage['filterPinCode'] != -1)
                    	vm.locationfilter = angular.copy($sessionStorage['filterPinCode']);
                }

                pinStateValidate();
               /* if (!$sessionStorage['filterStateId']) {
                    vm.filterstateID = vm.statesList.filter(function(v) {
                        return v.stateName == $sessionStorage["userInfo"].shippingAddress.state;
                    })[0].stateId.toString();
                    $sessionStorage['filterStateId'] = angular.copy(vm.filterstateID);
                } else {
                    if ($sessionStorage['filterStateId'] != -1)
                        vm.filterstateID = angular.copy($sessionStorage['filterStateId']);
                }*/
            }
        }

        function getFilterListFromSession() {
            vm.filterListData = angular.copy($sessionStorage['filterlist']);
            angular.element("#srchtxt").val($stateParams.srchtxt);
            angular.element(".srchDrpDown").val($stateParams.type);
            $timeout(function() {
                angular.element(".srchDrpDown").val($stateParams.type);
                angular.element("#srchtxt").val($stateParams.srchtxt)
            }, 100);
            if ($stateParams.type != "*") {
                vm.categories = $stateParams.type;
                watchOnCategoryChange(vm.categories);
            }
        }

        function prepareCategoryLevelObject() {
            vm.catValue = false;
            categorySet.splice(0, categorySet.length);
            if (vm.subCategories != null) {
                selectedCatList.splice(0, selectedCatList.length);
                var flagLevel1 = getFlagCount(vm.subCategories);
                var newflagLevel1 = flagLevel1;
                vm.subCategories.forEach(function(value, index) {
                    if (value.isChecked) {
                        categorySet.push(value.categoryId);
                        vm.catValue = true;
                        var level1 = value.categoryName;
                        var flagLevel2 = getFlagCount(value.subCategory);
                        var newflagLevel2 = flagLevel2;
                        value.subCategory.forEach(function(value, index) {
                            if (value.isChecked) {
                                categorySet.push(value.categoryId);
                                var level2 = value.categoryName;
                                var flagLevel3 = getFlagCount(value.subCategory);
                                var newflagLevel3 = flagLevel3;
                                value.subCategory.forEach(function(value, index) {
                                    if (value.isChecked) {
                                        categorySet.push(value.categoryId);
                                        var level3 = value.categoryName;
                                        var flagLevel4 = getFlagCount(value.subCategory);
                                        var newflagLevel4 = flagLevel4;
                                        value.subCategory.forEach(function(value, index) {
                                            if (value.isChecked) {
                                                categorySet.push(value.categoryId);
                                                var level4 = value.categoryName;
                                                if (flagLevel4 > 0 && newflagLevel4 == flagLevel4) {
                                                    selectedCatList.push(new CategoryNodes(level1, level2, level3, level4));
                                                    flagLevel4--;
                                                    newflagLevel4--;

                                                }
                                                if (newflagLevel4 == 0) {
                                                    newflagLevel3--;
                                                }
                                                flagLevel4 = newflagLevel4;
                                            }
                                        });
                                        if (flagLevel3 > 0 && newflagLevel3 == flagLevel3) {
                                            selectedCatList.push(new CategoryNodes(level1, level2, level3, ""));
                                            flagLevel3--;
                                            newflagLevel3--;

                                        }
                                        if (newflagLevel3 == 0) {
                                            newflagLevel2--;

                                        }
                                        flagLevel3 = newflagLevel3;
                                    }
                                });
                                if (flagLevel2 > 0 && newflagLevel2 == flagLevel2) {
                                    selectedCatList.push(new CategoryNodes(level1, level2, "", ""));
                                    flagLevel2--;
                                    newflagLevel2--;

                                }
                                if (newflagLevel2 == 0) {
                                    newflagLevel1--;
                                }
                                flagLevel2 = newflagLevel2;
                            }

                        });
                        if (flagLevel1 > 0 && newflagLevel1 == flagLevel1) {
                            selectedCatList.push(new CategoryNodes(level1, "", "", ""));
                            flagLevel1--;
                            newflagLevel1--;
                        }
                        flagLevel1 = newflagLevel1;
                    }

                });
            }
        }

        function callSearchDetails(req) {
            vm.waitingForPageToLoad = true;
            return setupAllSearchService.getAllSearchDetails(req);
        };

        function processGroupedSearchResponse(response) {
            var store = connection.storeImage;
            vm.productsGroupedList = response;
            vm.productsGroupedList.forEach(function(value, index) {
                value.start = 0;
                value.end = value.productList.length;
                value.count = 0;
                value.prev = false;
                value.next = true;
                if (value.end <= 5) {
                    value.next = false;
                }
                value.productList.forEach(function(subvalue) {
                    subvalue.product_img_path = store + subvalue.product_img_path;
                });
            });

            vm.message = 1;//"No Product(s) Found For Selected Criteria";
            if (vm.productsGroupedList[1].productList.length == 0) {
                if (vm.searQuery != "") {
                    vm.message = 2;//vm.searQuery + " Not found in " + vm.categories;
                }
                if (vm.filterstateID) {
                    var statename = vm.statesList.filter(function(v) {
                        return v.stateId == vm.filterstateID;
                    })[0].stateName;
                }
            }
            $rootScope.dataLoading = false;
            $rootScope.dataStillLoading = false;
            $scope.loading = false;
        };
        vm.increseCount = function(productsGroup) {
            ++productsGroup.count;

            if (productsGroup.count == productsGroup.end - 5) {
                productsGroup.next = false;
            } else {
                productsGroup.next = true;
            }
            if (productsGroup.count >= 1) {
                productsGroup.prev = true;
            }

        };
        vm.decreseCount = function(productsGroup) {
            --productsGroup.count;
            if (productsGroup.count >= 1) {
                productsGroup.prev = true;
            } else {
                productsGroup.prev = false;
            }
            if (productsGroup.count < productsGroup.end) {
                productsGroup.next = true;
            }
        };

        function processAdvancedSearchResponse(response) {
            vm.productsList = response;
            if (vm.productsList.length == 0) {
                vm.prodDisplay = false;
                vm.hideViewAll = false;
            } else {
                vm.prodDisplay = true;
                vm.hideViewAll = true;
            }
            if (vm.productsList.length > 0 && vm.productsList.length < vm.rows) {
                vm.hideViewAll = false;
                if (vm.productsList.length < 10) {
                    vm.rowcount = 10;
                }
            }

            if (vm.productsList.length != 0) {
                for (var i = 0; i < vm.productsList.length; i++) {
                    var discount = parseInt(vm.productsList[i].origo_discount) + parseInt(vm.productsList[i].vendor_discount);
                    var unit_price = parseInt(vm.productsList[i].unit_price);
                    var actual_discount = unit_price - unit_price * discount / 100;
                    vm.productsList[i].formattedPrice = actual_discount.toFixed(2);
                }

            }


        };

        function productDtlsResp(inputSearch) {
            setupAllSearchService.productId = inputSearch;
            setupAllSearchService.quantity = null;
            $sessionStorage["fromWhere"] = "advanceaddtocart";
            setupAllSearchService.recommendedProductDetails = vm.productsList;
            stateService.set(constants.PRODUCT_DISABLE_ADD_CARD, "advanceaddtocart");
            $state.go('productdetails', {
                "id": inputSearch
            });
        };

        function callSearchDetails(req) {
            return setupAllSearchService.getAllSearchDetails(req);
        };

        function watchOnCategoryChange(catvalue1) {
            vm.filterListData.categoryList.forEach(function(value, index) {
                if (catvalue1 == vm.filterListData.categoryList[index].categoryName) {
                    vm.subCategories = vm.filterListData.categoryList[index].subCategory;
                    angular.element('.srchDrpDown').val(catvalue1);
                    Object.keys(vm.selection.brands).forEach(function(key) {
                        delete vm.selection.brands[key];
                    });
                    Object.keys(vm.selection.grades).forEach(function(key) {
                        delete vm.selection.grades[key];
                    });
                    Object.keys(vm.selection.price).forEach(function(key) {
                        delete vm.selection.price[key];
                    });
                    vm.season = "";
                }
            });
            $scope.attributeFilter = callAttributeFilterList();
            $scope.attributeFilter.then(processAttributeFilterList);
            $q.all([$scope.attributeFilter]).then(function() {
                getBrandsFromSession();
                getGradesFromSession();
                if(vm.categories =='Farm Input'){
                	 vm.priceRange = angular.copy(farmInputPriceRange);
                }else{
                	 vm.priceRange = angular.copy(equipmentPriceRange);
                }
                getPriceRangeFromSession();
            });
            
            getCategoriesfromSession();
            vm.season = $stateParams.season;
            if ($stateParams.state){
            	vm.locationfilter = vm.statesList.filter(function(value){
         		   return value.stateId == $stateParams.state;
         	   })[0].stateName;
            	pinStateValidate();
            }
                //vm.filterstateID = $stateParams.state;
            if ($stateParams.pin){
            	vm.locationfilter = $stateParams.pin;
            	pinStateValidate();
            }
            	
            prepareFilterRequestObject();
            


        }

        function checkSubcat(item) {
            for (var i in item.subCategory) {
                item.subCategory[i].isChecked = true;
                if (item.subCategory[i].subCategory) {
                    vm.parentCheckChange(item.subCategory[i]);
                }
            }
        }

        function getBrandsFromSession() {
            if ($stateParams.brands) {
                vm.selection.brands = {}
                var selectedBrands = $stateParams.brands.split(',');
                selectedBrands.forEach(function(value) {
                    var isObjectExist = vm.attributefilter[0].filterLists.filter(function(v) {
                        return v.name == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                        vm.selection.brands[value] = true;
                });

            }

        };

        function getGradesFromSession() {
            if ($stateParams.grades) {
                var selectedGrades = $stateParams.grades.split(',');
                selectedGrades.forEach(function(value) {
                    var isObjectExist = vm.attributefilter[1].filterLists.filter(function(v) {
                        return v.name == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                        vm.selection.grades[value] = true;

                });
            }

        };

        function getPriceRangeFromSession() {
            if ($stateParams.prices) {
                var selectedPrices = $stateParams.prices.split(',');
                selectedPrices.forEach(function(value) {
                	var isObjectExist = vm.priceRange.filter(function(v) {
                        return v.value == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                    vm.selection.price[value] = true;
                });
            }
        };

        function getCategoriesfromSession() {
            if ($stateParams.catlevel)
                selectCheckboxes(vm.subCategories);
        }

        function selectCheckboxes(value) {
            var selectedCategoriesId = $stateParams.catlevel.split(',');
            value.forEach(function(subvalue, index) {
                if (selectedCategoriesId.indexOf(subvalue.categoryId.toString()) >= 0) {
                    subvalue.isChecked = true;
                    selectCheckboxes(subvalue.subCategory);
                }
            });
        }
    }]);
});