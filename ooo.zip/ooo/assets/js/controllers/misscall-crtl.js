
define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  
	controllers.controller("missCallCtrl", ['$scope', "$uibModalInstance",'$state','utilityService','missCallService','stateService', function($scope,$uibModalInstance,$state, utilityService,missCallService,stateService) {
		var vm = this;
		vm.showForm = true;
		vm.errorMsg = false;
		vm.sendcallDetails= function(){
			var callDetails = angular.extend({
				"name" :vm.name,
				"mobile" :vm.mobile
			});
			callSendUserDetails(callDetails).then(processCallDetailsResponse);
		},
		callSendUserDetails= function(request){
			return missCallService.sendCallDetails(request);
			
		}
		processCallDetailsResponse = function(response){
			var applicationStatusCode = response.body.applicationStatusCode;
			if(applicationStatusCode===1034){
				vm.showForm =false;
			}
			else if(applicationStatusCode===2061){
				vm.errorMsg = true;
				
			}
		}
	
	
	}]);

	

});
