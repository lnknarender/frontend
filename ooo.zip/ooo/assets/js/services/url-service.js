/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("urlService",['hostService',function(hostService){
		return	{

	        getSecurePath: function(){
	            return hostService.getHost();
	        },
	        
	        getPublicPath: function(){
	            return hostService.getHost();
	        },
	        getSearchDataUrl: function () {
	        	if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/search/all_search.json'; 
	          	}
	            return this.getSecurePath() +'/getsearchdata';
	        },
	        getAutoCompleteUrl: function () {
	        	
	    	if(connection.useMockData){
	      		 return this.getSecurePath() +'/assets/test/mockFiles/search/autoComplete.json'; 
	      	    }
	            return this.getSecurePath() +'/autocomplete';
	        },   
	        getFullDataSearchUrl: function () {
	        	if(connection.useMockData){
	       		 return this.getSecurePath() +'/assets/test/mockFiles/search/all_search.json'; 
	       	    }
	        	 
	            return this.getSecurePath() +'/getsearchdata';
	        },
	        searchFarmUrl: function () {
	            return this.getSecurePath() +'/search/farm';
	        },
	        searchCommoditiesUrl: function () {
	            return this.getSecurePath() +'/search/commodities';
	        },
	        searchEquipmentsUrl: function () {
	            return this.getSecurePath() +'/search/equipments';
	        },
	        getHomeUrl: function() {
	            
	            return '/start';
	        },
	        userOfferServiceUrl:function(){
	        	return this.getSecurePath()+'/getMachineryLoanForm';
	        },
	        getStartUrl: function() {
	            return '/start';
	        },
	        getErrorUrl: function() {
	            return '/error';
	        },
	        getRedirectURL: function(){
	            return '/redirect';
	        },
	        registrationUserUrl:function(){
	        	
	        	return this.getSecurePath() +'/saveOrUpdateUserDetails';
	        },
	        documentUploadForRegistedUserUrl:function(){
	        	return this.getSecurePath() +'/uploadFile';
	        },
	        secureUserLoginUrl:function(){
	        if(connection.useMockData){
	       		 return this.getSecurePath() +'/assets/test/mockFiles/login/login.json'; 
	       	 }
	        	return this.getSecurePath() +'/login';
	        },
			generateOTPUrl:function(){
				if(connection.useMockData){
		       		 return this.getSecurePath() +'/assets/test/mockFiles/login/generateOTP.json'; 
		       	 }
	        	return this.getSecurePath() +'/generateOTP';
	        },
	        validateOtpUrl:function(){
				if(connection.useMockData){
		       		 return this.getSecurePath() +'/assets/test/mockFiles/login/validateOTP.json'; 
		       	 }
	       	return this.getSecurePath() +'/validateOTP';
	       },
	        addproductDetailsToCartUrl:function(){
	        	if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/addToCart.json'; 
	          	 }
	           	
	        	return this.getSecurePath() +'/addToCart';
	        },
	        deleteToCartUrl:function(){
	        	return this.getSecurePath() +'/deleteToCart';
	        },
	        forgetPasswordUrl:function(){
	        	if(connection.useMockData){
	         		 return this.getSecurePath() +'/assets/test/mockFiles/login/forgotPassword.json'; 
	         	 }
	        	return this.getSecurePath() +'/forgotPassword';
	        },
	        callForgetUserNameUrl:function(){
	        	return this.getSecurePath() +'/forgetUserName';
	        },
	        changePasswordUrl:function(){
	        	return this.getSecurePath() +'/changePassword';
	        },
	        manualVerificationUserUrl:function(){
	        	return this.getSecurePath() +'/manualVerification';
	        },
	        getWareHouseLocationsUrl:function(){
	          if(connection.useMockData){
	        		 return this.getSecurePath() +'/assets/test/mockFiles/search/storeLocator.json'; 
	        	 }
	        	return this.getSecurePath() +'/getStoreLocator';
	        },
	       callValidLoginNameUrl:function(){
	        	return this.getSecurePath() +'/checkLoginName';
	        },
	        callValidEmailIdUrl:function(){
	        	return this.getSecurePath() +'/checkEmailId';
	        },
	        callValidMobileNumberUrl:function(){
	        	return this.getSecurePath() +'/checkmobileNumber';
	        },
	        submitOtpNumberUrl:function(){
	        	return this.getSecurePath() +'/otpNumberCheck';
	        },
	        getStateDetailsUrl:function(){
	        	if(connection.useMockData){
	        		return this.getSecurePath() +'/assets/test/mockFiles/search/states.json'; 
	        	}
	        	return this.getSecurePath() +'/getStates';
	        },
			getAddressDetailsUrl:function(){
	        	if(connection.useMockData){
	        		return this.getSecurePath() +'/assets/test/mockFiles/search/states_reg.json'; 
	        	}
	        	return this.getSecurePath() +'/statecity';
	        },
	        getProductDetailsUrl:function(){
	        	if(connection.useMockData){
	        		return this.getSecurePath() +'/assets/test/mockFiles/search/product_details.json'; 
	        	}
	        	return this.getSecurePath() +'/productById';
	        },
	        getDistrictDetailsUrl:function(){
	        	if(connection.useMockData){
	       		 return this.getSecurePath() +'/assets/test/mockFiles/search/districts.json'; 
	       	 }
	        	return this.getSecurePath() +'/getDistricts';
	        },
			getCitiesUrl:function(){
	        	if(connection.useMockData){
	       		 return this.getSecurePath() +'/assets/test/mockFiles/search/cities.json'; 
	       	 }
	        	return this.getSecurePath() +'/getCities';
	        },
	        callValidEmailUrl:function(){
	        	return this.getSecurePath() +'/checkEmailId';
	        },
			callOtpNumberUrl:function(){
	        	return this.getSecurePath() +'/validateOTP';
	        },
	        continueHandlerUrl:function(){
	        	return this.getSecurePath() +'/updateStatus';
	        },
	        checkAvailibalityUrl:function(){
	        	 if(connection.useMockData){
	           		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/checkavailablity.json'; 
	           	 }
	        	return this.getSecurePath() +'/checkavailablity';
	        },
	        addToCartUrl:function(){
	        	if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/addToCart.json'; 
	          	 }
	        	return this.getSecurePath() +'/addToCart';
	        },
	        hitsUrl:function(){
	        	return this.getSecurePath() +'/hits';
	        },
	        removeFromCartUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/removeFromCart.json'; 
	          	 }
	       	return this.getSecurePath() +'/removeFromCart';
	        },
	        updateQuantityUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/updateQuantity.json'; 
	          	 }
	       	return this.getSecurePath() +'/updateQuantity';
	        },
	        getCartUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/getCart.json'; 
	          	 }
	       	return this.getSecurePath() +'/getCart';
	        },
	        getPlacementOrderUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/placementOrder.json'; 
	          	 }
	       	return this.getSecurePath() +'placeNewOrder'; 
	        },
	        checkProductAvailabityUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/productavailablity.json'; 
	          	 }
	       	return this.getSecurePath() +'/productavailablity';
	       },
	       addNewAddressUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/addnewaddress.json'; 
	          	 }
	       	return this.getSecurePath() +'/addNewShippingAddress';
	       },
	       updateAddressUrl:function(){
	    	   if(connection.useMockData){
	    		   return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/updateaddress.json'; 
		       }
		       return this.getSecurePath() +'/updateShippingAddress';
		   },
		   removeAddressUrl:function(){
	    	   if(connection.useMockData){
	    		   return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/removeaddress.json'; 
		       }
		       return this.getSecurePath() +'/removeShippingAddress';
		   },
	       submitOrderRequestUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/submitorder.json'; 
	          	 }
	       	return this.getSecurePath() +'/placeNewOrder';
	       },
	       getProdcutSummaryUrl:function(){
	       	 if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/orderManagement/productsummary.json'; 
	          	 }
	       	return this.getSecurePath() +'/getProductSummary';
	       },
	       getUserDetailsUrl:function(){         	
	         	return this.getSecurePath() +'/useraccount';
	         },
	       getVerifyPasswordUrl:function(){         	
	        	return this.getSecurePath() +'/verifypassword';
	        },
	        getChangePasswordUrl:function(){
	        	return this.getSecurePath()+'/changepassword';
	        },
	        callChangeBankUrl:function(){
	        	return this.getSecurePath()+'/addnewbank';
	        },
	        getUserOrdersUrl:function(){
	            return this.getSecurePath() +'/getOrderdetails';
	        },
	        getWalletUrl:function(){
	        	return this.getSecurePath()+'/walletTransactionDetail';
	        }, 
	        getCategoryInputUrl:function(){
	        	return this.getSecurePath()+'/getcategoryinput';
	        },
	        createFarmInputUrl:function(){
	        	return this.getSecurePath()+'/addFarmInputsListing';
	        },
	        updateFarmInputUrl:function(){
	        	return this.getSecurePath()+'/updateFarmInputsListing';
	        },
	        deleteFarmInputUrl:function(){
	        	return this.getSecurePath()+'/deleteFarmInputsListing';
	        },
	        getFarmInputUrl:function(){
	        	return this.getSecurePath()+'/getAllListing';
	        },
	        createCommodityInputUrl:function(){
	        	return this.getSecurePath()+'/createcommodityinput';
	        },
	        updateCommodityInputUrl:function(){
	        	return this.getSecurePath()+'/updatecommodityinput';
	        },
	        deleteCommodityInputUrl:function(){
	        	return this.getSecurePath()+'/deletecommodityinput';
	        },
	        getCommodityInputUrl:function(){
	        	return this.getSecurePath()+'/getcommodityinput';
	        },
	        getCallUrl :function(){
	        	return this.getSecurePath()+'/saveCallDetails';
	        },
			getHomeOfferUrl:function(){
	        	return this.getSecurePath()+'/origoAdvService';
	        },
	        getCategoryBasedProducts:function(){
	        	//path for submit demand category req
	        	 return this.getSecurePath() +'/getListOfProducts';
	        },
	        sendSubmitDemand:function(){
	        	//path for sending submit demand 
	        	 return this.getSecurePath() +'/saveOrUpdateWishList';
	        },
	        
	        getUserDemands:function(){
	        	//get user demands
	        	 return this.getSecurePath() +'/getDemandsInWishList';
	        },
	        delDemand:function(){
	        	 return this.getSecurePath() +'/deleteFromWishList';
	        },
	        getaddShippingUrl:function(){
	        	return this.getSecurePath()+'/addNewShippingAddress';
	        },
	        getShippingAddressUrl:function(){
	        	return this.getSecurePath()+'/getShippingAddresses';
	        },
	        getFilterListUrl:function(){
	        	if(connection.useMockData){
	          		 return this.getSecurePath() +'/assets/test/mockFiles/search/filterlist.json'; 
	        	}
	        	return this.getSecurePath()+'/getfilterlist';
	        },
	        getFilterResultUrl:function(){
	        	return this.getSecurePath()+'/filterresults';
	        },
			addToWishlistUrl:function(){
	        	//to add product to wishlist
	        	 return this.getSecurePath() +'/saveOrUpdateWishList';
	        },
	        getUserWishlistItems:function(){
	        	//get wishlist items
	        	 return this.getSecurePath() +'/getProductsOfInterest';
	        },
	        delItemFromWL:function(){
	        	//delete item from wishlist
	        	 return this.getSecurePath() +'/deleteFromWishList';
	        },
	        signOutURL:function(){
	        	//delete item from wishlist
	        	 return this.getSecurePath() +'/logout';
	        },
	        getAllStoresUrl:function(){
	        	return this.getSecurePath() +'/getAllStores';
	        },
	        getSeedClassUrl:function(){
	        	return this.getSecurePath() +'/getSeedClassMasterData';
	        },
	        getSkuUrl:function(){
	        	return this.getSecurePath() +'/getSkuMasterData';
	        },
	        getGradeUrl:function(){
	        	return this.getSecurePath() +'/getGradeMasterData';
	        },
	        getFarmInputsListingByIdUrl:function(){
	        	return this.getSecurePath() +'/getListingById';
	        },
	        getProducts:function(){
	        	return this.getSecurePath() +'/filterresults';
	        },
	        getGroupedData:function(){
	        	return this.getSecurePath() +'/groupeddata';
	        },
	        getAttributeFilterlistUrl:function(){
	        	return this.getSecurePath() +'/getattributefilterlist';
	        },
	        getAttributesForCategoryUrl:function(){
	        	return this.getSecurePath() +'/getAttributeDetails';
	        },
	        getBestSellingProductsUrl:function(){
	        	return this.getSecurePath() +'/getBestSellingProductsById';
	        },
	        getStoresAndSeasonByStateIdUrl:function(){
	        	return this.getSecurePath() +'/getStoresAndSeasonByStateId';
	        },
	        getAllUsersUrl:function(){
	        	return this.getSecurePath() +'/getUsersOnOrigo';
	        },
	        addMoneyToUser:function(){
	        	return this.getSecurePath() +'/addMoney';
	        },
	        addrApprovalUsers:function(){
	        	return this.getSecurePath() +'/addrApprovalForUsers';
	        },
	        getAllOrders:function(){
	        	return this.getSecurePath() +'/getallorders';
	        },
	        orderStatusChange:function(){
	        	return this.getSecurePath() +'/changeorderstatus';
	        }
		};
	}]);
    
	return services;
});