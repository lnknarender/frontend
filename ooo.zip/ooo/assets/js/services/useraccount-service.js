/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("userAccountService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return	{
			  userAccount: function (useraccount) {
	        	 var url = urlService.getUserDetailsUrl();
	            return ajaxService.doGet(url,useraccount);
	        },
	        
	        verifyPassword:function(userInfo){
	        	var url = urlService.getVerifyPasswordUrl();
	        	return ajaxService.doPost(url,{},userInfo);
	        	
	        },
	        generateOTP:function(loginName){
	        	var url = urlService.generateOTPUrl();
	        	return ajaxService.doGet(url,loginName);
	        	
	        },
	        changePassword:function(generateOTPInfo){
	        	var url =urlService.getChangePasswordUrl();
	        	return ajaxService.doPut(url,{},generateOTPInfo);
	        },
	       ValidateOTP :function(loginName){
	    		 var url = urlService.callOtpNumberUrl();
	             return ajaxService.doGet(url,loginName);
	    	   
	       }
	        ,
	         userOffer: function (userOffer) {
	                var url = urlService.userOfferServiceUrl();
	                return ajaxService.doPost(url, {},userOffer);
	            },
			addBankDetails:function(bankInfo){
	        	var url=urlService.callChangeBankUrl();
	        	return ajaxService.doPut(url,{},bankInfo);
	        },getIndianStateList:function(stateName){
	        	var url=urlService.getAddressDetailsUrl();
	        	return ajaxService.doGet(url,stateName);
	        },getUserWallet:function(userInfo){
	        	var url = urlService.getWalletUrl();
	        	return ajaxService.doGet(url,userInfo);
	        },getAddShipping:function(userAdd){
	        	var url = urlService.getaddShippingUrl();
	        	return ajaxService.doPost(url,{},userAdd);
	        }
		};
	}]);
    
	return services;
});