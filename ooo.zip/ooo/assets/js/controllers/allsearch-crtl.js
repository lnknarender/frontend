
/**
 *  search the product when initially loaded by the application
 */
'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("searchCtrl", ['$scope','$state', 'setupAllSearchService','$window','$timeout', function($scope,$state, setupAllSearchService,$window,$timeout) {


	 var vm = this;
     init();
		vm.storeLocatorHandler=storeLocatorHandler;
		vm.inputFarmHandler=inputFarmHandler;
		vm.viewAllEquipments=viewAllEquipments;
		vm.viewAllCommodities=viewAllCommodities;
		vm.viewAllInputFarms=viewAllInputFarms;
		vm.onkeyPress =onkeyPress;
		vm.buyFinancingHanlder=buyFinancingHanlder;
		vm.checkForApprovalHanlder =checkForApprovalHanlder;
		vm.sellCommoditiesHanlder=sellCommoditiesHanlder;
		vm.freebiesHanlder=freebiesHanlder;
		vm.specialAuctionsHandler=specialAuctionsHandler;
		vm.findStoreOrWarhouseHandler=findStoreOrWarhouseHandler;
		vm.findWareHouseLocations=findWareHouseLocations;
		
		vm.searchFields = "all";
		vm.onStateChange=onStateChange;
		   function viewAllInputFarms(){
			    setupAllSearchService.type="farminputs";
	        	$state.go('advancedsearchdetails');
	        };
	
     

/* function nameToValue(obj) {
     if (angular.isObject(obj) && angular.isUndefined(obj.value)) {
         obj.value = obj.cereal_desc;
     }
     return obj;
 }*/
/*autocompleteCode*/
 
 $scope.selectedData = null;

 $scope.onSelect = function(selection) {
		//console.log(selection);
		$scope.selectedData = selection;
	};

	$scope.clearInput = function() {
		$scope.$broadcast('simple-autocomplete:clearInput');
	};
	/*autocompleteCode Ends*/
	vm.advSearchClick = function(){
		var request=angular.extend({},{
			//searchText:$scope.selectedData.title,
			searchText:angular.element('#srchtxt').val(),
			type:vm.searchFields
		});
		 callSearchDetails(request).then(processAdvancedSearchResponse);
	};
		function buyFinancingHanlder(){
			//$window.open("http://localhost:8080/OrigoSVN/#/buyFinancing",'width=25px',"height=250px")
			$state.go('buyFinancing');
		}
		function checkForApprovalHanlder(){
			$state.go('login');
		}
		function sellCommoditiesHanlder(){
			//$window.open("http://localhost:8080/OrigoSVN/#/sellCommodities",'width=25px',"height=250px")
			$state.go('sellCommodities');
		}
		function freebiesHanlder(){
			//$window.open("http://localhost:8080/OrigoSVN/#/freebies",'width=25px',"height=250px")
			$state.go('freebies');
		}
		function specialAuctionsHandler(){
			//$window.open("http://localhost:8080/OrigoSVN/#/specialAuctions",'width=25px',"height=250px")
		}
		function findStoreOrWarhouseHandler(){
			//$window.open("http://localhost:8080/OrigoSVN/#/findStoreOrWarhouse",'width=25px',"height=750px")
		}
		function callAtDistrcitTimeout() {
			vm.district=setupAllSearchService.storeinfo.district;
			//setupAllSearchService.storeinfo={};
		}
		function callAtTimeout() {
			vm.state=setupAllSearchService.storeinfo.state ;
			
			$timeout(callAtDistrcitTimeout, 100);
		}
     function init() {
          vm.waitingForPageToLoad = false;
          if(setupAllSearchService.storeinfo!=null||setupAllSearchService.storeinfo!=undefined){
         	  vm.statesList=setupAllSearchService.statesList ;
         	  vm.locator=setupAllSearchService.storeinfo.storeType;
         	  vm.districtList =setupAllSearchService.districtList;
         	  $timeout(callAtTimeout, 100);
               vm.storesLocation= setupAllSearchService.storesLocation;
               vm.warehouse = setupAllSearchService.isWareHouse;
               vm.storeDetails = true;
          }else{
         	 vm.locator="store";
         	 vm.storeDetails = false;
         	 callFullDataDetails().then(processFullDataSearchResponse);
         	 callStateDetails().then(processStateDataResponse);
          }
      }
     function callStateDetails(){
     	return setupAllSearchService.getStatesDetails();
     }
     function processStateDataResponse(response){
     	var body = response.body;
     	vm.statesList = body.data;
     	setupAllSearchService.statesList =vm.statesList;
     	console.log(vm.statesList);
     }
     function onStateChange(){
     	var request= angular.extend({},{
     		stateName:vm.state
     	});
     	 callDistrictDetails(request).then(processDistrictResponse);
     }
     function callDistrictDetails(request){
     	return setupAllSearchService.getDistrictDetails(request);
     }
     function processDistrictResponse(res){
     	var data= res.body.data;
     	vm.districtList=data;
     	setupAllSearchService.districtList =vm.districtList;
     	
     }
     function onkeyPress($event){
     	if ($event.which === 13){
     		 var free_text= angular.element('#free_text');
     		 callSearchDetails(free_text.val()).then(processFullDataSearchResponse);
     	}
     	  
     	}
     function inputFarmHandler(inputSearch){
     	
     	setupAllSearchService.productDetails=inputSearch;
     	$state.go('productdetails');
     }
     function callSearchDetails(free_text) {
         vm.waitingForPageToLoad = true;
         var searchText = angular.extend({},{
         	searchText:free_text
			});
         return setupAllSearchService.getAllSearchDetails(searchText);
     };
     function callFullDataDetails() {
         vm.waitingForPageToLoad = true;

         return setupAllSearchService.getFullDataSearchDetails();
     };
     function processFullDataSearchResponse(changeDetailsResponse) {
     	vm.allFarmInputs =changeDetailsResponse;
     }; 
     function processAdvancedSearchResponse(response) {
     	setupAllSearchService.allProductDetails =response;
     	$state.go('advancedsearchdetails');
     }; 
     
     function viewAllEquipments(){
     	
     };
     function viewAllCommodities(){
     	
     };
  
		/*StoreLocatorCode*/
     vm.map_grid = false;
     vm.limit="2";
     function storeLocatorHandler(){
			 if (navigator.geolocation){
	             navigator.geolocation.getCurrentPosition(onSuccess);
	         }else{
	            alert("Geolocation API not supported.");
	         }
		}
     function onSuccess(position) {
         var latx=position.coords.latitude;    
         var lonx=position.coords.longitude;   
         var resultx=new google.maps.LatLng(latx,lonx);
         var map = new google.maps.Map(document.getElementById('sl_map'), { 
           zoom: 5,  
           scrollwheel: false,
           center: resultx,
           mapTypeId: google.maps.MapTypeId.ROADMAP 
         }); 
         var infowindow = new google.maps.InfoWindow(); 
         var marker, i; 
         for (i = 0; i < $scope.storesLocation.length; i++) {   
           marker = new google.maps.Marker({ 
             position: new google.maps.LatLng($scope.storesLocation[i].latitude, $scope.storesLocation[i].longitude), 
             disableAutoPan: true,
             map: map 
           }); 
           google.maps.event.addListener(marker, 'click', (function(marker, i) { 
             return function() { 
               infowindow.setContent($scope.storesLocation[i][0]); 
               infowindow.open(map, marker); 
             }; 
           })(marker, i)); 
         }
     }
     vm.showStores = function(){
     	if(vm.map_grid){
     		return;
     	}
     	vm.map_grid = true;
     	
     	var mapView = angular.element( document.querySelector( '#mapView' ) );
     	mapView.addClass('storeLocator-viewtype-active');
     	mapView.removeClass('storeLocator-viewtype-inactive');
     	var gridView = angular.element( document.querySelector( '#gridView' ) );
     	gridView.addClass('storeLocator-viewtype-inactive');
     	gridView.removeClass('storeLocator-viewtype-active');
     };
     vm.showGrid = function(){
     	if(!vm.map_grid){
     		return;
     	}
     	vm.map_grid = false;
     	var mapView = angular.element( document.querySelector( '#mapView' ) );
     	mapView.addClass('storeLocator-viewtype-inactive');
     	mapView.removeClass('storeLocator-viewtype-active');
     	var gridView = angular.element( document.querySelector( '#gridView' ) );
     	gridView.addClass('storeLocator-viewtype-active');
     	gridView.removeClass('storeLocator-viewtype-inactive');
     };
     function findWareHouseLocations(){
     	var locator= vm.locator,state=vm.state,district=vm.district;
     	vm.warehouse = false;
     	if(locator!='store'){
     		vm.warehouse = true;
     	}
     	var findLocators=angular.extend({},{
     		storeType:locator,
     		state:state,
     		district:district,
     		pincode:"null",
     	});
     	setupAllSearchService.storeinfo = findLocators;
     	setupAllSearchService.isWareHouse = vm.warehouse;
     	callWareHouseLocationsDetails(findLocators).then(processWareHouseLocationsResponse);
     }
     function callWareHouseLocationsDetails(findLocators){
     	return setupAllSearchService.getAllWareHouseLocationsDetails(findLocators);
     }
     function processWareHouseLocationsResponse(response){
     	//console.log(response);
     	setupAllSearchService.storesLocation =response;
     	$state.go('storeLocator');
     	//alert('hello');
     }
	
}]);
});