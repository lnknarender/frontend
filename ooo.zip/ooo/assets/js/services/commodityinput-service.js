/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("commodityInputService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return	{
			
			createCommodityInputRequest:function(request){
		      	  var url = urlService.createCommodityInputUrl();
		            return ajaxService.doPost(url, {},request);
		      },
		      updateCommodityInputRequest:function(request){
		      	  var url = urlService.updateCommodityInputUrl();
		            return ajaxService.doPost(url, {},request);
		      },
		      deleteCommodityInputRequest:function(request){
		      	  var url = urlService.deleteCommodityInputUrl();
		            return ajaxService.doPost(url, {},request);
		      },
		     getCommodityInputRequest:function(request){
		      	  var url = urlService.getCommodityInputUrl();
		            return ajaxService.doGet(url,request);
		      }
		};
	}]);
    
	return services;
});