/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("setupAllSearchService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return	{
			   getAllSearchDetails: function (req) {
		            var deferred = $q.defer(); /*searchDetail = stateService.get(constants.STATE_SEARCH_DETAILS);

		            if (searchDetail) {
		                deferred.resolve(searchDetail);
		            } else {*/
		                var url = urlService.getSearchDataUrl();

		                var searchDetailsResponse = ajaxService.doGet(url,req);

		               searchDetailsResponse.then(function (result) {
		                	
		                    stateService.set(constants.STATE_ALL_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		            //}

		            return deferred.promise;
		        },
		        getFullDataSearchDetails :function (req) {
		            var deferred = $q.defer();
		                var url = urlService.getFullDataSearchUrl();

		                var searchDetailsResponse = ajaxService.doGet(url, req);

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.STATE_FULL_DATA_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            

		            return deferred.promise;
		        },
		        getAllWareHouseLocationsDetails:function(findLocators){
		        	   var deferred = $q.defer();

		               
		                   var url = urlService.getWareHouseLocationsUrl();

		                   var searchDetailsResponse = ajaxService.doGet(url,findLocators);

		                  searchDetailsResponse.then(function (result) {
		                   
		                       stateService.set(constants.STATE_WARE_HOUSE_DETAILS, result);
		                       deferred.resolve(result);
		                   },
		                   function (errorResult) {
		                      deferred.reject(errorResult);
		                   });
		               

		               return deferred.promise;
		        },
		        getAutoCompleteDetails :function (request) {
		                    	var deferred = $q.defer()
		                var url = urlService.getAutoCompleteUrl();

		                var searchDetailsResponse = ajaxService.doGet(url, request);

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.STATE_AUTO_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            

		            return deferred.promise;
		        },
		        getStatesDetails:function(request){
		        	var deferred = $q.defer();
		                var url = urlService.getStateDetailsUrl();
		//console.log(url);
		                var searchDetailsResponse = ajaxService.doGet(url, request);

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.STATE_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            

		            return deferred.promise;
		        },
		        getDistrictDetails:function(request){
		        	var deferred = $q.defer();
		                var url = urlService.getDistrictDetailsUrl();

		                var searchDetailsResponse = ajaxService.doGet(url, request);

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.DISTRICT_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            

		            return deferred.promise;
		        },
		        callHitCounts:function(){
		        	var deferred = $q.defer();
		            var url = urlService.hitsUrl();

		            var searchDetailsResponse = ajaxService.doGet(url);

		           searchDetailsResponse.then(function (result) {
		            
		                deferred.resolve(result);
		            },
		            function (errorResult) {
		               deferred.reject(errorResult);
		            });
		        

		        return deferred.promise;
		    },
		    getProductDetails:function(request){
		    	var deferred = $q.defer();
		        var url = urlService.getProductDetailsUrl();

		        var searchDetailsResponse = ajaxService.doGet(url,request);

		       searchDetailsResponse.then(function (result) {
		        
		            deferred.resolve(result);
		        },
		        function (errorResult) {
		           deferred.reject(errorResult);
		        });
		    

		    return deferred.promise;
		},
		signOutDetails:function(request){
	    	var deferred = $q.defer();
	        var url = urlService.signOutURL();

	        var searchDetailsResponse = ajaxService.doGet(url,request);

	       searchDetailsResponse.then(function (result) {
	        
	            deferred.resolve(result);
	        },
	        function (errorResult) {
	           deferred.reject(errorResult);
	        });
	    

	    return deferred.promise;
	},
	
	getBestSellingProducts:function(request){
    	var deferred = $q.defer();
        var url = urlService.getBestSellingProductsUrl();

        var searchDetailsResponse = ajaxService.doGet(url,request);

       searchDetailsResponse.then(function (result) {
        
            deferred.resolve(result);
        },
        function (errorResult) {
           deferred.reject(errorResult);
        });
    

    return deferred.promise;
}
	
	
		};
	}]);
    
	return services;
});