'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("homePageCtrl", ['$scope', '$rootScope','$state', '$translate','stateService','setupAllSearchService','$window','$timeout','$uibModal','homepageService','farmInputService','loginService', 'utilityService', '$sessionStorage', function($scope,$rootScope,$state, $translate,stateService,setupAllSearchService,$window,$timeout,$uibModal,homepageService,farmInputService, loginService, utilityService,$sessionStorage) {
    var vm = this;
    $scope.userInfo = loginService.getUserInfo();
    
    stateService.set(constants.STATE_USER_ACTION,constants.HOME_ACTION);
	vm.translatePg=function(language){
		var prevLang = vm.select_lang; 
		angular.element('#'+prevLang).removeClass(prevLang+'-active');
		angular.element('#'+prevLang).addClass(prevLang);
		$translate.use(language);
		angular.element('#'+language).removeClass(language);
		angular.element('#'+language).addClass(language+'-active');
		vm.select_lang=language;
	};
	
	vm.select_lang="eng";
	//angular.element('#logined_user').hide();
	vm.missCallHandler = function(){
		$uibModal.open({
		      animation: $scope.animationsEnabled,
		      templateUrl: 'assets/templates/header/missCall.html',
		      controller: 'missCallCtrl',
		      controllerAs:'vm'
		    });
	}
	
	vm.setUserDetails = function(vm,data) {
 		angular.element('#loginuser').hide();
 		angular.element('#loginuserdevide').hide();
        angular.element('#signuser').hide();
        angular.element('#userLoggedIn').show();
        angular.element('#signeduser').text([constants.HELLO,data.fullName].join(" "));

        var prdLen= utilityService.isCheckEmptyArray(data.productsIDS) ? data.productsIDS.length : 0;
		angular.element('#cartcounterlist').text(prdLen);
		  
		/*//Session//
		stateService.set(constants.USER_CART_DETAILS_AFTER_LOGIN,data.productsIDS);
		stateService.set(constants.STATE_USER_STATUS,data.progress);
		stateService.set(constants.STATE_USER_STATUS_VALUE,data.status);
		stateService.set(constants.USER_SHIPPING_ADDRESS,data.shippingAddress);
		*/
 	}
	
	if($scope.userInfo) {
		vm.setUserDetails(vm,$scope.userInfo);
	}
	
	vm.offersHandler = function(){
		$state.go('offers');
	   }
    vm.loginHandler= function(){
 	   $state.go('login');
    };
    vm.signUpHandler= function(){	
 	   $state.go('userRegistration');
    };
    vm.walletHandler = function(){
    	$state.go('wallet');
    };
    vm.signOutHandler = function(){
    	$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
    	callSignOutDetails().then(processSignOutResponse);
    };
    function callSignOutDetails(){
    	return setupAllSearchService.signOutDetails();
    }
    function processSignOutResponse(response){
    	 angular.element('#loginuser').show();
   	  angular.element('#loginuserdevide').show();
   	  angular.element('#signuser').show();
   	  angular.element('#userLoggedIn').hide();
   	  angular.element('#signeduser').text("");
   	  //angular.element('#logoutuser').text("");angular.element('#userLoggedIn').show();
   	  //angular.element('#signedinuserdevide').hide();
   	  angular.element('#cartcounterlist').text(0);
  // 	stateService.set(constants.STATE_TOKEN,'');
   	  stateService.reset();
   	  loginService.logout();
   	  $rootScope.dataLoading = false;
   	  $rootScope.dataStillLoading = false;
   	  $state.go('start');
    }
    vm.adminHandler = function(){
    	$state.go('admin',{"id":"welcome"},{reload:true});
    }
    //submit demand handler
    vm.submitDemandHandler= function(){	
    	stateService.set(constants.STATE_USER_ACTION,constants.SUBMIT_DEMAND);
    	//get username
    	 var userName= $scope.$parent.userInfo.userName; //$scope.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
    	 //if user is not logged in navigate to login page, else to submit demad page
	    	if(userName===null||userName===undefined ||userName===""){		
	    			$state.go('login');
	    		
	    	}else{
	    		  $state.go('submitDemand');
	    	}
 	   
    };
    
    
    vm.sellCommaditiesHandler= function(){	
 	   $state.go('sellCommodities');
    };
    vm.downloadAppHandler= function(){	
 	   $state.go('downloadApp');
    };
    vm.userAccountHandler= function(){
 	   angular.element("#useraccountdropdown").hide();
 	   $state.go('useraccount');
    };
    vm.userOrdersHandler= function(){	
    	
  	   $state.go('orders');
     };
    vm.homePageHandler = function(){
 	   $state.go('start');
    };
    vm.aboutUsHandler = function(){
 	   $state.go('aboutUs');
    };
    vm.cropsHandler = function(){
 	   $state.go('crops');
    };
    vm.inputsHandler = function(){
    	farmInputService.farmInputDetail=true;
    	stateService.set(constants.STATE_USER_ACTION,constants.FARM_INPUTS);
    	//get username
    	 var userName=  $scope.$parent.userInfo.userName;
    	 //if user is not logged in navigate to login page, else to submit demad page
	    	if(userName===null||userName===undefined ||userName===""){		
	    			$state.go('login');
	    		
	    	}else{
	    		  $state.go('mylisting');
	    	}
    };
    vm.faqHandler = function(){
 	   $state.go('faq');
    };
    vm.contactUsHandler = function(){
 	   $state.go('contactUs');
    };
    vm.comingSoonHandler = function(){
 	   $state.go('knowMore');
    };
    vm.userWishlistHandler=function(){
    	$state.go('wishlist');
    }
    vm.userDemandsHandler=function(){
    	$state.go('demands');
    }
    vm.intialize = function(){
    	jssor_1_slider_init();
    }
    
    	init();
		vm.storeLocatorHandler=storeLocatorHandler;
		vm.inputFarmHandler=inputFarmHandler;
		//vm.viewAllEquipments=viewAllEquipments;
		vm.viewAllCommodities=viewAllCommodities;
		vm.viewAllInputFarms=viewAllInputFarms;
		vm.viewAllEquipments = viewAllEquipments;
		vm.onkeyPress =onkeyPress;
		vm.buyFinancingHanlder=buyFinancingHanlder;
		vm.checkForApprovalHanlder =checkForApprovalHanlder;
		vm.sellCommoditiesHanlder=sellCommoditiesHanlder;
		vm.freebiesHanlder=freebiesHanlder;
		vm.specialAuctionsHandler=specialAuctionsHandler;
		vm.findStoreOrWarhouseHandler=findStoreOrWarhouseHandler;
		vm.findWareHouseLocations=findWareHouseLocations;
		vm.submitUserOffer = submitUserOffer;
		
		function submitUserOffer()
		{
			angular.element('#alreadyoffer').hide();
			angular.element('#successoffer').hide();
			angular.element('#entervalue').hide();
			if(vm.offerEmail!=null||vm.offerPhoneNumber!=null)
		    {
			
			 var userInfo = angular.extend({},{
        		 emailId:vm.offerEmail,
        		 phoneNo:vm.offerPhoneNumber
        	 });
			 
			 return callHomeOffer(userInfo).then(processHomeOffer);
		    }
			else{
				angular.element('#entervalue').show();
			}
		}
		
		function callHomeOffer(userInfo)
		{
			return homepageService.homeOfferService(userInfo);
		}
		
		function processHomeOffer(response)
		{
			if(response.body.applicationStatusCode===1035){
				vm.offerEmail=null;
				vm.offerPhoneNumber=null;
				angular.element('#successoffer').show();
			}
			else
				{
				  angular.element('#alreadyoffer').show();
				}
		}
		
		
		vm.cartHandler=function(){
		 	 stateService.set(constants.STATE_USER_ACTION,"homecartdetails");
		 	 // stateService.set(constants.STATE_USER_ACTION,constants.CART_DETAILS);
		 	  var userName= $scope.$parent.userInfo.userName; //$scope.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
		    	if(userName===null||userName===undefined ||userName===""){		
		    			$state.go('login');
		    		
		    	}else{
		    	 $state.go('myCart',{},{reload:true});
		    	}
		    };
		vm.advSearchClick = advSearchClick;
		vm.state="";
		vm.district="";
		vm.searchFields = "Farm Input";
		vm.onStateChange=onStateChange;
		vm.showUserDropDown=showUserDropDown;
		vm.hideUserDropDown=hideUserDropDown;
		
		function showUserDropDown(){
			angular.element("#useraccountdropdown").show();
		}
		
		function hideUserDropDown(){
			angular.element("#useraccountdropdown").hide();
		}
		
		function viewAllInputFarms(){
			/*setupAllSearchService.type="farminputs";
			var request=angular.extend({},{
				type:'farminput'
			});
			callSearchDetails(request).then(processFarmInputResponse);*/
			$state.go('advancedsearchdetails',{"srchtxt":'',"type":'Farm Input',"catlevel":false},{reload:true});
	   };
	   function viewAllEquipments(){
	    	$state.go('advancedsearchdetails',{"srchtxt":'',"type":'Equipment',"catlevel":false},{reload:true});
	    };
	function processFarmInputResponse(response){
 	   setupAllSearchService.allProductDetails =response;
       	$state.go('advancedsearchdetails');
    }
   function cartHandler(){
 	 stateService.set(constants.STATE_USER_ACTION,"homecartdetails");
 	 // stateService.set(constants.STATE_USER_ACTION,constants.CART_DETAILS);
 	  var userName = $scope.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
    	if(userName===null||userName===undefined ||userName===""){		
    			$state.go('login');
    		
    	}else{
    	 $state.go('myCart',{},{reload:true});
    	}
    }

	function advSearchClick(){
		var srchText = angular.element('#srchtxt').val();
		/*var request=angular.extend({},{
			searchText:srchText,
			type:vm.searchFields
		});
		callSearchDetails(request).then(processAdvancedSearchResponse);*/
		vm.searchFields=angular.element('.srchDrpDown').val();
		$state.go('advancedsearchdetails',{"srchtxt":srchText,"type":vm.searchFields,"brands":null,"grades":null,"prices":null,"catlevel":false},{reload:true});
	};
		function buyFinancingHanlder(){
			$state.go('buyFinancing');
		}
		function checkForApprovalHanlder(){
			$state.go('login');
		}
		function sellCommoditiesHanlder(){
			$state.go('sellCommodities');
		}
		function freebiesHanlder(){
			$state.go('freebies');
		}
		function specialAuctionsHandler(){
		}
		function findStoreOrWarhouseHandler(){
		}
		function callAtDistrcitTimeout() {
			//vm.district=setupAllSearchService.storeinfo.district;
			//setupAllSearchService.storeinfo={};
		}
		function callAtTimeout() {
			vm.state=setupAllSearchService.storeinfo.state ;
			
			$timeout(callAtDistrcitTimeout, 100);
		}
		function setDefaultValues(){
			angular.element("#srchtxt").val('');
			angular.element("#srchDrpDown").val('Farm Input');
			$('input:radio[name="radioGroup"][value="ST"]').prop('checked', true);
			angular.element("#state").val('');
			angular.element("#district").val('');
		}
    function init() {
         vm.waitingForPageToLoad = false;
         setDefaultValues();
        // callHitCounts().then(processCountResponse);
         if(setupAllSearchService.storeinfo!=null||setupAllSearchService.storeinfo!=undefined){
        	  vm.statesList=setupAllSearchService.statesList ;
        	  vm.locator=setupAllSearchService.storeinfo.storeType;
        	  vm.districtList =setupAllSearchService.districtList;
        	  $timeout(callAtTimeout, 100);
              vm.storesLocation= setupAllSearchService.storesLocation;
              vm.warehouse = setupAllSearchService.isWareHouse;
              vm.storeDetails = true;
         }else{
        	 vm.locator="ST";
        	 vm.storeDetails = false;
        	 var request= angular.extend({},{
         		type:"Farm Input"
         	});
        	 callFullDataDetails(request).then(processFullDataSearchResponse);
        	 var request1= angular.extend({},{
          		type:"Equipment"
          	});
         	 callFullDataDetails(request1).then(processEquipmentDataSearchResponse);
        	 callStateDetails().then(processStateDataResponse);
         }
         //categorySlider();
         carousalControl();
         changeCurrentSelector();
         $('[data-toggle="popover"]').popover();
     }
    function changeCurrentSelector(){
    	if($rootScope.currentSelector==undefined){
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}else{
    		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}
    	$rootScope.currentSelector = $rootScope.toState.name;
    }
    function carousalControl(){
    	
    	    // init carousel
    	    $('.carousel').carousel({
    	        pause: true,        // init without autoplay (optional)
    	        interval: false,    // do not autoplay after sliding (optional)
    	        wrap:false          // do not loop
    	    });
    	    // init carousels with hidden left control:
    	    $('.carousel').children('.left.carousel-control').hide();
   	

    	// execute function after sliding:
    	$('.carousel').on('slid.bs.carousel', function () {
    	    // This variable contains all kinds of data and methods related to the carousel
    	    var carouselData = $(this).data('bs.carousel');
    	    // get current index of active element
    	    var currentIndex = carouselData.getItemIndex(carouselData.$element.find('.item.active'));

    	    // hide carousel controls at begin and end of slides
    	    $(this).children('.carousel-control').show();
    	    if(currentIndex == 0){
    	        $(this).children('.left.carousel-control').hide();
    	    }else if(currentIndex+1 == carouselData.$items.length){
    	        $(this).children('.right.carousel-control').hide();
    	    }
    	});
    }
    function categorySlider(){
    	$('.regular').slick({
    		dots: false,
    		infinite: false,
    		speed: 300,
    		slidesToShow: 2,
    		slidesToScroll: 2
    	});
    }
    function callHitCounts(){
 	   return setupAllSearchService.callHitCounts();
    } 	
    function processCountResponse(response){
 	 vm.counter =  response.body.data;
    }
    function callStateDetails(){
    	return setupAllSearchService.getStatesDetails();
    }
    function processStateDataResponse(response){
    	var body = response.body||{};
    	vm.statesList = body.data;
    	setupAllSearchService.statesList =vm.statesList;
    	//console.log(vm.statesList);
    }
    function onStateChange(){
 		vm.districtList=null;
    	var request= angular.extend({},{
    		stateName:vm.state
    	});
    	 callDistrictDetails(request).then(processDistrictResponse);
    }
    function callDistrictDetails(request){
    	return setupAllSearchService.getDistrictDetails(request);
    }
    function processDistrictResponse(res){
    	var data= res.body.data;
    	vm.districtList=data;
    	setupAllSearchService.districtList =vm.districtList;
		vm.district="";

    	
    }
    function onkeyPress($event){
    	if ($event.which === 13){
    		 var free_text= angular.element('#free_text');
    		 callSearchDetails(free_text.val()).then(processFullDataSearchResponse);
    	}
    	  
    	}
    function inputFarmHandler(productId){
    	$sessionStorage["fromWhere"] = "homepageaddtocart";
 	   	stateService.set(constants.PRODUCT_DISABLE_ADD_CARD,"homepageaddtocart");
    		setupAllSearchService.productId=productId;
    		setupAllSearchService.quantity=null;
			setupAllSearchService.recommendedProductDetails=vm.allFarmInputs;
    		$state.go('productdetails',{"id":productId});
    }
    function callSearchDetails(req) {
        vm.waitingForPageToLoad = true;
        /*var searchText = angular.extend({},{
        	searchText:free_text
			});*/
        return setupAllSearchService.getAllSearchDetails(req);
    };
    function callFullDataDetails(req) {
        vm.waitingForPageToLoad = true;

        return setupAllSearchService.getFullDataSearchDetails(req);
    };
    function processFullDataSearchResponse(changeDetailsResponse) {
    	vm.allFarmInputs =changeDetailsResponse;
    	vm.farmInputsInitial=[];
    	vm.farmInputsMiddle=[];
    	vm.farmInputsLast=[];
    	var store= connection.storeImage+"";
    	for(var i=0,len=vm.allFarmInputs.length;i<len;i++){
    		vm.allFarmInputs[i].product_img_path = store+vm.allFarmInputs[i].product_img_path;
    		if(i<2){
    			vm.farmInputsInitial.push(vm.allFarmInputs[i]);
    		}else if(i<4){
    			vm.farmInputsMiddle.push(vm.allFarmInputs[i]);
    		}else if(i<6){
    			vm.farmInputsLast.push(vm.allFarmInputs[i]);
    		}
    	}
    	$scope.$watch(vm.farmInputsLast, $scope.updateFarmInputCarousel, true);
    };
    
    $scope.updateFarmInputCarousel = function() {
    	var _carouselFarmInpuContainer = $('.carousel-inner.carousel-farminputlist');
    	if (_carouselFarmInpuContainer.children('.item').length < 2){
    		_carouselFarmInpuContainer.siblings('.carousel-control, .carousel-indicators').hide();
    	} else {
    		_carouselFarmInpuContainer.siblings('.carousel-control, .carousel-indicators').show();
    	}
	    $('.carousel').children('.left.carousel-control').hide();
    }
    
    function processEquipmentDataSearchResponse(equipmentResponse){
    	vm.allEquipments =equipmentResponse;
    	vm.equipmentsInitial=[];
    	vm.equipmentsMiddle=[];
    	vm.equipmentsLast=[];
    	var store= connection.storeImage+"";
    	for(var i=0,len=vm.allEquipments.length;i<len;i++){
    		vm.allEquipments[i].product_img_path = store+vm.allEquipments[i].product_img_path;
    		if(i<2){
    			vm.equipmentsInitial.push(vm.allEquipments[i]);
    		}else if(i<4){
    			vm.equipmentsMiddle.push(vm.allEquipments[i]);
    		}else if(i<6){
    			vm.equipmentsLast.push(vm.allEquipments[i]);
    		}
    	}
    	$scope.$watch(vm.equipmentsLast, $scope.updateEquipCarousel, true);
    }
    
    $scope.updateEquipCarousel = function() {
    	var _carouselEquipContainer = $('.carousel-inner.carousel-equipmentlist');
    	if (_carouselEquipContainer.children('.item').length < 2){
    		_carouselEquipContainer.siblings('.carousel-control, .carousel-indicators').hide();
    	} else {
    		_carouselEquipContainer.siblings('.carousel-control, .carousel-indicators').show();
    	}
	    $('.carousel').children('.left.carousel-control').hide();
    }
    
    /*function processAdvancedSearchResponse(response) {
	      	setupAllSearchService.allProductDetails =response;
	       	if($state === "advancedsearchdetails"){
	       		$rootScope.$emit("CallParentMethod", {});
	       	}else{
	       		$state.go('advancedsearchdetails');	
	       	}
    };*/ 
    
    
    function viewAllCommodities(){
    	
    };
 
		/*StoreLocatorCode*/
    
    function storeLocatorHandler(){
			 if (navigator.geolocation){
	             navigator.geolocation.getCurrentPosition(onSuccess);
	         }else{
	            alert("Geolocation API not supported.");
	         }
		}
    
    function findWareHouseLocations(){
    	var locator= vm.locator,state=vm.state,district=vm.district;
    	if(state==="" && district===""){
    		vm.selectLocations=true;
    		return true;
    	}else{
    		vm.selectLocations=false;
    	}
    	if(vm.state!==undefined&&vm.district!==undefined){
    		//debugger;
    		/*var elementPos = vm.districtList.map(function(item) {return item.districtId; }).indexOf(district), 
    		 	objectFound = vm.districtList[elementPos];*/ 
    		
    		//console.log(elementPos, objectFound); 
    		var  _district=district===""?null:district; // TO-DO: un-comment this once Backend code changed to accept id instead of name...
    		district!="" ? $state.go('storeLocator',{"state":state,"district":_district,"type":locator},{reload:true}) : $state.go('storeLocator1',{"state":state,"type":locator},{reload:true});
    		//var  _district=district===""?null:objectFound.districtName;
    		//objectFound !== undefined ? $state.go('storeLocator',{"state":state,"district":_district,"type":locator}) : $state.go('storeLocator1',{"state":state,"type":locator}); 
    	}
    	
    }
   
}]);
});