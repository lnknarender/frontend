/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("forgetPasswordService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return	{
			callForgetPassword:function(loginName){
	        	 var url = urlService.forgetPasswordUrl();
	             return ajaxService.doPost(url,{}, loginName);
	        },
	        callChangePassword:function(secureUser){
	       	 var url = urlService.changePasswordUrl();
	            return ajaxService.doPost(url, {},secureUser);
	       },
	       submitOtpNumberUrl:function(secureUser){
	         	 var url = urlService.callOtpNumberUrl();
	             return ajaxService.doGet(url,secureUser);
	        },
	        generateOTPUrl:function(secureUser){
	         	 var url = urlService.generateOTPUrl();
	             return ajaxService.doGet(url,secureUser);
	        }
		};
	}]);
    
	return services;
});