
/*
 * Define Angular app.directives module
 */
define(['angular'], function (angular) {
    
    var module =  angular.module('app.constants', []);
	
    module.config(['$provider',function($provider){
	
        module._constant = module.constant;
	
        module.constant = function(name, factory) {
            $provider.constant( name, factory );
            return( this );
        };
	
    }]);
  	

	return module;	
});