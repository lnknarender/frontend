/**
 * advance search which will search based on the filter and displays all the product 
 */
'use strict';

define(['angular',
    'controllers-module',
    'underscore'
], function(angular, controllers, underscore) {

    // Add Attribute Controller
    controllers.controller("AdvancedSearchCtrl", ['$scope', '$rootScope', '$state', 'setupAllSearchService', 'stateService', 'utilityService', '$stateParams', 'setupAdvancedSearchService', '$timeout', '$sessionStorage', '$q', function($scope, $rootScope, $state, setupAllSearchService, stateService, utilityService, $stateParams, setupAdvancedSearchService, $timeout, $sessionStorage, $q) {
        var vm = this;
        var categorySet = new Array();
        init();
        /*vm.EnterInPinCodeField = EnterInPinCodeField;*/
        vm.pinCodeValidate = pinCodeValidate;
        vm.advSearchClick = advSearchClick;
        vm.productDtlsResp = productDtlsResp;
        vm.viewAll = viewAll;
        vm.watchOnCategoryChange = watchOnCategoryChange;
        vm.parentCheckChange = parentCheckChange;
        vm.prepareFilterRequestObject = prepareFilterRequestObject;
        vm.pinStateValidate = pinStateValidate;
        var farmInputPriceRange = [{
            Name: "300 and below",
            value: "0 TO 300"
        }, {
            Name: "301 - 500",
            value: "301 TO 500"
        }, {
            Name: "501 - 900",
            value: "501 TO 900"
        }, {
            Name: "901 and above",
            value: "901 TO *"
        }];

        var equipmentPriceRange = [{
            Name: "10000 and below",
            value: "0 TO 10000"
        }, {
            Name: "10001 - 50000",
            value: "100001 TO 50000"
        }, {
            Name: "50001 - 100000",
            value: "50001 TO 100000"
        }, {
            Name: "100001 and above",
            value: "100001 TO *"
        }]
        function init() {
            vm.haveSubCats = true;
            vm.showPinInvalidMsg = false;
            $scope.loading = true;
            $rootScope.dataLoading = true;
            $rootScope.dataStillLoading = true;
            vm.waitingForPageToLoad = false;
            vm.season = "";
            vm.prodDisplay = true;
            vm.showViewALL = true;
            vm.searchQueryDisplay = true;
            vm.searQuery = $stateParams.srchtxt;
            if (!$stateParams.srchtxt || $stateParams.srchtxt == '') {
                vm.searchQueryDisplay = false;
            }

            vm.searchFields = $stateParams.type;
            vm.priceRange = [];
            var request = angular.extend({}, {
                searchText: vm.searQuery,
                type: vm.searchFields
            });

            //varibale required for Filter search
            vm.sortField = "";
            vm.selectedPriceRange = [];
            vm.selectedCatList = [];
            vm.selectedBrands = [];
            vm.selectedGrades = [];
            vm.selection = {
                brands: {},
                grades: {},
                price: {}

            };
            vm.rowcount = 10;
            vm.start = 0;
            vm.rows = vm.rowcount;
            vm.filterListData = {};
            if ($sessionStorage['stateList']) {
                vm.statesList = angular.copy($sessionStorage['stateList']);
            } else {
                $scope.request2 = callStateDetails();
                $scope.request2.then(processStateDataResponse);
            }
            if ($sessionStorage['filterlist']) {
                getFilterListFromSession();
            } else {
                $scope.request1 = callListFilter();
                $scope.request1.then(processFilterList);
            }

           

            $scope.request3 = callAttributeFilterList();
            $scope.request3.then(processAttributeFilterList);
            $q.all([$scope.request1, $scope.request2, $scope.request3]).then(function(values) {
                $rootScope.dataLoading = false;
                $rootScope.dataStillLoading = false;
            });
            changeCurrentSelector();
        }
        function changeCurrentSelector(){
        	var presentSelector = $stateParams.type;
        	if($rootScope.currentSelector==undefined){
        		angular.element("#"+presentSelector).addClass('currentSelected');
        	}else{
        		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
        		angular.element("#"+presentSelector).addClass('currentSelected');
        	}
        	$rootScope.currentSelector = presentSelector;
        }
        function pinCodeValidate() {
            if ($scope.pinForm.pin.$valid && !$scope.pinForm.pin.$pristine) {
                if ($sessionStorage['filterPinCode'] != vm.pinCodefilter)
                    $sessionStorage['filterPinCode'] = -1;
                pinStateValidate();
            }
        }
        /*function EnterInPinCodeField(event){
    	 if(event.which === 13){
    		 vm.pinCodeValidate();
    	 }
     }*/
        function callAttributeFilterList() {
            if ($stateParams.sp == "true" || $stateParams.bs == "true")
                var level1 = "*";
            else
                var level1 = $stateParams.level;
            var request = {
                category: $stateParams.type,
                level1: level1,
                pin: vm.pinCodefilter,
                season: vm.season,
                state_id: vm.filterstateID
            };
            return setupAdvancedSearchService.getAttributeFilterList(request);
        }

        function callStateDetails() {
            return setupAllSearchService.getStatesDetails();
        }

        function processStateDataResponse(response) {
            var body = response.body || {};
            vm.statesList = body.data;
            setupAllSearchService.statesList = vm.statesList;
            //console.log(vm.statesList);
        }

        function getFilterListFromSession() {
            vm.filterListData = angular.copy($sessionStorage['filterlist']);
            $timeout(function() {
                angular.element(".srchDrpDown").val($stateParams.type);
                angular.element("#srchtxt").val($stateParams.srchtxt)
            }, 100);
            if ($stateParams.type != "*") {
                vm.categories = $stateParams.type;
                watchOnCategoryChange(vm.categories);
            }
        }

        function parentCheckChange(item) {
        	if(item.isChecked == false){
            	for (var i in item.subCategory) {
                    item.subCategory[i].isChecked = false;
                    if (item.subCategory[i].subCategory) {
                        vm.parentCheckChange(item.subCategory[i]);
                    }
                }
            }
        }

        function advSearchClick() {
            var srchText = angular.element('#srchtxt').val();
            vm.searchFields = angular.element('.srchDrpDown').val();
            $state.go('advancedsearchdetails', {
                "srchtxt": srchText,
                "type": vm.searchFields,
                "brands": null,
                "grades": null,
                "prices": null,
                "catlevel": false
            }, {
                reload: true
            });
        };

        function pinStateValidate() {
        	 vm.locationFilterError = false;
             if (vm.locationfilter && vm.locationfilter.toString().trim().length > 0) {   
                 var pinPattern = new RegExp("^[0-9]{6}$");
                if(pinPattern.test(vm.locationfilter)){
             	   vm.pinCodefilter = vm.locationfilter;
             	   vm.filterstateID = null;
             	   prepareFilterRequestObject();
                }else{
             	   var state = vm.statesList.filter(function(value){
             		   return value.stateName.toLowerCase() == vm.locationfilter.toLowerCase();
             	   });
             	   
             	   if(state.length>0){
             		   vm.pinCodefilter = null;
                 	   vm.filterstateID = state[0].stateId;
                 	   prepareFilterRequestObject();
             	   }else{
             		   vm.locationFilterError = true;
             	   }
                }
                 //callVerifyPinWithState(vm.pinCodefilter).then(processWhizapiResponse);
             } else {
             	vm.pinCodefilter = null;
             	vm.filterstateID = null;
                 prepareFilterRequestObject();
             }
        }

        function prepareFilterRequestObject() {
            $rootScope.dataLoading = true;
            $rootScope.dataStillLoading = true;
            if ($sessionStorage['filterStateId'] != vm.filterstateID)
                $sessionStorage['filterStateId'] = -1;

            var bs = false;
            var sp = false;
            if ($stateParams.sp == "true") {
                sp = true;
            }
            if ($stateParams.bs == "true") {
                bs = true;
            }
            vm.showPinInvalidMsg = false;
            
            
            $scope.loading = true;
            $scope.attrRequest = callAttributeFilterList();
            $scope.attrRequest.then(processAttributeFilterList);
         

            $q.all([$scope.attrRequest]).then(function(values) {
                $rootScope.dataLoading = false;
                $rootScope.dataStillLoading = false;
                prepareBrands();
                prepareGrades();
                preparePriceRange();
                var catArray = [];
                categorySet.forEach(function(value) {
                    if (catArray.indexOf(value) === -1)
                        catArray.push(value);
                });
                vm.start = 0;
                if (vm.rowcount != 0)
                    vm.rows = vm.rowcount;
                prepareCategoryLevelObject();
                var requestObject = {
                    category: vm.categories,
                    categoryLevelDTOs: vm.selectedCatList,
                    priceRange: vm.selectedPriceRange,
                    grades: vm.selectedGrades,
                    brands: vm.selectedBrands,
                    searchText: vm.searQuery,
                    start: vm.start,
                    rows: vm.rows + 1,
                    sortField: vm.sortField,
                    season: vm.season,
                    state_id: vm.filterstateID,
                    pin: vm.pinCodefilter,
                    bestSelling: bs,
                    sponsered: sp
                };
                $state.transitionTo('advancedsearchviewall', {
                    "srchtxt": vm.searQuery,
                    "type": vm.categories,
                    "level": $stateParams.level,
                    "brands": vm.selectedBrands,
                    "grades": vm.selectedGrades,
                    "prices": vm.selectedPriceRange,
                    "cats": catArray,
                    "sp": $stateParams.sp,
                    "bs": $stateParams.bs,
                    "pin": vm.pinCodefilter,
                    "state": vm.filterstateID,
                    "season": vm.season
                }, {
                    location: true,
                    inherit: true,
                    relative: $state.$current,
                    notify: false
                });

                callFilteredResult(requestObject).then(processAdvancedSearchResponse);
            });
        }

        function callVerifyPinWithState(pin) {
            $scope.loading = true;
            return setupAdvancedSearchService.verifyPinWithState(pin);
        }

        function processWhizapiResponse(response) {
            $scope.loading = false;
            if (response.ResponseCode === 0) {
                var state = response.Data[0].State;
                var stateId = vm.statesList.filter(function(v) {
                    return v.stateName == state;
                })[0].stateId.toString();
                if (stateId === vm.filterstateID) {
                    vm.showPinInvalidMsg = false;
                    prepareFilterRequestObject();
                } else {
                    vm.showPinInvalidMsg = true;
                }
            }
            if (response.ResponseCode === 20) {
                vm.showPinInvalidMsg = true;
            }

        }

        //ng-changeFunction
        function CategoryNodes(level1, level2, level3, level4) {
            this.level1 = level1;
            this.level2 = level2;
            this.level3 = level3;
            this.level4 = level4;
        }

        function LevelList(parent, child) {
            this.parent = parent;
            this.child = child;
        }

        vm.setSortCriteria = function(field) {
            vm.sortField = field;
            prepareFilterRequestObject();
        }
        vm.watchFunction = function() {
            prepareFilterRequestObject();
        }

        function getFlagCount(objectList) {
            var count = 0;
            objectList.forEach(function(value, index) {
                if (value.isChecked)
                    count++;
            });
            return count;
        }

        function prepareBrands() {
            vm.selectedBrands.splice(0, vm.selectedBrands.length);
            for (var brand in vm.selection.brands) {
            	var isObjectExist = vm.attributefilter[0].filterLists.filter(function(v) {
                    return v.name == brand;
                });
                if (vm.selection.brands[brand] && isObjectExist.length>0)
                    vm.selectedBrands.push(brand);
            }
        }

        function preparePriceRange() {
        	vm.selectedPriceRange.splice(0, vm.selectedPriceRange.length);
            for (var sprice in vm.selection.price) {
            	var isObjectExist = vm.priceRange.filter(function(v) {
                    return v.value == sprice;
                });
            	if (vm.selection.price[sprice] && isObjectExist.length>0)
                    vm.selectedPriceRange.push(sprice);
            }
        }

        function prepareGrades() {
            vm.selectedGrades.splice(0, vm.selectedGrades.length);
            for (var grade in vm.selection.grades) {
            	var isObjectExist = vm.attributefilter[1].filterLists.filter(function(v) {
                    return v.name == grade;
                });
                if (vm.selection.grades[grade] && isObjectExist.length>0)
                    vm.selectedGrades.push(grade);
            }
        }

        //Calling Filtered Result
        function callFilteredResult(requestObject) {
            console.log("***********************************" + requestObject)
            return setupAdvancedSearchService.getFilteredSearchDetails(requestObject);
        }

        //For filterList
        function callListFilter() {
            return setupAdvancedSearchService.getFilterList();
        }


        //For filterList response
        function processFilterList(response) {
            $sessionStorage['filterlist'] = angular.copy(response.body.data[0]);
            vm.filterListData = response.body.data[0];
            angular.element("#srchtxt").val($stateParams.srchtxt);
            angular.element(".srchDrpDown").val($stateParams.type);
            if ($stateParams.type != "*") {
                vm.categories = $stateParams.type;
                watchOnCategoryChange(vm.categories);
            }
        }

        function processAttributeFilterList(response) {
            vm.attributefilter = response;

            console.log(vm.attributefilter);
        }

        function prepareCategoryLevelObject() {
            //console.log(vm.subCategories);
            if (vm.subCategories != null) {
                categorySet.splice(0, categorySet.length);
                vm.selectedCatList.splice(0, vm.selectedCatList.length);
                var flagLevel1 = getFlagCount(vm.subCategories);
                var newflagLevel1 = flagLevel1;
                vm.subCategories.forEach(function(value, index) {
                    if (value.isChecked) {
                        categorySet.push(value.categoryId);
                        var level1 = value.categoryName;
                        var flagLevel2 = getFlagCount(value.subCategory);
                        var newflagLevel2 = flagLevel2;
                        value.subCategory.forEach(function(value, index) {
                            if (value.isChecked) {
                                categorySet.push(value.categoryId);
                                var level2 = value.categoryName;
                                var flagLevel3 = getFlagCount(value.subCategory);
                                var newflagLevel3 = flagLevel3;
                                value.subCategory.forEach(function(value, index) {
                                    if (value.isChecked) {
                                        categorySet.push(value.categoryId);
                                        var level3 = value.categoryName;
                                        var flagLevel4 = getFlagCount(value.subCategory);
                                        var newflagLevel4 = flagLevel4;
                                        value.subCategory.forEach(function(value, index) {
                                            if (value.isChecked) {
                                                categorySet.push(value.categoryId);
                                                var level4 = value.categoryName;
                                                if (flagLevel4 > 0 && newflagLevel4 == flagLevel4) {
                                                    vm.selectedCatList.push(new CategoryNodes(level1, level2, level3, level4));
                                                    flagLevel4--;
                                                    newflagLevel4--;
                                                    if (newflagLevel4 == 0) {
                                                        newflagLevel3--;
                                                        newflagLevel2--;
                                                        newflagLevel1--;
                                                    }
                                                }
                                                flagLevel4 = newflagLevel4;
                                            }
                                        });
                                        if (flagLevel3 > 0 && newflagLevel3 == flagLevel3) {
                                            vm.selectedCatList.push(new CategoryNodes(level1, level2, level3, ""));
                                            flagLevel3--;
                                            newflagLevel3--;
                                            if (newflagLevel3 == 0) {
                                                newflagLevel2--;
                                                newflagLevel1--;
                                            }
                                        }
                                        flagLevel3 = newflagLevel3;
                                    }
                                });
                                if (flagLevel2 > 0 && newflagLevel2 == flagLevel2) {
                                    vm.selectedCatList.push(new CategoryNodes(level1, level2, "", ""));
                                    flagLevel2--;
                                    newflagLevel2--;
                                    if (newflagLevel2 == 0) {
                                        newflagLevel1--;
                                    }
                                }
                                flagLevel2 = newflagLevel2;
                            }

                        });
                        if (flagLevel1 > 0 && newflagLevel1 == flagLevel1) {
                            vm.selectedCatList.push(new CategoryNodes(level1, "", "", ""));
                            flagLevel1--;
                            newflagLevel1--;
                        }
                        flagLevel1 = newflagLevel1;
                    }

                });
                //console.log(vm.selectedCatList);
            }
        }

        function callSearchDetails(req) {
            vm.waitingForPageToLoad = true;
            return setupAllSearchService.getAllSearchDetails(req);
        };

        function processAdvancedSearchResponse(response) {
            vm.productsList = response;
            var store = connection.storeImage;
            if (vm.productsList.length == 0) {
                vm.prodDisplay = false;
                vm.showViewALL = false;
            } else {
                vm.prodDisplay = true;
                vm.showViewALL = true;
            }
            if (vm.productsList.length > 0 && vm.productsList.length <= vm.rows) {
                vm.showViewALL = false;
                if (vm.productsList.length < 10) {
                    vm.rowcount = 10;
                }
            }

            if (vm.productsList.length != 0) {
                for (var i = 0; i < vm.productsList.length; i++) {
                    var discount = parseInt(vm.productsList[i].origo_discount) + parseInt(vm.productsList[i].vendor_discount);
                    var unit_price = parseInt(vm.productsList[i].unit_price);
                    var actual_discount = unit_price - unit_price * discount / 100;
                    vm.productsList[i].formattedPrice = actual_discount.toFixed(2);
                    vm.productsList[i].product_img_path = store + vm.productsList[i].product_img_path;
                }

            }
            if (vm.showViewALL)
                vm.productsList.splice(-1);

            angular.element("#srchtxt").val($stateParams.srchtxt);
            angular.element("#srchDrpDown").val($stateParams.type);
            $scope.loading = false;

        };

        function productDtlsResp(inputSearch) {
            setupAllSearchService.productId = inputSearch;
            setupAllSearchService.quantity = null;
            $sessionStorage["fromWhere"] = "advanceaddtocart";
            setupAllSearchService.recommendedProductDetails = vm.productsList;
            stateService.set(constants.PRODUCT_DISABLE_ADD_CARD, "advanceaddtocart");
            $state.go('productdetails', {
                "id": inputSearch
            });
        };

        function viewAll() {
            $rootScope.dataLoading = true;
            $rootScope.dataStillLoading = true;
            var bs = false;
            var sp = false;
            if ($stateParams.sp == "true") {
                sp = true;
            }
            if ($stateParams.bs == "true") {
                bs = true;
            }
            var currentProdLength = vm.productsList.length;
            prepareBrands();
            prepareGrades();
            preparePriceRange();
            prepareCategoryLevelObject();
            vm.start = vm.productsList.length;
            // vm.rows = vm.rowcount;
            var requestObject = {
                category: vm.categories,
                categoryLevelDTOs: vm.selectedCatList,
                priceRange: vm.selectedPriceRange,
                grades: vm.selectedGrades,
                brands: vm.selectedBrands,
                searchText: vm.searQuery,
                start: vm.start,
                rows: vm.rows + 1,
                sortField: vm.sortField,
                season: vm.season,
                state_id: vm.filterstateID,
                pin: vm.pinCodefilter,
                bestSelling: bs,
                sponsered: sp
            };
            var catArray = [];
            categorySet.forEach(function(value) {
                if (catArray.indexOf(value) === -1)
                    catArray.push(value);
            });
            //$sessionStorage['selected-subCat-viewall'] = vm.subsubCategory;
            $state.transitionTo('advancedsearchviewall', {
                "srchtxt": vm.searQuery,
                "type": vm.categories,
                "level": $stateParams.level,
                "brands": vm.selectedBrands,
                "grades": vm.selectedGrades,
                "prices": vm.selectedPriceRange,
                "cats": catArray,
                "sp": $stateParams.sp,
                "bs": $stateParams.bs,
                "pin": vm.pinCodefilter,
                "state": vm.filterstateID,
                "season": vm.season
            }, {
                location: true,
                inherit: true,
                relative: $state.$current,
                notify: false
            });

            callFilteredResult(requestObject).then(processFarmInputResponse);
        }

        function callSearchDetails(req) {
            return setupAllSearchService.getAllSearchDetails(req);
        };

        function processFarmInputResponse(response) {
            var store = connection.storeImage;
            vm.productsList = vm.productsList.concat(response);
            if (utilityService.isCheckEmpty(response) || response.length <= vm.rows) {
                vm.showViewALL = false;
            }
            if (vm.showViewALL) {
                vm.productsList.splice(-1);
                vm.rowcount += vm.productsList.length - 1;
            } else {
                vm.rowcount += vm.productsList.length;
            }

            if (response.length != 0) {
                for (var i = 0; i < response.length; i++) {
                    var discount = parseInt(response[i].origo_discount) + parseInt(response[i].vendor_discount);
                    var unit_price = parseInt(response[i].unit_price);
                    var actual_discount = unit_price - unit_price * discount / 100;
                    response[i].formattedPrice = actual_discount.toFixed(2);
                    response[i].product_img_path = store + response[i].product_img_path;
                }
            }
            $rootScope.dataLoading = false;
            $rootScope.dataStillLoading = false;
            console.log(vm.productsList);
        }

        function watchOnCategoryChange(catvalue) {
            if (vm.subsubCategory) {
                vm.subsubCategory.splice(0, vm.subsubCategory.length);
            } else {
                vm.subsubCategory = [];
            }

            vm.filterListData.categoryList.forEach(function(value, index) {
                if (catvalue == vm.filterListData.categoryList[index].categoryName) {
                    vm.subCategories = vm.filterListData.categoryList[index].subCategory;
                    vm.subCategories.forEach(function(subvalue, subindex) {
                        if (subvalue.categoryName == $stateParams.level) {
                            vm.subsubCategory = vm.subCategories[subindex].isChecked = true;
                            vm.subsubCategory = vm.subCategories[subindex].subCategory;
                            if (vm.subsubCategory.length === 0) {
                                vm.haveSubCats = false;
                            } else {
                                vm.haveSubCats = true;
                            }
                            vm.subCatName = subvalue.categoryName;
                            vm.subCatHeader = subvalue.categoryName;
                        }
                    });

                    if ($stateParams.sp == "true" || $stateParams.bs == "true") {
                        vm.subsubCategory = vm.subCategories;
                        vm.subCatName = angular.copy($stateParams.type);
                        vm.subCatHeader = $stateParams.level;
                    }
                    angular.element('.srchDrpDown').val(catvalue);

                }
            });

            $scope.attributeFilter = callAttributeFilterList();
            $scope.attributeFilter.then(processAttributeFilterList);
            $q.all([$scope.attributeFilter]).then(function() {
                getBrandsFromSession();
                getGradesFromSession();
                if(vm.categories =='Farm Input'){
               	 vm.priceRange = angular.copy(farmInputPriceRange);
               }else{
               	 vm.priceRange = angular.copy(equipmentPriceRange);
               }
                getPriceRangeFromSession();
            });
            getCategoriesfromSession()
           
            vm.season = $stateParams.season;
            if ($stateParams.state){
            	vm.locationfilter = vm.statesList.filter(function(value){
         		   return value.stateId == $stateParams.state;
         	   })[0].stateName;
            	pinStateValidate();
            }
                //vm.filterstateID = $stateParams.state;
            if ($stateParams.pin){
            	vm.locationfilter = $stateParams.pin;
            	pinStateValidate();
            }
            prepareFilterRequestObject();
        }

        function checkSubcat(item) {
            for (var i in item.subCategory) {
                if (item.subCategory[i].categoryName == $stateParams.level) {
                    item.subCategory[i].isChecked = true;
                    if (item.subCategory[i].subCategory) {
                        parentCheckChange(item.subCategory[i]);
                    }
                }
            }
        };

        function getBrandsFromSession() {
            if ($stateParams.brands) {
                vm.selection.brands = {}
                var selectedBrands = $stateParams.brands.split(',');
                selectedBrands.forEach(function(value) {
                    var isObjectExist = vm.attributefilter[0].filterLists.filter(function(v) {
                        return v.name == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                        vm.selection.brands[value] = true;
                });
            }

        };

        function getGradesFromSession() {
            if ($stateParams.grades) {

                var selectedGrades = $stateParams.grades.split(',');
                selectedGrades.forEach(function(value) {
                    var isObjectExist = vm.attributefilter[1].filterLists.filter(function(v) {
                        return v.name == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                        vm.selection.grades[value] = true;

                });
            }
        };

        function getPriceRangeFromSession() {
            if ($stateParams.prices) {
            	var selectedPrices = $stateParams.prices.split(',');
                selectedPrices.forEach(function(value) {
                	var isObjectExist = vm.priceRange.filter(function(v) {
                        return v.value == value;
                    });
                    if (isObjectExist && isObjectExist.length > 0)
                    vm.selection.price[value] = true;
                });
            }

        };

        function getCategoriesfromSession() {
            if ($stateParams.cats) {
                selectCheckboxes(vm.subsubCategory);
            } else {
                checkSubcat(vm.subsubCategory);
            }
        }

        function selectCheckboxes(value) {
            var selectedCategoriesId = $stateParams.cats.split(',');
            value.forEach(function(subvalue, index) {
                if (selectedCategoriesId.indexOf(subvalue.categoryId.toString()) >= 0) {
                    subvalue.isChecked = true;
                    selectCheckboxes(subvalue.subCategory);
                }
            });
        }
    }]);
});