/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("placeorderService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService','$sessionStorage',function($q, ajaxService, stateService, utilityService,urlService,$sessionStorage){
		return	{
				getPlacementOrderUrl: function (orderdetails) {
		            var url =  urlService.placeorderUrl();
		            return ajaxService.doPost(url,{},orderdetails);
		        },
		        getShippingAddresses: function (loginName) {
		            var url =  urlService.getShippingAddressUrl();
		            return ajaxService.doGet(url+'?loginName='+loginName);
		        },
		        submitOrderRequest: function (submitOrder) {
		            var url =  urlService.submitOrderRequestUrl();
		            return ajaxService.doPost(url,{},submitOrder);
		        },
		        expandOrCollapseAccordion: function (accordionStatus) {
		
		            //  Update each accordion header using the header's status and HTML id
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.shippingaddress, "shippingaddressAccId");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.productsummary, "productsummaryAccId");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.paymentmethod, "paymentmethodAccId");
		           
		        },
		        addNewAddress: function (addressDetails) {
		            var url =  urlService.addNewAddressUrl();
		            return ajaxService.doPost(url,{},addressDetails);
		        },
		        updateAddress: function (addressDetails) {
		            var url =  urlService.updateAddressUrl();
		            return ajaxService.doPut(url,{},addressDetails);
		        },
		        removeAddress: function (shipId) {
		            var url =  urlService.removeAddressUrl();
		            return ajaxService.doDelete(url, shipId);
		        },
		        getProdcutSummary: function (product) {
		            var url =  urlService.getProdcutSummaryUrl();
		            return ajaxService.doPost(url,{},product);
		        },
        		getUserWallet:function(userInfo){
        			var url = urlService.getWalletUrl();
        			return ajaxService.doGet(url,userInfo);
		        },
		        getOrderDetailsOnSuccess : function() {
					return typeof $sessionStorage["orderDetailsOnSuccess"] != "undefined" ? $sessionStorage["orderDetailsOnSuccess"]: false;
				},
				getStatedName: function(statesList,id){
					for(var _state = 0,_stateLen =  statesList.length;_state<=_stateLen;_state++){
						if((_state)===parseInt(id)){
							return statesList[_state].state;
						}
					}
				},
				getStateId: function(statesList,name){
					for(var _state = 0,_stateLen =  statesList.length;_state<=_stateLen;_state++){
						if(statesList[_state].name===name){
							return _state+1;
						}
					}
				}
		};
	}]);
    
	return services;
});