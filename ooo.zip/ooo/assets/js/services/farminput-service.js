/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("farmInputService",['$q', '$http','ajaxService', 'stateService', 'utilityService','urlService', 'loginService',function($q,$http, ajaxService, stateService, utilityService,urlService, loginService){
		return	{
			 createFarmInputRequest:function(request){
		      	var url = urlService.createFarmInputUrl(), deferred = $q.defer();;
		      	 $http.post(url,request,{
	            	 transformRequest: angular.identity,
	            	 headers: {'Content-Type': undefined,'origoToken': loginService.getUserInfo().origoToken}
		            }).success(function (data, status, headers, config) {
		   			    deferred.resolve(data);
		       
		     }).error(function(data, status, headers, config){
		    	 deferred.reject(data);
			     });
		      	  
		      	 return deferred.promise;
		      },
		        expandOrCollapseAccordion: function (accordionStatus) {
		    		
		            //  Update each accordion header using the header's status and HTML id
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.farmbasicdetails, "farminputdetailsid");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.selectcategorydetails, "categoryinputdetailsid");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.farminputstoredetails, "farminputstoredetailsid");
		           
		        },
		      updateFarmInputRequest:function(request){
		      	  var url = urlService.updateFarmInputUrl()	, deferred = $q.defer();
		      	 $http.post(url,request,{
	            	 transformRequest: angular.identity,
	            	 headers: {'Content-Type': undefined,'origoToken': loginService.getUserInfo().origoToken}
		            }).success(function (data, status, headers, config) {
		   			    deferred.resolve(data);
		       
		     }).error(function(data, status, headers, config){
		    	 deferred.reject(data);
			     });
		      	  
		      	 return deferred.promise;
		      },
		      getAttributesForCategory:function(request){
		    	  var url = urlService.getAttributesForCategoryUrl();
		            return ajaxService.doGet(url, request);
		      },
		      deleteFarmInputRequest:function(request){
		      	  var url = urlService.deleteFarmInputUrl();
		            return ajaxService.doDelete(url, request);
		      },
		     getFarmInputRequest:function(request){
		      	  var url = urlService.getFarmInputUrl();
		            return ajaxService.doGet(url,request);
		      },
		      getFarmFilterListRequest:function(){
			      	  var url = urlService.getFilterListUrl();
			            return ajaxService.doGet(url,{});
			  },
			  getStoreDetailsRequest:function(){
		      	  var url = urlService.getAllStoresUrl();
		            return ajaxService.doGet(url,{});
		      },
		      getSeedClassRequest:function(){
		      	  var url = urlService.getSeedClassUrl();
		            return ajaxService.doGet(url,{});
		      },
		      getSkuRequest:function(){
		      	  var url = urlService.getSkuUrl();
		            return ajaxService.doGet(url,{});
		      },
		      getGradeRequest:function(){
		      	  var url = urlService.getGradeUrl();
		            return ajaxService.doGet(url,{});
		      },
		      getFarmInputsListingById:function(request){
		      	  var url = urlService.getFarmInputsListingByIdUrl();
		            return ajaxService.doGet(url,request);
		      },
		      getStatesDetails:function(request){
		                var url = urlService.getStateDetailsUrl();
		              
		            return ajaxService.doGet(url, request); 
		        },
		        getStoresAndSeasonByStateId:function(request){
			      	  var url = urlService.getStoresAndSeasonByStateIdUrl();
			            return ajaxService.doGet(url,request);
			      },
		      getAllRequest:function(){
		            var deferred = $q.defer();
		            $q.all({
		                grade: this.getGradeRequest(),
		                sku: this.getSkuRequest(),
		                store: this.getStoreDetailsRequest(),
		                filterlist:this.getFarmFilterListRequest(),
		                state:this.getStatesDetails()
		            }).then(function(results) {
		                    deferred.resolve(results);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		            return deferred.promise;
		        },
		    	 getStoreName:function (vm,storeId){
		      		var data = vm.listOfStores;
		      		for(var i=0; i<data.length;i++){
		      			var store= data[i];
		      			if(store.store_id===storeId){
		      				return store.storeName;
		      				//angular.element('#store_field').text(store.name);
		      				break;
		      			}
		      		}
		      	},
		      	getStateId:function (vm,stateName){
		      		var data = vm.statesList;
		      		for(var i=0; i<data.length;i++){
		      			var state= data[i];
		      			if(state.stateName===stateName){
		      				return state.stateId;
		      				//angular.element('#store_field').text(store.name);
		      				break;
		      			}
		      		}
		      	},
		      	getStoreId:function (vm,storeName){
		      		var data = vm.listOfStores;
		      		for(var i=0; i<data.length;i++){
		      			var store= data[i];
		      			if(store.storeName===storeName){
		      				return store.store_id;
		      				//angular.element('#store_field').text(store.name);
		      				break;
		      			}
		      		}
		      	},
		      	 getDataWithPattern:function(data){
		    		for(var _data=0,_dataLen=data.length;_data<_dataLen;_data++){
		    			var item = data[_data]
		    			if(item.dataType==='float(5,2)'){
		    				item.pattern=/^[0-9]{1,3}(\.[0-9]{1,2})?$/;
		    				item.maxlength=6;
		    				item.placeholder='Eg:100.00'
		    			}else if(item.dataType==='float(6,2)'){
		    				item.pattern=/^[0-9]{1,4}(\.[0-9]{1,2})?$/;
		    				item.maxlength=7;
		    				item.placeholder='Eg:1000.00'
		    			}else if(item.dataType==='float(7,2)'){
		    				item.pattern=/^[0-9]{1,5}(\.[0-9]{1,2})?$/;
		    				item.maxlength=8;
		    				item.placeholder='Eg:10000.00'
		    				
		    			}else if(item.dataType==='float(9,2)'){
		    				item.pattern=/^[0-9]{1,7}(\.[0-9]{1,2})?$/;
		    				item.maxlength=8;
		    				item.placeholder = 'Eg:1000000.00'
		    				
		    			}else if(item.dataType==='tinyint'){
		    				item.pattern=/^[0-9]+$/;
		    				item.maxlength=2;
		    				item.placeholder='Eg :90'
		    			}else if(item.dataType==='varchar(50)'){
		    				item.pattern =/^[a-zA-Z\s0-9&.,_-`:-]*$/;
		    				item.placeholder='';
		    				item.maxlength=50;
		    				
		    			}
		    		};
		    		return data;
		    	},
		    	 setProductData:function(product,vm) {
		         	var inputs = angular.extend(vm, {
						 productTitle:product.productName,
						 productDesc:product.productDesc,
						 supplierName:product.supplierName,
						 prodSku:product.sku,
						 skuDesc:product.skuDesc,
						 unitSize:product.unitSize,
						 unitPrice:product.unitPrice,
						 vendorDisc:product.vendorDiscount,
						 origoDisc:product.origoDiscount,
						 percentDisc:product.percentDiscount,
						 brand:product.brand,
						 tradeName:product.tradeName,
						 manufacturer:product.manufacturer,
						 prodGrade:product.grade,
						 gradeDesc:product.gradeDesc,
						 prodStatus:product.status,
						 itemNumber:product.itemNumber,
						 sponsored:product.is_sponsored==="Y"?"Yes":"No",
						 storeName:this.getStoreName(vm,+product.storeLocatorDTO.store_id),
						 skuMeasure:product.natureOfMeasurement,
						 seasonName: product.seasonName,
				         stateName: product.stateName,
				         dynamicAttr:this.getDataWithPattern(product.listAttibutes),
				         stockQuantity:product.stockQuantity
					});
//					var fData = new FormData();
//					fData.append('file', file);
//					fData.append("data", JSON.stringify(inputs));
					
				//	updateFarmInputRequest(inputs).then(updateFarmInputResponse); 
				}
	
		};
	}]);
    
	return services;
});