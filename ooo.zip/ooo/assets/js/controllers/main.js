
/**
 *  load all angular controller files in controllers directory.
 */

define([
'./advancedsearch-crtl',
'./allsearch-crtl',
'./forgetpassword-crtl',
'./forgetusername-crtl',
'./homepage-crtl',
'./login-crtl',
'./registration-crtl',
'./storelocater-crtl',
'./useraccount-crtl',
'./productdetails-crtl',
'./mycart-crtl',
'./placeorder-crtl',
'./ordersuccess-crtl',
'./userorder-crtl',
'./farminput-list-crtl',
'./commodityinput-crtl',
'./misscall-crtl',
'./submitdemand-crtl',
'./userwishlist-crtl',
'./userdemands-crtl',
'./farminput-crtl',
'./placeordersuccess-crtl',
'./groupedsearch-ctrl',
'./addtowallet-crtl',
'./adminroles-ctrl'
], function(){
	
});