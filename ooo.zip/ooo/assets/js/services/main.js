
/*
 * load angular app.services files - angular.module("app.services");
 */
define([
"./advancedsearch-service", 
"./allsearch-service", 
"./forgetpassword-service", 
"./forgetusername-service", 
"./homepage-service",
"./login-service",
"./registration-service",
"./ajax-services",
"./state-service",
"./url-service",
"./host-service",
"./utility-service",
"./useraccount-service",
"./mycart-service",
"./placeorder-service",
"./productdetails-service",
"./userorder-service",
"./farminput-service",
"./commodityinput-service",
"./misscall-service",
"./submitdemand-service",
"./userwishlist-service",
"./adminroles-service"

], function() {

});