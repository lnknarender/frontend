/*global define */
define(['angular', 'directives-module','bootstrap'], function(angular, directives,bootstrap) {
	'use strict';

    /* Directives  */

	directives.directive('fileModel', ['$parse', function ($parse) {


	    return {
	    
	    	restrict: 'A',
	        require :'ngModel',
	        link: function(scope, element, attrs,ngModel) {
	            var p="vm.q",
	            	filesuploaded ="vm.uploadedFiles",
	            	_files=[],
	            	inputs="vm.listingfiles",
	            	_showImage = "vm.showImage",
	            	model2 = $parse(p),
	            	model3 = $parse(inputs),
                	model = $parse(attrs.ngModel),
                	modelSetter = model.assign,
                	model4= $parse(filesuploaded),
                	model5 = $parse(_showImage),
                	z=[],
                	obj={},
                	currentFileName,
               		newUpdaloadedFileNames = [],
                	existingFile = false;

	            
	            element.bind('change', function(changeEvent){
	                     var reader = new FileReader();
	                     if(element[0].files[0]===undefined){
	                    	 scope.documentForm.file.$setPristine();
	                    	 scope.documentForm.file.$setUntouched();
	                    	 modelSetter(scope, null); 
	                     } else {
	                    	 currentFileName = element[0].files[0].name;
	                     }
	                     reader.onload = function (loadEvent) {
	                    scope.$apply(function () {
	                    //     ngModel.$setViewValue(element.val());
	                        ngModel.$render();
	                        var x={};
	                        var fileread = loadEvent.target.result,
	                       		fileExists = false;
	                       	z = scope.vm.listingfiles ? scope.vm.listingfiles : [];
	                       	newUpdaloadedFileNames = [];
	                       	if(scope.vm.inputDirective){
				                       	for(var _uploads = 0; _uploads < scope.vm.uploadedFiles.length; _uploads++) {
				                       		newUpdaloadedFileNames.push(scope.vm.uploadedFiles[_uploads].name.split('.')[0]);
				                       	}
		                       	
		                       	
		                       	for(var files=0; files<z.length;files++){
		                       		if(z[files].split('/')[z[files].split('/').length-1].split('.')[1] === currentFileName.split('.')[0]) {
		                       			fileExists = true;
		                       		}
		                       	}
		                       	
		                       	for(var files=0; files<newUpdaloadedFileNames.length;files++){
		                       		if(newUpdaloadedFileNames[files] === currentFileName.split('.')[0]) {
		                       			fileExists = true;
		                       		}
		                       	}
		                       	
		                       	if(fileExists) {
		                       		alert("Image already exists..!");
		                       		existingFile = true;
		                       	} else {
		                       		existingFile = false;
			                       	z.push(fileread);
			                    	 newUpdaloadedFileNames.push(currentFileName);
		                       	}
	                       	}
	                       	//console.log(fileread);
                            modelSetter(scope, element[0].files[0]);
                            model2.assign(scope,fileread);
                            model3.assign(scope,z);
                            model4.assign(scope,_files);

	                    });
	                }
	                reader.readAsDataURL(changeEvent.target.files[0]);
	                reader.onloadend=function(event) {
	                	if(!existingFile) {
		                	_files.push(scope.categoryForm.image.$modelValue);
		                	if(scope.vm.listingfiles.length == 4) {
			                	_showImage = false;
			                	scope.$apply(function () {
			                		model5.assign(scope,_showImage);
			                	});		                		
		                	}
	                	}
                        changeEvent.target.value = null;
                    }	                
	            });
	        }
	    };


	}]);
	directives.directive('loading', function () {
	    return {
	        restrict: 'EA',
	        replace: true,
	        template: '<div class="loading"><img src="assets/images/ajax-loader.gif" alt="loading ticker" width="25" height="25" /><span><br>Loading details</span></div>',
	        link: function (scope, element, attr) {
	            scope.$watch('loading', function (val) {
	                if (val){
	                	 $(element).show();
	                }
	                 else{
	                	$(element).hide();
	                }
	                    
	            });
	        }
	    };
	});
	
	directives.directive('myDatepicker',function(){
		
		      return {
					restrict: 'A',
					require: 'ngModel',
					link: function (scope, element, attrs, ngModelCtrl) {
					$(element).datepicker({
					changeYear : true,
					changeMonth : true,
					yearRange: "-100:+0",
					// minDate: "-100y",
					 maxDate: 0,
					showOn: "button",
					buttonImage: "assets/images/Calendar1.png",
					buttonImageOnly: true,
					buttonText: "Select date",
					dateFormat : 'dd-mm-yy',
					onSelect: function(date) {
						 scope.date = date;
						 var modelPath = $(this).attr('ng-model');
						 scope.vm.dob=date;
						 scope.regForm.dob.$setValidity('required', true);
		                    scope.$apply();
					}
		      });
		    }
		  };	  
		  
	});
	
	directives.directive('sdDatepicker',function(){
		
	      return {
				restrict: 'A',
				require: 'ngModel',
				link: function (scope, element, attrs, ngModelCtrl) {
				$(element).datepicker({
				changeYear : true,
				changeMonth : true,
				 minDate: 0,
				 maxDate:"+1y +1m +1w",
				showOn: "button",
				buttonImage: "assets/images/Calendar1.png",
				buttonImageOnly: true,
				buttonText: "Select date",
				dateFormat : 'dd-mm-yy',
				onSelect: function(date) {
					 scope.date = date;
					 var modelPath = $(this).attr('ng-model');
					 scope.vm.expDate=date;
					 scope.sdForm.doexp.$setValidity('required', true);
	                    scope.$apply();
				}
	      });
	    }
	  };	  
	  
});
directives.directive('errSrc', function() {
		  return {
		    link: function(scope, element, attrs) {
		      element.bind('error', function() {
		    	  var imageLink = constants.ERROR_IMAGE;
		    	  
		        if (attrs.src != imageLink) {
		          attrs.$set('src', imageLink);
		        }
		      });
		    }
		  }
});
	return directives;
});