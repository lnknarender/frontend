/**
 * creating, updating, listing and deleting the commodity 
 */

'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("commodityInputCtrl", ['$scope','$rootScope','$state', 'commodityInputService','stateService','utilityService','$stateParams', function($scope,$rootScope,$state, commodityInputService,stateService,utilityService,$stateParams) {
	 var vm = this;
     init();
     vm.createCommodityInput= createCommodityInput;
     vm.updateCommodityInput =updateCommodityInput;
     vm.deleteCommodityInput = deleteCommodityInput;
     function init(){
    	 
    	 getCommodityInputRequest(request).then(getFarmInputResponse);
     }
	function getCommodityInputRequest(request){
		return commodityInputService.getCommodityInputRequest(request);
	}
	function getCommodityInputResponse(response){
		
	}
	function createCommodityInput(){
		createCommodityInputRequest(request).then(createCommodityInputResponse);
	     }
	function createCommodityInputRequest(request){
		return commodityInputService.createCommodityInputRequest(request);
	}
	function createCommodityInputResponse(response){
		
	}
	function updateCommodityInput(){
		updateCommodityInputRequest(request).then(updateCommodityInputResponse); 
	}
    function updateCommodityInputRequest(request){
    	return commodityInputService.updateCommodityInputRequest(request);
	}
	function deleteCommodityInputResponse(response){
		
	}
	function deleteCommodityInput(){
		deleteCommodityInputRequest(request).then(deleteCommodityInputResponse); 
	}
   function deleteCommodityInputRequest(request){
	   return commodityInputService.deleteCommodityInputRequest(request);
	}
	function deleteCommodityInputResponse(response){
		
	}
   
}]);
});