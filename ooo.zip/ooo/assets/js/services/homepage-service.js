/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("homepageService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return	{
		    
			homeOfferService:function(userInfo){
				 var url = urlService.getHomeOfferUrl();
				 return ajaxService.doPost(url, {},userInfo);
			}
		};
	}]);
    
	return services;
});