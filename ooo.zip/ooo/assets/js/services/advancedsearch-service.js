/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("setupAdvancedSearchService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService','$http',function($q, ajaxService, stateService, utilityService,urlService,$http){
		return	{
			  getAllSearchDetails: function (free_text) {
		            var deferred = $q.defer(), searchDetail = stateService.get(constants.STATE_SEARCH_DETAILS);

		            if (searchDetail) {
		                deferred.resolve(searchDetail);
		            } else {
		                var url = urlService.getSearchDataUrl();

		                var searchDetailsResponse = ajaxService.doGet(url,free_text);

		               searchDetailsResponse.then(function (result) {
		                	
		                    stateService.set(constants.STATE_ALL_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		            }

		            return deferred.promise;
		        },
		        getFullDataSearchDetails :function () {
		            var deferred = $q.defer(), searchDetail = stateService.get(constants.STATE_FULL_DATA_SEARCH_DETAILS);

		            if (searchDetail) {
		                deferred.resolve(searchDetail);
		            } else {
		                var url = urlService.getFullDataSearchUrl();

		                var searchDetailsResponse = ajaxService.doGet(url, {});

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.STATE_FULL_DATA_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            }

		            return deferred.promise;
		        },
		        getFilterList : function(){
		        	//http://localhost:8080/origo/getfilterlist
				 var deferred = $q.defer();/* searchDetail = stateService.get(constants.STATE_FILTER_SEARCH_DETAILS);

			            if (searchDetail) {
			                deferred.resolve(searchDetail);
			            } else {*/
			                var url = urlService.getFilterListUrl();

			                var searchDetailsResponse = ajaxService.doGet(url, {});

			               searchDetailsResponse.then(function (result) {
			                
			                    stateService.set(constants.STATE_FILTER_SEARCH_DETAILS, result);
			                    deferred.resolve(result);
			                },
			                function (errorResult) {
			                   deferred.reject(errorResult);
			                });
			           /* }*/

			            return deferred.promise;
		        },
		        getFilteredSearchDetails: function (requestObject) {
		            var deferred = $q.defer();/* searchDetail = stateService.get("Filtered Result");

		            if (searchDetail) {
		                deferred.resolve(searchDetail);
		            } else {*/
		                var url = urlService.getFilterResultUrl();
		                var searchDetailsResponse = ajaxService.doPost(url,{},requestObject);

		               searchDetailsResponse.then(function (result) {
		                	
		                    stateService.set(constants.STATE_ALL_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		            /*}*/

		            return deferred.promise;
		        },
		        getAttributeFilterList: function (requestObject) {
		            var deferred = $q.defer();
		                var url = urlService.getAttributeFilterlistUrl();
		                var searchDetailsResponse = ajaxService.doGet(url,requestObject);

		               searchDetailsResponse.then(function (result) {
		                	
		                    stateService.set(constants.STATE_ALL_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		           

		            return deferred.promise;
		        },
		        getGroupedSearchDetails: function (requestObject) {
		            var deferred = $q.defer();
		            
		                var url = urlService.getGroupedData();
		                var searchDetailsResponse = ajaxService.doPost(url,{},requestObject);

		               searchDetailsResponse.then(function (result) {
		                	
		                   // stateService.set(constants.STATE_ALL_SEARCH_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                    deferred.reject(errorResult);
		                });
		           

		            return deferred.promise;
		        },
		        verifyPinWithState: function (pin) {	           
		        	 var deferred = $q.defer();
		        	var url = "https://www.whizapi.com/api/v2/util/ui/in/indian-city-by-postal-code";
	                var requestObj = {
	                		AppKey : "ks7nz2pv8lp5dktt8b57m249",
	                		pin : pin
	                		
	                }
		          // var searchDetailsResponse = ajaxService.doGet(url,requestObj);
	                $http({
                        method: 'GET',
                        url: url,
                        cache: false,
                        params:requestObj,  
                   }).
                        success(function (data, status, headers, config) {
                        	deferred.resolve(data);
                        }).
                         error(function (data, status, headers, config) {
                        	 deferred.reject(data);
                        });
	               
		            return deferred.promise;
	        }	        
		};
	}]);
    
	return services;
});