'use strict';
 
App.factory('TestService', ['$http', '$q', function($http){
 
    return {
    		testAngJs: function(){
                  //return $http.get('http://localhost:8080/wlt-services/test').success(function(response)
    			  return $http.get('http://localhost:8080/wlt-services/test').success(function(response)
    					  {
                                    	alert("response.data: "+response.name);
                                    	return response.name;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while testing');
                                        //return $q.reject(errResponse);
                                        return false;
                                    }
                            );
            }
    };
 
}]);