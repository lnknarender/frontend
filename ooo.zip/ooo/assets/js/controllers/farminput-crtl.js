'use strict';

define([ 'angular', 'controllers-module', 'underscore' ], function(angular,
		controllers, underscore) {
					
		// Add Attribute Controller
controllers.controller("createFarmInputCtrl", ['$scope','$rootScope','$state', 'farmInputService','stateService','utilityService','$stateParams', 'loginService', '$sessionStorage', function($scope,$rootScope,$state, farmInputService,stateService,utilityService,$stateParams,loginService, $sessionStorage) {
	var vm = this;
	vm.seedDetails	 = {};
	vm.fertilizerDetails = {};
	vm.pesticideDetails = {};
	vm.nutrientDetails = {};
	vm.hormoneDetails = {};
	init();
	vm.view = view;
	vm.tabs={};
	vm.farmType = $sessionStorage.userInfo ? $sessionStorage.userInfo.farmType : $state.go('login');
	vm.deleteImages=[];
	vm.submitFarmInputs = submitFarmInputs;
     vm.category={};
     vm.categoryObj={};
	 vm.view = view;
	 vm.onParentCategoryChange=onParentCategoryChange;
     vm.onSubCategoryLevel1Change=onSubCategoryLevel1Change;
     vm.onSubCategoryLevel2Change=onSubCategoryLevel2Change;
	 var selectCategory;
	 vm.onChangingSeed=onChangingSeed;
	 vm.onChangingGrade=onChangingGrade;
	 vm.onChangingSku=onChangingSku;
	 vm.basicDetailsContinue=basicDetailsContinue;
	 vm.editFarminputBasicDetails=editFarminputBasicDetails;
	 vm.farmCategoryContinue =farmCategoryContinue;
		 vm.editFarminputCategoryDetails =editFarminputCategoryDetails;
    vm.onSubCategoryLevel3Change=onSubCategoryLevel3Change;
    vm.onStateChangeChange =onStateChangeChange;
    vm.isPrimaryImageDeleted = false;
    vm.uploadedFiles=[];
    vm.inputDirective=true;
    vm.listingfiles = [];
    vm.showImage = true;
    vm.sponsored='';
    farmInputService.action = farmInputService.action ? farmInputService.action : $sessionStorage["farmInputAction"];
    farmInputService.productId = farmInputService.productId ? farmInputService.productId : $sessionStorage["farmInputProductId"];
    vm.deleteImage = function(index){
    	var image= vm.listingfiles[index];
    	
    	/*function checkImage(_item){
    		return _item.imgPath===image.substr(image.indexOf('\images')+7);
    	}
    	vm.deletedImagesList= vm.dummyUploadFiles.filter(checkImage);*/
    	 if(farmInputService.action==="update"){
    		 vm.deletedImages=vm.deletedImages||[];
    		 for(var i=0;i<vm.dummyUploadFiles.length;i++){
    			 var _dummyImageName = vm.dummyUploadFiles[i].imgPath.split('/')[vm.dummyUploadFiles[i].imgPath.split('/').length-1].split('.')[vm.dummyUploadFiles[i].imgPath.split('/')[vm.dummyUploadFiles[i].imgPath.split('/').length-1].split('.').length-2],
    			 	 _imagePath = image.split('/')[image.split('/').length-1].split('.')[image.split('/')[image.split('/').length-1].split('.').length-2]
        		 if(_dummyImageName === _imagePath){
        			 vm.deletedImages.push(vm.dummyUploadFiles[i]);
        		 }
        	 }
			 if(vm.dummyUploadFiles[index].isDefault == true) {
				 vm.isPrimaryImageDeleted = true;
			 }    		 
    		 if(image.indexOf("data:image/") == 0) {
	    		 var _objMapping = {},
	    		 	 indexCounter = -1;
	    		 for(var objIndex = 0; objIndex < vm.listingfiles.length; objIndex++) {
	    			 if(vm.listingfiles[objIndex].indexOf("data:image/") == 0) {
	    				 indexCounter++;
	    			 }
	    			 _objMapping[objIndex] = indexCounter;
	    		 }

    			 vm.uploadedFiles.splice(_objMapping[index],1);
    		 }    		 
    		     		 
    	 } else {
    	    vm.uploadedFiles.splice(index,1);
    	 }
    	vm.listingfiles.splice(index,1);
    	if(vm.listingfiles.length < 4) {
    		vm.showImage = true;
    	}
    } 
    function onStateChangeChange(){
    	var stateId=farmInputService.getStateId(vm,vm.stateName);
    	var request = angular.extend({},{
    		stateId:stateId
    	})
    	getStoresAndSeasonByStateIdRequest({stateId:stateId}).then(getStoresAndSeasonByStateIdResponse);
    }
    function getStoresAndSeasonByStateIdRequest(request){
    	return farmInputService.getStoresAndSeasonByStateId(request);
    }
    function getStoresAndSeasonByStateIdResponse(response){
    	var data= response.body.data;
    	vm.listOfSeasons = data[0].listOfSeasons;
    	vm.listOfStores = data[0].listOfStores;
    }
	 function onParentCategoryChange(categoryItem){
		 vm.category.type =vm.levelOne;
		 if(vm.category.type==undefined){//it will collapse all dynamic attributes and sublevels of category dropdowns
			 vm.categoryListLevel1Show = vm.categoryListLevel2Show=vm.categoryListLevel3Show=false;
			 vm.dynamicAttr=[];
			 vm.levelTwo =vm.levelThree=vm.levelFour= "";
			 return false;
		 }
		 vm.categoryListLevel1=vm.categoryListLevel2=vm.categoryListLevel3=[];
		 var category= getSubCategoryByName(vm.levelOne,vm.categoryList);
		 vm.categoryLevelOneId = category.categoryId;
		 vm.categoryId=category.categoryId;
		 vm.categoryListLevel1=category!=null?category.subCategory:[];
		 vm.categoryListLevel1Show=vm.categoryListLevel1.length>0?true:false;
		 vm.categoryListLevel2Show=vm.categoryListLevel3Show=false;
		 vm.categoryObj = getCategoryObject(vm.levelOne,vm.categoryList);
		 selectCategory = vm.category.type;
		 
		 if(vm.farmType == '2') {
			 if(farmInputService.action==="update" && vm.product.categoryDTO.categoryName===category.categoryName && !vm.categoryListLevel1Show){
				  vm.dynamicAttr=vm.product.listAttibutes;
			 }else if(!vm.categoryListLevel1Show){
				var request= angular.extend({},{
					catagoryIds:[vm.categoryLevelOneId]
				})
				getAttributesForCategoryRequest(request).then(getAttributesForCategoryResponse);
			 }
		 }else{
			 vm.dynamicAttr=[];
		 }
	 }
	function onSubCategoryLevel1Change(categoryItem,update){
		var category= getSubCategoryByName(vm.levelTwo,vm.categoryListLevel1);
		vm.categoryObj=category;
		vm.categoryLevelTwoId =  category.categoryId;
		vm.categoryListLevel2=category!=null?category.subCategory:[];
		vm.categoryListLevel2Show=vm.categoryListLevel2.length>0?true:false;
		vm.categoryListLevel3Show=false;
		vm.categoryListLevel3=[];
		if(farmInputService.action==="update" && vm.product.categoryDTO.categoryName===category.categoryName && !vm.categoryListLevel2Show){
				  vm.dynamicAttr=vm.product.listAttibutes;
		}else if(!vm.categoryListLevel2Show){
				var request= angular.extend({},{
					catagoryIds:[vm.categoryLevelOneId,vm.categoryLevelTwoId].join(",")
				})
				getAttributesForCategoryRequest(request).then(getAttributesForCategoryResponse);
			}else{
				vm.dynamicAttr=[];
			}
		
		
		 }
	function getAttributesForCategoryRequest(request){
		return farmInputService.getAttributesForCategory(request);
	}
	function onSubCategoryLevel3Change(category,update){
		var category=getSubCategoryByName(vm.levelFour,vm.categoryListLevel3);
		vm.categoryObj=category;
		vm.categoryLevelFourId =  category.categoryId;
		if(farmInputService.action==="update" && vm.product.categoryDTO.categoryName===category.categoryName){
			vm.dynamicAttr=vm.product.listAttibutes;
		}else{
				var request= angular.extend({},{
					catagoryIds:[vm.categoryLevelOneId,vm.categoryLevelTwoId,vm.categoryLevelThreeId,vm.categoryLevelFourId]
				})
				getAttributesForCategoryRequest({catagoryIds:[vm.categoryLevelOneId,vm.categoryLevelTwoId,vm.categoryLevelThreeId,vm.categoryLevelFourId].join(",")}).then(getAttributesForCategoryResponse);
			}
		
		
		
	}
	
	function getAttributesForCategoryResponse(response){
		if(response.body.applicationStatusCode===1047){
			var data= response.body.data;
			
			if(data!=null){
				
				vm.dynamicAttr=farmInputService.getDataWithPattern(data);
			}
		}
	}
	vm.validate = function(pattern,value){
		if(value===""||value===null||value===undefined){
			return false;
		}
		var match = new RegExp(pattern);
	 return	!match.test(value);
	}
	function onSubCategoryLevel2Change(categoryItem,update){
		var category=getSubCategoryByName(vm.levelThree,vm.categoryListLevel2);
		vm.categoryObj=category;
		vm.categoryLevelThreeId =  category.categoryId;
		vm.categoryListLevel3=category!=null?category.subCategory:[];
		vm.categoryListLevel3Show=vm.categoryListLevel3.length>0?true:false;
		if(farmInputService.action==="update" && vm.product.categoryDTO.categoryName===category.categoryName){
			 vm.dynamicAttr=vm.product.listAttibutes;
		}else if(!vm.categoryListLevel3Show){
			var request= angular.extend({},{
				catagoryIds:[vm.categoryLevelOneId,vm.categoryLevelTwoId,vm.categoryLevelThreeId].join(",")
			})
			getAttributesForCategoryRequest(request).then(getAttributesForCategoryResponse);
		}else{
			vm.dynamicAttr=[];
		}
		
	}
	 function setCategoryHierarchyDTO(categoryHierarchyDTO,update){
    	 for(var categoryList = 1,categoryLen = categoryHierarchyDTO.length;categoryList<categoryLen;categoryList++){
    		 var _category = categoryHierarchyDTO[categoryList],categoryName = _category.categoryName;
    		  if(parseInt(_category.level)===2){
    			 vm.levelOne = categoryName;
    			 onParentCategoryChange(null,update);
    			 vm.categoryListLevel1Show=vm.farmType == '2'?false:true;
    		 }else if(parseInt(_category.level)===3){
    			 vm.levelTwo = categoryName;
    			 vm.categoryListLevel2Show=true;
    			 onSubCategoryLevel1Change(null,update);
    		 }else if(parseInt(_category.level)===4){
    			 vm.levelThree = categoryName;
    			 vm.categoryListLevel3Show=true;
    			 onSubCategoryLevel2Change(null,update);
    		 }else if(parseInt(_category.level)===5){
    			 vm.levelFour = categoryName;
    			 vm.categoryListLevel4Show=true;
    			 onSubCategoryLevel3Change(null,update);
    		 }
    	 }
     }
	function getSubCategoryByName(name,categoryList){
		 for(var list=0,listLen=categoryList.length;list<listLen;list++){
			 if(categoryList[list].categoryName===name){
				 return categoryList[list];
			 }
		 }
	}
	 function createProduct(){
		 newProduct();
	 }
	 function updateProduct(){
		 return request;
	 }
	 function newProduct(){
		 var empty="",emptyObj={},emptyArray=[];
		 angular.extend(vm,{
             productTitle:empty,
			 productDesc:empty,
			 supplierName:empty,
			 prodSku:vm.skuList[0].name,
			 skuDesc:vm.skuList[0].desc,
			 unitSize:empty,
			 unitPrice:empty,
			 vendorDisc:empty,
			 origoDisc:empty,
			 brand:empty,
			 tradeName:empty,
			 manufacturer:empty,
			 prodGrade:vm.gradeList[0].name,
			 gradeDesc:vm.gradeList[0].desc,
			 itemNumber:empty,
			 sponsored:empty,
			 storeName:vm.storeList[0].storeName,
			 skuMeasure:vm.skuList[0].nature,
			 categoryInputObj:empty,
			 seasonName: empty,
	         stateName: empty,
	         listAttibutes:emptyArray,
	         deleteImages:vm.deletedImages
			 
      });
	 }
	
     function init(){    
    	 $scope.loading=true;
    	 $rootScope.dataLoading = true;
    	 $rootScope.dataStillLoading = true;
    		 getAllRequest().then(getAllResponse);
    	// completedStatus(false,false,false);
    	// defaultValues(vm,'farmbasicdetails',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
	 
    		
     }
     function getProductById(request){
   		return farmInputService.getFarmInputsListingById(request);
   	}
     function getImages(vm,productImgPath,images){
    	vm.dummyUploadFiles=[];
    	 var _mPath= productImgPath,path=[connection.storeImage,_mPath.substr(_mPath.indexOf('\images')+7)].join("");
    	 vm.listingfiles.push(path);
    	 vm.dummyUploadFiles.push({isDefault:true,imgPath:path});
    	 for(var imageItem=0,imageLen=images.length;imageItem<imageLen;imageItem++){
    		 var _path= images[imageItem].imgPath,_imgPath = [connection.storeImage, _path.substr(_path.indexOf('\images')+7)].join("");
    		 vm.listingfiles.push(_imgPath);
    		 vm.dummyUploadFiles.push({isDefault:false,imgPath:_path,imgNo:images[imageItem].imgNo});
    		// vm.uploadedFiles.push(_imgPath);
    	 }
    	 if(vm.listingfiles.length == 4) {
    		 vm.showImage = false;
    	 }
     }
     function getUpdateStateDetails(stateName){
    	 var stateId=farmInputService.getStateId(vm,stateName);
     	var request = angular.extend({},{
     		stateId:stateId
     	})
     	getStoresAndSeasonByStateIdRequest({stateId:stateId}).then(getUpdateStateDetailsResponse);
     }
     function getUpdateStateDetailsResponse(response){
    	 var data= response.body.data;
    	 $rootScope.dataLoading = false;
    		$rootScope.dataStillLoading = false;
     	vm.listOfSeasons = data[0].listOfSeasons;
     	vm.listOfStores = data[0].listOfStores;
    	 farmInputService.setProductData(vm.product,vm);
     	 var categoryDTO = vm.product.categoryDTO;
    	 var categoryHierarchyDTO=[],_categoryObj=vm.product.categoryHierarchyDTO;
    	 while(_categoryObj!=null){
    		
    		 categoryHierarchyDTO.push({
    			 categoryId:_categoryObj.categoryId,
    			 categoryName:_categoryObj.categoryName,
    			 level:_categoryObj.level,
    			 parentCategoryId:_categoryObj.parentCategoryId
        	 });
        	 _categoryObj=_categoryObj.categoryHierarchyDTO;
    	 }
    	 categoryHierarchyDTO.push({
			 categoryId:categoryDTO.categoryId,
			 categoryName:categoryDTO.categoryName,
			 level:categoryDTO.level,
			 parentCategoryId:categoryDTO.parentCategoryId
    	 });
    	  getImages(vm,vm.product.productImgPath,vm.product.images);
    	 setCategoryHierarchyDTO(categoryHierarchyDTO,true);
    	 completedStatus(false,false,false);
    	 defaultValues(vm,'selectcategorydetails',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
     }
     function getProductByIdResponse(response){
    	 $scope.loading=false;
    	 vm.loaded =  true;
    	 vm.product=response.body.data[0];
    	
    	 getUpdateStateDetails(vm.product.stateName).then(getUpdateStateDetailsResponse);
     }
    
     function completedStatus(selectcategoryCompleted,farmbasicdetailsCompleted,farminputstoredetailsCompleted){
    	 angular.extend(vm.tabs,{
			 farmbasicdetailsCompleted:farmbasicdetailsCompleted,
			 selectcategoryCompleted:selectcategoryCompleted,
			 farminputstoredetailsCompleted:farminputstoredetailsCompleted
			 
		 });
     }
     function editFarminputBasicDetails(){
    	 completedStatus(true,false,false);
    	 defaultValues(vm,'farmbasicdetails',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
     }
     function basicDetailsContinue(){
    	 completedStatus(true,true,false);
    	 defaultValues(vm,'farminputstoredetails',constants.ACCORDION_SUCCESS,constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT);
     }
     function farmCategoryContinue(){
    	 
    	 if(farmInputService.action==="update" && vm.isPrimaryImageDeleted && vm.uploadedFiles.length == 0) {
    		 alert("Please upload a primary image...!");
    		 return false;
    	 }
    	 
    	 completedStatus(true,false,false);
    	 defaultValues(vm,'farmbasicdetails',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
     }
     function editFarminputCategoryDetails(){
    	 completedStatus(false,false,false);
    	 defaultValues(vm,'selectcategorydetails',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
     }
     function defaultValues(vm,active,selectcategorydetails,farmbasicdetails,farminputstoredetails){
     	 vm.tabs.active=active;
     	angular.extend(vm,{
     		accordionStatus:{
     			farmbasicdetails:farmbasicdetails,
     			selectcategorydetails:selectcategorydetails,
     			farminputstoredetails:farminputstoredetails
     		}
     		
     	});
     	farmInputService.expandOrCollapseAccordion(vm.accordionStatus);
     	
     }
     function getAllRequest(){
  		return farmInputService.getAllRequest();
  	}
  	function getAllResponse(response){
  		
  		getStoreDetailsResponse(response.store);
  		//getSeedClassResponse(response.seed);
  		getSkuResponse(response.sku);
  		getGradeResponse(response.grade);
  		
  		getFilterResponse(response.filterlist);
  		 vm.statesList = response.state.body.data;
  		 if(farmInputService.action==="update"){
  			vm.action='update';
			 var request=angular.extend({},{
				 productId:farmInputService.productId
			 })
			 getProductById(request).then(getProductByIdResponse);
		 }else if (farmInputService.action==="create"){
			 $scope.loading=false;
			 vm.loaded =  true;
			 completedStatus(false,false,false);
			 defaultValues(vm,'selectcategorydetails',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
			 newProduct();
			 $rootScope.dataLoading = false;
		  		$rootScope.dataStillLoading = false;
		 }
  		 
  	}
	function getFilterResponse(response){
		var _resBody = response.body.data[0];
		var arrayList = {};
	   _resBody.categoryList.map(function(element){
		   return arrayList[element['categoryName']] = element.subCategory;
		});
	
		vm.categoryList = vm.farmType == '1' ? arrayList["Farm Input"]:arrayList["Equipment"];		
	}
  	function getStoreDetailsRequest(){
  		return farmInputService.getStoreDetailsRequest();
  	}
  	function getStoreDetailsResponse(response){
  		vm.storeList=[];
  		var data=response.body.data;
  		
  	   	
  		for(var i=0; i<data.length;i++){
  			var store= data[i];
  			vm.storeList.push({name:store.storeName,id:store.store_id});
  		}
  	}
  
  	function onChangingSeed(seed){
	  	for(var i=0;i<vm.seedClassList.length;i++){
	  		if(vm.seedClassList[i].name==seed){
	  	  		vm.seedDesc=vm.seedClassList[i].desc;
  	  		
  			}
  		}
  		
  	}
  	
  	function onChangingGrade(grade){
	  	for(var i=0;i<vm.gradeList.length;i++){
	  		if(vm.gradeList[i].name==grade){
	  			vm.gradeDesc=vm.gradeList[i].desc;
  	  		
  			}
  		}
  		
  	}
  	
  	function onChangingSku(sku){
  		for(var i=0;i<vm.skuList.length;i++){
	  		if(vm.skuList[i].name==sku){
	  			vm.skuDesc=vm.skuList[i].desc;
	  			vm.skuMeasure=vm.skuList[i].nature;
  	  		
  			}
  		}
  	}
  	
	function getSeedClassRequest(){
  		return farmInputService.getSeedClassRequest();
  	}
  	function getSeedClassResponse(response){
  		vm.seedClassList=[];
  		var data=response.body.data;
  		
  	   	
  		for(var i=0; i<data.length;i++){
  			var seedClass= data[i];
  			vm.seedClassList.push({name:seedClass.seedClass, desc:seedClass.seedDesc});
  		}
  	}
  	
	function getSkuRequest(){
  		return farmInputService.getSkuRequest();
  	}
  	function getSkuResponse(response){
  		vm.skuList=[];
  		var data=response.body.data;
  		
  		for(var i=0; i<data.length;i++){
  			var sku= data[i];
  			vm.skuList.push({name:sku.sku, desc:sku.skuDesc, nature:sku.natureOfMeasurement});
  		}
  	}
  	
	function getGradeRequest(){
  		return farmInputService.getGradeRequest();
  	}
  	function getGradeResponse(response){
  		vm.gradeList=[];
  		var data=response.body.data;
  		for(var i=0; i<data.length;i++){
  			var grade= data[i];
  			vm.gradeList.push({name:grade.gradeMaster, desc:grade.gradeDesc});
  		}
  	}
  	function getCategoryObject(name,categoryList){
		 for(var list=0,listLen=categoryList.length;list<listLen;list++){
			 if(categoryList[list].categoryName===name){
				 return categoryList[list];
			 }
		 }
	}

	function createFarmInput(){
		createFarmInputRequest(request).then(createFarmInputResponse);
	     }
	function createFarmInputRequest(request){
		return farmInputService.createFarmInputRequest(request);
	}
	function createFarmInputResponse(response){
		var data=response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		if(data.applicationStatusCode==1042){
			vm.displayError=false;
			//$state.go('mylisting');
			$state.go('admin',{"id":"listingDetails"},{reload:true});
			
		}else if(data.applicationStatusCode==2078){
			vm.displayError=true;
			
		}
	}
	function updateFarmInput(){
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		updateFarmInputRequest(request).then(updateFarmInputResponse); 
	}
    function updateFarmInputRequest(request){
    	return farmInputService.updateFarmInputRequest(request);
	}
	
    function view() {
		var p = $scope.vm.q;
			$window.open(p);
	}
    function createRequest(){
    	var  category= angular.extend({},{
			categoryId: vm.categoryObj.categoryId,
            categoryName: vm.categoryObj.categoryName,
            parentCategoryId: vm.categoryObj.parentCategoryId,
            level :vm.categoryObj.level
		      });
    	
    	for(var list=0;list<vm.dynamicAttr.length;list++){
    		delete vm.dynamicAttr[list].$$hashKey;
    		delete vm.dynamicAttr[list].pattern;
    		delete vm.dynamicAttr[list].maxlength;
    		delete vm.dynamicAttr[list].placeholder;
    	}
    	var inputs = angular.extend({}, {
			productId:farmInputService.action==="update"?vm.product.productId:null,
			productName : vm.productTitle,
			productDesc : vm.productDesc,
			supplierName : vm.supplierName,
			sku : vm.farmType == 1?vm.prodSku:null,
			skuDesc : vm.farmType == 1?vm.skuDesc:null,
			unitSize : vm.farmType == 1 ? vm.unitSize : 1,
			unitPrice : vm.unitPrice,
			vendorDiscount : vm.vendorDisc,
			origoDiscount : vm.origoDisc,
//			percentDiscount : vm.percentDisc,
			brand : vm.brand,
			tradeName : vm.tradeName,
			manufacturer : vm.manufacturer,
			grade : vm.farmType == 1?vm.prodGrade:null,
			gradeDesc : vm.farmType == 1?vm.gradeDesc:null,
			percentDiscount:1,
			status : farmInputService.action==="A"?vm.product.status:"A",//TODO
			itemNumber : vm.itemNumber,
			is_sponsored : vm.sponsored=="Yes"?"Y":"N",
			rootCategoryId: vm.farmType == 1 ? -1 : -3,//vm.rootCategoryId,TODO
			categoryDTO: category,
			storeId: farmInputService.getStoreId(vm,vm.storeName),
			natureOfMeasurement:vm.farmType == 1?vm.skuMeasure:null,
			stockQuantity : vm.stockQuantity,
            seasonName: vm.seasonName,
            stateName: vm.stateName,
            listAttibutes:vm.dynamicAttr,
	        deleteImages:vm.deletedImages
		});
		
    	if(farmInputService.action==="update" && vm.uploadedFiles.length > 0 && !vm.isPrimaryImageDeleted) {
       		vm.uploadedFiles.splice(0, 0, null);    			
    	}
		var fData = new FormData();
		fData.append('file', vm.uploadedFiles[0]);
        for(var i=1; i<vm.uploadedFiles.length;i++)
        {
        	fData.append('file'+i, vm.uploadedFiles[i]);
        }
		
		fData.append("data", JSON.stringify(inputs));
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		if(vm.product!=null && vm.product.productId!=null){
			updateFarmInputRequest(fData).then(updateFarmInputResponse); 
		}else{
			createFarmInputRequest(fData).then(createFarmInputResponse);
		}
		
	   // return fData;
	}
    function updateFarmInputResponse(response){
    	//console.log(response);
    	var data=response.body;
    	$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		if(data.applicationStatusCode==1045){
			//$state.go('mylisting');
			$state.go('admin',{"id":"listingDetails"},{reload:true});
			vm.displayError=false;
		}else if(data.applicationStatusCode==2078){
			vm.displayError=true;
			console.log(vm.displayError);
			console.log("2078");
		}
    }
    function submitFarmInputs() {
    	var request=createRequest();
    	
	}
				
    vm.cancelHandler = function() {
	    //$state.go('mylisting');
    	$state.go('admin',{"id":"listingDetails"},{reload:true});
    };
    vm.backToListingDetails = function(){
    	$state.go('admin',{"id":"listingDetails"},{reload:true});
    };
	function updateInputs(request) {
		//var request=createRequest();							
	  updateFarmInputRequest(request).then(updateFarmInputResponse); 
	}


} ]);
});