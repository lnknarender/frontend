'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("registrationCtrl", ['$rootScope','$scope','$state','$window','$anchorScroll','utilityService','registrationUserService','stateService','forgetPasswordService', 'loginService', '$sessionStorage','$location', '$sce','$filter','$translate',
                                    function($rootScope,$scope,$state, $window,$anchorScroll,utilityService,registrationUserService,stateService,forgetPasswordService, loginService, $sessionStorage,$location, $sce,$filter,$translate) {
	
    	var previousElement,
    		previousColor,
        	vm = this,
            isFarmer;

    	vm.noProof = true;
    	vm.userInfo = loginService.getUserInfo()||{};
        $scope.loading = true;
        // vm.selectHandler= selectHandler;
        vm.showErrorMessage = false;
        vm.userRegistration = userRegistration;
        vm.documentUploadHandler = documentUploadHandler;
        vm.registrationClick = registrationClick;
        vm.loginClick = loginClick;
        vm.userLoginOrRegistration = true;
        vm.generateOTP = generateOTP;
        vm.OTPSubmit = OTPSubmit;
        vm.backHome = backHome;
        vm.onSelectOfShippingAddress = onSelectOfShippingAddress;
        vm.documentsAdd = documentsAdd;
        vm.farmerYesDocumentHandler = farmerYesDocumentHandler;
        vm.farmerNoDocumentHandler = farmerNoDocumentHandler;
        vm.deleteRecord = deleteRecord;
        vm.permanentAddress = {};
        vm.validLoginNameHandler = validLoginNameHandler;
        vm.validEmailHandler = validEmailHandler;
        vm.validMobileNumber = validMobileNumber;
        vm.documentUploadContinueHandler = documentUploadContinueHandler;
        vm.backToHome = backToHome;
        vm.view = view;
        vm.uploadDocs = uploadDocs;
        vm.uploadStatus = [];
        vm.uploadDocuments = [];
        vm.addressProof = false;
        vm.IdProof = false;
        vm.enableButton = true;
        vm.onRadioChange = onRadioChange;
        vm.pan = false;
        vm.farmerDocuments = ['ID Proof','Address Proof' ,'TIN' ,'TAN','PAN','AADHAAR'];
        vm.nonFarmerDocuments = ['ID Proof' ,'Address Proof','VRO','Land Document' ,'PAN'];
        vm.subDocuments = ['Ration Card' ,'Passport','Electricity bill'];
        vm.addPAttr = 'VA';
        vm.addSAttr = 'DS';
        vm.acc_zeroes_whole = false;
	    vm.bankdetailsSelected = false;
	    vm.cntnBtn = true;
	    vm.accountNo = '';
	    vm.state = '';
	    vm.docAdded = false;
	    vm.interceptToCalender = function(event) {
	    	var _evt = event || window.event,
	    		_elem = _evt.target;
	    	_evt.preventDefault();
	    	if(_evt.keycode == '13' || _evt.keycode == '32' || _evt.which == '32' || _evt.which == '13') {
	    		angular.element(".ui-datepicker-trigger").trigger('click');
	    	} else if( _evt.type == "click") {
	    		angular.element(".ui-datepicker-trigger").trigger('click');
	    	}
	    	return false;
	    };
	    vm.yearErr, vm.dayLessErr, vm.dayMoreErr, vm.monthLessErr, vm.monthMoreErr = false;
       
	    vm.checkDOB = function() {
			var date = vm.dob.split('-');
			vm.dayLessErr = date[0]<1
			vm.dayMoreErr = date[0]>31; 
			vm.monthLessErr = date[1]<1; 
			vm.monthMoreErr = date[1]>12; 
			if(date[0]<1&&vm.dob==""){
				vm.dayLessErr = false;
			}
			if(date[2].length>0){
				vm.yearErr = (date[2].charAt(0) == 0);
			}
			/*if(vm.dob==undefined||vm.dob==null||vm.dob==""){
				vm.dayLessErr,vm.dayMoreErr,vm.dayMoreErr,vm.monthLessErr,vm.monthMoreErr=false;
			}*/
	    	}
	
       
       $scope.$on('$locationChangeStart', function(event, next, current){            
    	    
    	 //   event.preventDefault();            
    	});
       document.onkeydown = function (event) {
    		
    		if (!event) { /* This will happen in IE */
    			event = window.event;
    		}
    			
    		var keyCode = event.keyCode;
    		
    		if (keyCode == 8 &&
    			((event.target || event.srcElement).tagName != "TEXTAREA") && 
    			((event.target || event.srcElement).tagName != "INPUT")) { 
    			
    			if (navigator.userAgent.toLowerCase().indexOf("msie") == -1) {
    				event.stopPropagation();
    			} else {
    				alert("prevented");
    				event.returnValue = false;
    			}
    			
    			return false;
    		}
    	};

		
       vm.isDisabled = function(){
    	   if(vm.bankdetailsSelected  && vm.AddressDetailsSelected){
    		   var p = $scope.regForm.$invalid,
    		   	   q = $scope.bankForm.$invalid,
    		   	   r = $scope.shippingForm.$invalid,
    		   	   z = p || q || r;
    		   console.log(p + " q" +q + "r" + r  );
    		   return z;
    	   } else if(vm.bankdetailsSelected) {
    		   var p = $scope.regForm.$invalid,
    		   	   q = $scope.bankForm.$invalid,
    		   	   z = p||q;
    		   return z;
    	   } else if(vm.AddressDetailsSelected){
    		   var p = $scope.regForm.$invalid,
    		   	   q = $scope.shippingForm.$invalid,
    		   	   z = p || q;
    		   return z;
    	   } else {
    		   vm.cntnBtn = $scope.regForm.$invalid;
    	   }
    	   return  vm.cntnBtn
       }
       
       vm.onSelectOfAddBank = function onSelectofAddBank(){
    	   vm.isDisabled();
    	   vm.showBank = !vm.showBank;
    	   
       }
       
       vm.checkPinCodeStart = function(){
			var pin = vm.permanentAddress.pinCode_p;
			if(pin.charAt(0)=="0"){
				
				vm.pinValid = true;
			}else{
				
				vm.pinValid = false;
			}
		}
		vm.accountNoVerify = function(){
			
			var acc_num = vm.accountNo;
			var zeroes_accnt_num = 0;
			var acc_num_length = acc_num.length;
			for(var zero_counter = 0;zero_counter<=acc_num_length;zero_counter++){
				if(acc_num.charAt(zero_counter)=="0"){
					zeroes_accnt_num++;
				}
			}
			if(zeroes_accnt_num==acc_num_length){
				vm.acc_zeroes_whole = true;
			}
			else{
				vm.acc_zeroes_whole = false;
			}
		}
        
        vm.reTypePassword = reTypePassword;
        vm.retypeAccountNumber = retypeAccountNumber;
        vm.paste = paste;
        vm.failedFile = "";
        vm.unsuccessfullUpload = false;
        var doc;
        
		
		/*angular.element("#dob").datepicker({
			dateFormat: "dd-mm-yy",
			changeMonth:true,
			changeYear: true,
			yearRange: "-100:+0",
			showOn: "button",
		    buttonImage: "assets/images/Calendar1.png",
		    buttonImageOnly: true,
		    buttonText: "Select date"
		});*/
				
        function onRadioChange(){
        	vm.docAdded= false;
        	vm.documentFileSize=false;
        	vm.documentFileType=false;
			vm.idOrAddressDocumentSelected = '';
	        vm.farmerNoDocumentSelected = '';
	        vm.farmerYesDocumentSelected = '';
	        vm.documentNumber = '';
			
			vm.showErrorMessage = false;
			vm.uploadDocuments = [];
			vm.addressProof = false;
			vm.IdProof = false;
			vm.pan = false;
			vm.enableButton = true;
			vm.documentFile = '';
			angular.forEach(angular.element("input[type='file']"),function(inputElem) {
				angular.element(inputElem).val(null);
			});
		
		}
        
		function paste(e){
			e.preventDefault();
			return false;
		}
	
		vm.checkZeroAtStart = function() {
			var pin=vm.sa.pinCode_p;
			if(pin.charAt(0)=="0"){
				
				vm.ZeroValidator = true;
			} else {
				
				vm.ZeroValidator = false;
			}
		}
 
		function backToHome(){
			//'/start'
			 $state.go('start');
		}
		
		function reTypePassword(){
        	vm.passwordIncorrect=!(vm.password===vm.repassword);
        	
        }
        
        function retypeAccountNumber(){
        	vm.accountNumberIncorrect=!(+vm.accountNo===+vm.reacntnumber);
        }
  
        function validLoginNameHandler(){
        	vm.validMobileLoading = vm.validEmailLoading = false;
        	if(vm.userName==null){
        		vm.validLoginName = false;
        		vm.inValidLoginName = false;
        		vm.validLoginNameLoading = false;
        	}
			var firstLetter = parseInt(String(vm.userName).charAt(0));
		
			if(firstLetter<=9&&firstLetter>=0){
			vm.userNameFirst = true;
			}
			if(vm.userName!==undefined||vm.userName){
				vm.validLoginNameLoading = true;
				var request = angular.extend({},{
					userName:vm.userName
				});
				callValidLoginName(request).then(processValidLoginNameResponse);
			}
        };
        function  callValidLoginName(request){
        	return registrationUserService.callValidLoginName(request);
        }
        function processValidLoginNameResponse(response){
        	var res = response.body;
        	vm.validLoginNameLoading = false;
        	if(+res.applicationStatusCode===1003){
			vm.validLoginName = true,vm.inValidLoginName = false
			}else{
			vm.inValidLoginName = true,vm.validLoginName = false;
			}
        	
        }
        function validEmailHandler(){
        	vm.validMobileLoading = vm.validLoginNameLoading = false;
			if(vm.email!==undefined){
        	vm.validEmailLoading = true;
			//if((!(vm.email==""||vm.email==null||vm.email==undefined)){
        	var request = angular.extend({},{
        		emailId:vm.email
        	});
        	callValidEmail(request).then(processValidEmailResponse);
			}
        };
        function processValidEmailResponse(response){
        	var res = response.body;
        	vm.validEmailLoading = false;
        	if(+res.applicationStatusCode===1004){
        		vm.validEmail = true,vm.inValidEmail = false;
			}else{
				vm.inValidEmail = true,vm.validEmail = false;
			}
       }
       function  callValidEmail(request){
    	   return registrationUserService.callValidEmail(request);
       }
       function validMobileNumber(){
    	   vm.validEmailLoading = vm.validLoginNameLoading = false;
    	   if(vm.mobileNo==null&&$scope.regForm.tel.$invalid||vm.mobileNo==undefined&&$scope.regForm.tel.$invalid){
    		   vm.validMobile = false;
    		   vm.inValidMobile = false;
    	   }
    	   if(vm.mobileNo!==undefined&&vm.mobileNo!=null&&$scope.regForm.tel.$valid){
    		   vm.validMobileLoading = true;
    		   var request = angular.extend({},{
    			   mobileNumber:vm.mobileNo
    		   });
    		   callValidMobileNumber(request).then(processValidMobileNumberResponse);
    	   }
       };
       function processValidMobileNumberResponse(response){
    		var res = response.body;
    		vm.validMobileLoading = false;
    		if(+res.applicationStatusCode===1005){
			vm.validMobile = true,vm.inValidMobile = false
			}else{
			vm.inValidMobile = true,vm.validMobile = false;
			}
        	
        }
      function  callValidMobileNumber(request){
    	  return registrationUserService.callValidMobileNumber(request);
        }
        function deleteRecord(uploadDocument){
        	$scope.pdfcontent = '';
        	$scope.imagecontent = '';
        	vm.showErrorMessage = false;
        	vm.docAdded=false;
        	if(vm.uploadDocuments!=null){
        		
        		for(var i = 0,len = vm.uploadDocuments.length;i<len;i++){
        			if(uploadDocument.type===vm.uploadDocuments[i].type){
        				 if(vm.uploadDocuments[i].type==="ID Proof"){
        						vm.enableButton = true;
        						vm.IdProof = false;
     			   			console.log(vm.IdProof + "delete");
     			   		 }
     			   		if(vm.uploadDocuments[i].type==="Address Proof"){
     			   		vm.enableButton = true;
     			   		vm.addressProof = false;
     			   		}
     			   		
     			   		if(vm.farmer==='no'&& vm.uploadDocuments[i].type==="PAN"){
     			   			vm.enableButton = true;
     			   			vm.pan = false;
     			   				
     			   		}
     			   		
        				vm.uploadDocuments.splice(i,1);
        				
        			   		
        			   	
        			}
        		}
        	}
        }
         function farmerYesDocumentHandler(){
        	vm.docAdded=false;
        	 vm.noProof = vm.farmerYesDocumentSelected==="ID Proof"||vm.farmerYesDocumentSelected==="Address Proof";
        	 vm.onlyDocumentProof=vm.farmerYesDocumentSelected==="ID Proof"||vm.farmerYesDocumentSelected==="Address Proof";
         }
         function farmerNoDocumentHandler(){
        	 vm.docAdded=false;
        	 $("#farmerdocs").attr("required","required");
        	 vm.noProof =vm.farmerNoDocumentSelected==="ID Proof"||vm.farmerNoDocumentSelected==="Address Proof";
        	 vm.onlyDocumentProof=vm.farmerNoDocumentSelected==="ID Proof"||vm.farmerNoDocumentSelected==="Address Proof"||vm.farmerNoDocumentSelected==="VRO"
        		 ||vm.farmerNoDocumentSelected==="Land Document"||vm.farmerNoDocumentSelected==="PAN";
         }
         function bytesToSize(bytes) {
        	   if (bytes == 0) return '0 Byte';
        	   var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024))),value = Math.round(bytes / Math.pow(1024, i), 2);
        	   if(i>2){
        		   return true;
        	   }else if(i<2) {
        		   return false
        	   }else if(i===2 && value>=5){
        		   return true;
        	   }else{
        		   return false;
        	   }
        	  
        	}
      
        function registrationClick(){
        	
        	 vm.userLoginOrRegistration= true;
        	 registrationUserService.defaultSettings(vm);
        }
      function loginClick(){
    	  vm.userLoginOrRegistration=false;
        }
        init();
        function init(){
        	callAddressDetails().then(processAddressStateDataResponse);
        	if(vm.userInfo.progress!=null){
        		if(vm.userInfo === constants.DOCUMENT_UPLOAD){
        			vm.generateotpsuccess=true;
        		}
        		registrationUserService.getRegistrationFlow(vm, vm.userInfo.progress);
        	}else{
        		vm.accordionStatus={};
            	registrationUserService.defaultSettings(vm);
        	}
        	changeCurrentSelector();
        }
        function changeCurrentSelector(){
        	if($rootScope.currentSelector==undefined){
        		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
        	}else{
        		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
        		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
        	}
        	$rootScope.currentSelector = $rootScope.toState.name;
        }
        function callAddressDetails(){
        	return registrationUserService.getAddressDetails();
        }
		function processAddressStateDataResponse(response){
        	vm.statesList = response.body.data;
        	console.log(vm.statesList);
        // 	vm.districtList = response.body.data.districts;
        }
        
       
        function onSelectOfShippingAddress(){
        	vm.isDisabled();
        	if(vm.shippingAddressSelected){
        		//alert("hello");
        		 vm.isDisabled();
        		vm.sa=vm.sa||{};
        		vm.sa = angular.copy(vm.permanentAddress);
   
        		angular.element('#sfirstname').val(angular.element('#afirstname').val());
        		angular.element('#saddress').val(angular.element('#address').val());
        		angular.element('#slandmark').val(angular.element('#landmark').val());
        		angular.element('#pincode_ship_p').val(angular.element('#pincode_a').val());
        		angular.element('#scitybank').val(angular.element('#citybank').val());
        		angular.element('#sstatebank').val(angular.element('#statebank').val());
        		angular.element('#landline_p').val(angular.element('#landline_a').val());
        		angular.element('#scountry').val(angular.element('#country_a').val());
        		vm.addPAttr = 'VA';
				vm.addSAttr = 'VD';
				
        	}else{
        	
        		vm.sa.address='';
        		vm.sa.landmark='';
        		vm.sa.pinCode_p='';
        		vm.sa.landLineNo_p='';
        		vm.sa.state='';
        		vm.sa.city='';
        		angular.element('#sfirstname').val("");
        		angular.element('#saddress').val("");
        		angular.element('#slandmark').val("");
        		angular.element('#pincode_ship_p').val("");
        		angular.element('#scitybank').val("");
        		angular.element('#sstatebank').val("");
        		angular.element('#landline_p').val("");
        		angular.element('#scountry').val("");
        		vm.addSAttr = 'DS';
        		vm.addPAttr = 'VA';
				vm.isDisabled();
        	}
        	
        }
        function userRegistration(){
			 vm.sa=vm.sa||{};
            //stateService.set(constants.STATE_USER_NAME,vm.userName);
            if(vm.middleName!=null&&vm.middleName!=undefined){
           	 vm.permanentAddress.name=vm.firstName+" "+vm.middleName+" "+vm.lastName;
           	 vm.sa.name=vm.firstName+" "+vm.middleName+" "+vm.lastName;
				}
            else{
           	 vm.permanentAddress.name=vm.firstName+" "+vm.lastName;
           	 vm.sa.name=vm.firstName+" "+vm.lastName;
            }
          
           var registration = {};
            registration = angular.extend({},{
           	firstName:vm.firstName,
			    middleName:vm.middleName,
				lastName:vm.lastName,
				mobileNumber:vm.mobileNo,
				emailId:vm.email,
				loginName:vm.userName,
				password:vm.password,
				dob:vm.dob,
               gender:vm.gender,
               altNumber:vm.optionlNumber,
				permanentAddress:{
					name :vm.permanentAddress.name,
	                address :vm.permanentAddress.address,
	                landmark :vm.permanentAddress.landmark,
	                district:$("#citybank option:selected").html(),
	                state :$("#statebank option:selected").html(),
	                pinCode :vm.permanentAddress.pinCode_p,
	                landLineNo:vm.permanentAddress.landLineNo_p,
	                country:vm.permanentAddress.country,
	                addressAttribute:vm.addPAttr 
				},
				status:constants.INACTIVE,
				progress:constants.REGISTRATION,
           });
            if(vm.dob!=undefined && vm.dob.trim().length==0){
            	delete registration['dob'];
            }
            console.log(registration);
           if(vm.bankdetailsSelected){
           	 angular.extend(registration,{
								bankDetails:{	
												accountHolderName:vm.accountName,
									            accountName :vm.accountName,
											    bankName :vm.bankname,
								                accountNumber :+vm.accountNo,
								                ifscCode :vm.ifscCode,
								                branch :vm.branchname,
								                state :angular.element("#statename option:selected").html(),
								                district :vm.district
								      }
					});
            }
          
          if(vm.AddressDetailsSelected){
           	 angular.extend(registration,{
						shippingAddress:{
							name :vm.sa.name,
			                address :vm.sa.address,
			                landmark :vm.sa.landmark,
			                district:$("#scitybank option:selected").html(),
			                state :$("#sstatebank option:selected").html(),
			                //pinCode :vm.sa.pinCode_a,
			                pinCode:vm.sa.pinCode_p,
			                landLineNo:vm.sa.landLineNo_p,
			                //landLineNo:vm.sa.landLineNo_a,
			                country:vm.sa.country,
			                addressAttribute:vm.addSAttr
			             }
				});
           }
			
			registrationUserService.firstName=vm.firstName;
			//processRegistrationResponse();
			$rootScope.dataLoading = true;
			callUserRegistration(registration).then(processRegistrationResponse);
		}
	
	 
	
	 function callUserRegistration(registration) {
            vm.waitingForPageToLoad = true;

            return registrationUserService.registrationUser(registration);
        };
 
        function processRegistrationResponse(response) {
        	 var res= response.body;
        	 $rootScope.dataLoading = false;
        	 if(res.applicationStatusCode===1006){
        		 vm.fullName = vm.firstName+' '+vm.lastName;
        		 vm.userInfo.authenticated = true;
        		 vm.userInfo.status = 'Inactive';
        		 vm.userInfo.progress = 'documentUpload';
        		 vm.userInfo.userName = vm.userName;
        		 vm.userInfo.fullName = vm.fullName;
        		 vm.userInfo.productsIDs = [];
        		 vm.userInfo.origoToken = res.data[0].origoToken;
        		 vm.userInfo.shippingAddress = {};
        		 if(vm.AddressDetailsSelected) {
        			 vm.userInfo.shippingAddress.shipId = '';
        			 vm.userInfo.shippingAddress.name = vm.fullName;
        			 vm.userInfo.shippingAddress.address = vm.sa.address;
        			 vm.userInfo.shippingAddress.landmark = vm.sa.landmark;
        			 vm.userInfo.shippingAddress.district = vm.sa.city;
        			 vm.userInfo.shippingAddress.pinCode = vm.sa.pinCode_p;
        			 vm.userInfo.shippingAddress.landLineNo = vm.sa.landLineNo_p;
        			 vm.userInfo.shippingAddress.country = vm.sa.country;
        			 vm.userInfo.shippingAddress.addressAttribute = vm.shippingAddressSelected ? 'P' : 'VA';
        		 } else {
        			 vm.userInfo.shippingAddress.shipId = '';
        			 vm.userInfo.shippingAddress.name = vm.fullName;
        			 vm.userInfo.shippingAddress.address = vm.permanentAddress.address;
        			 vm.userInfo.shippingAddress.landmark = vm.permanentAddress.landmark;
        			 vm.userInfo.shippingAddress.district = vm.permanentAddress.city;
        			 vm.userInfo.shippingAddress.pinCode = vm.permanentAddress.pinCode_p;
        			 vm.userInfo.shippingAddress.landLineNo = vm.permanentAddress.landLineNo_p;
        			 vm.userInfo.shippingAddress.country = vm.permanentAddress.country;
        			 vm.userInfo.shippingAddress.addressAttribute = vm.shippingAddressSelected ? 'P' : 'VA';        			 
        		 }
        		 
        		 $sessionStorage['userInfo'] = vm.userInfo;
        		 
        		 /*
        		  var tokenResponse = res.data[0].origoToken,token = stateService.get(constants.STATE_TOKEN);
	         		 if(token===null||token===""||token===undefined){
	         			stateService.set(constants.STATE_TOKEN,tokenResponse);
	         		 }
        		 */
	         		 
        		 registrationUserService.nextUploadDocumentSetting(vm);
             	vm.farmer=constants.YES;
             	vm.farmerYesDocumentSelected="";
             	vm.farmerNoDocumentSelected="";
             	vm.idOrAddressDocumentSelected="";
	      		  angular.element('#loginuser').hide();
	     		  angular.element('#loginuserdevide').hide();
		          angular.element('#signuser').hide();
		          angular.element('#userLoggedIn').show();
		          angular.element('#signeduser').text([constants.HELLO,vm.fullName].join(" "));
		          //angular.element('#logoutuser').text([constants.LOGOUT]);
		          //angular.element('#signedinuserdevide').show();
		     }else if (res.applicationStatusCode===2009){
        		
        			vm.registrationFailed= true;
        			var errorCodes =res.errorCodes[0],code;
        			if(errorCodes.errcode==2008){
        			    code="Account Number already exists";
        			  }else if(errorCodes.errcode==2007){
        			    code="Date of Birth is in the wrong format";
        			  }else if (errorCodes.errcode==2004){
        			    code="User Name already exists";
        			  }else if(errorCodes.errcode==2005){
        			    code="Email Address already exists";
        			  }else if (errorCodes.errcode==2006){
        			    code="Mobile Number already exists";
        			 }
        			  else{
        				  code="Something went wrong please try again."
        			  }
        								 
        			vm.registraionFailedReason =code;
        			 $location.hash('regErrorMsg');
        		     
        		      $anchorScroll();
            		
            		//vm.registrationFailed=true;
        	 }
        	
        	
        }; 
        function documentsAdd(){
        	  
        	vm.documentFileType=false;
        	vm.documentFileSize=false;
        	if(previousElement!=null){
        		$(previousElement).css({"background-color" :previousColor});
        	}
        	vm.showErrorMessage= false;
        	console.log($scope.vm.q);
        	console.log($scope.vm.documentFile)
        	
        	
    	 var record={},no=['ID Proof','Address Proof','TIN','TAN','PAN','AADHAAR'],yes=['ID Proof','Address Proof','VRO','Land Document','PAN']
       	 registrationUserService.nolen=registrationUserService.nolen||[];registrationUserService.yeslen=registrationUserService.yeslen||[];
       	 if(vm.farmer=="yes"){
   		 record.type=vm.farmerNoDocumentSelected;
       	 }
       	 else{
       		record.type=vm.farmerYesDocumentSelected;
       	 }
   		 record.value=vm.noProof?vm.idOrAddressDocumentSelected:vm.documentNumber;
   		 record.fileName=vm.documentFile!=null?vm.documentFile.name:"";
   		 record.fileData=vm.documentFile||null;
   		 record.fileContent =$scope.vm.q;
   		 if(record.type==="ID Proof"){
   			vm.IdProof =true;   			 
   		 }
   		if(record.type==="Address Proof"){
   			vm.addressProof =true;
   		}
   		if(record.type==="PAN"){
   			vm.pan = true;
   		}
   		var p = false;
   		if(vm.farmer==="yes"){
   		 p = vm.IdProof && vm.addressProof;
   		}
   		if(vm.farmer==="no"){
   			p = vm.IdProof&& vm.addressProof && vm.pan;
   		}
   		
   		console.log(p);
   		vm.enableButton =!(p);
   		console.log(p);
   		 var mimeType=vm.documentFile!=null?vm.documentFile.type:null,size=vm.documentFile!=null?vm.documentFile.size:null,typeIndex=0,maxSize=0;
   		   if(mimeType!=null){
   			typeIndex = ["jpeg", "gif", "pdf", "tiff", "png"].indexOf(mimeType.split("/")[1]);
   			if(typeIndex===-1){
     			  vm.documentFileType=true;
     			  return false;
     		  }
   		   }
   		  
   		  maxSize=bytesToSize(size);
   		  
   		  if(maxSize){
   			  vm.documentFileSize=true;
   			  return false;
   		  }
   		  
   		  
   		  if(registrationUserService.nolen.length===no.length-1){
   			 vm.continueBtn=true;
    			
   		  }
   		 if(registrationUserService.yeslen.length===yes.length-1){
   			 vm.continueBtn=true;
    			
   		  }
   	
       	 if(utilityService.isCheckEmpty(vm.documentUploaded)){
       		 vm.documentUploaded=[];
       	  }
       		// vm.documentUploaded.push(record);
       	     vm.documentFile=null;
       	     $('input[type=file]').val('');
       	     $('input[type=text]').val('');
       	     vm.farmerYesDocumentSelected=constants.SELECT;
       	     vm.farmerNoDocumentSelected=constants.SELECT;
       	     vm.idOrAddressDocumentSelected=constants.SELECT;
       	     console.log(vm.uploadDocuments);
       	     if(vm.uploadDocuments.length>0){
       	    	 var x = false;
       	    	 for(var i=0; i<vm.uploadDocuments.length;i++){
       	    		 if(record.type===vm.uploadDocuments[i].type){
       	    			 previousElement = $("table").find("tr")[i+1];
       	    			 console.log(previousElement);
       	    			 previousColor = $($("table").find("tr")[i+1]).css("background-color");
       	    			 $($("table").find("tr")[i+1]).css({"background-color" : "rgba(255,0,0,0.1)"});
       	    			 vm.showErrorMessage="true";
       	    			x =true;
       	    			vm.idOrAddressDocumentSelected='';
           	        	vm.farmerNoDocumentSelected='';
           	        	vm.documentNumber='';
           	        	vm.farmerYesDocumentSelected='';
       	    		 }
       	    	 }
       	    	 if(!x){
       	    		 vm.uploadDocuments.push(record);
       	    		vm.docAdded  = true;
       	    		vm.idOrAddressDocumentSelected='';
       	        	vm.farmerNoDocumentSelected='';
       	        	vm.documentNumber='';
       	        	vm.farmerYesDocumentSelected='';
       	    	//	$scope.documentForm.$setPristine(true);
       	    		angular.forEach($scope.documentForm.$error.required, function(field) {
       	    		    field.$setPristine();
       	    		});
       	    	 }
       	     }
       	     else{
       	     vm.uploadDocuments.push(record)
       	     vm.docAdded= true;
       	    
       	     	vm.idOrAddressDocumentSelected='';
	        	vm.farmerNoDocumentSelected='';
	        	vm.documentNumber='';
	        	vm.farmerYesDocumentSelected='';
       	     }
       	  $scope.documentForm.$setPristine();
         $scope.documentForm.$setUntouched();
       	    
        }
        function documentUploadHandler(record){
     
        
        	var  listOfDocuments=[],fd = new FormData(),
        	registrationDocument = angular.extend({},{
        		loginName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
        		farmer:vm.farmer,
        		status:constants.INACTIVE,
				progress:constants.DOCUMENT_UPLOAD
        	});
     
        		angular.extend(registrationDocument,{
 				   type:record.type,
             	   value:record.value
             	   
 			});
        		
     
        			if(record.fileData!=null){
        			fd.append('file',record.fileData);
        		}
        		fd.append("data", JSON.stringify(registrationDocument));
    		    listOfDocuments.push(record);
    		    $rootScope.dataLoading = true;
    		    callDocumentUploadForRegistedUser(fd).then(documentUploadForRegistedUserResponse);
    		 
  
        	
        }
        function uploadDocs(record){
        	record.status ="In progress";
        	documentUploadHandler(record);
        	
        }
        function view(p){
        	$scope.pdfcontent = '';
        	$scope.imagecontent = '';
        	if(p.fileData.type.indexOf("image") != -1) {
            	var output = document.getElementById('image-viewer'),
        		binaryData = [];
        		binaryData.push(p.fileData);        		
        		output.src = window.URL.createObjectURL(new Blob(binaryData));
        		$scope.imagecontent = true;
        	} else {
        		var binaryData = [],
        			_file, fileURL;
        			binaryData.push(p.fileData);
        		_file = new Blob(binaryData, {type: 'application/pdf'});
        	    fileURL = window.URL.createObjectURL(_file);
        	    $scope.pdfcontent = $sce.trustAsResourceUrl(fileURL);
        	}
        }
        
        function callDocumentUploadForRegistedUser(registrationDocument){
        	
        		console.log(registrationUserService);
        		return registrationUserService.callDocumentUploadForRegistedUser(registrationDocument);
        	 
        }
        function documentUploadContinueHandler(){
        	console.log("vm.uploadDocuments");
        	console.log( vm.uploadDocuments);
        	for(doc =0;doc<vm.uploadDocuments.length;doc++){
        		
        		 documentUploadHandler(vm.uploadDocuments[doc]); 
        	}
       /* 	var request= angular.extend({},{
        		loginName:stateService.get(constants.STATE_USER_NAME)
        	});
        	//continueHandler(request).then(processContinueHandlerResponse);
        	*/
        }
		/*------*/
		function callStateDetailsHandler(){
			console.log("call state details handler")
       	return registrationUserService.getStatesDetails1();
       }
       
       function onStateChange(){
    	   console.log("on state change")
    	   callStateDetails();
       	var request= angular.extend({},{
       		stateName:vm.state
       	});
       	 callCityDetails(request).then(processCityResponse);
       }
       function callCityDetails(request){
       	return registrationUserService.getCityDetails(request);
       }
       function processCityResponse(res){
       	var data= res.body.data;
       	vm.cityList=data;
       	registrationUserService.cityList =vm.cityList;
       	
       }
		/*------*/
        function  continueHandler(request){
     	   return registrationUserService.continueHandler(request);
          }
        function processContinueHandlerResponse(response){
		    vm.generateotpsuccess=true;
        	registrationUserService.nextOTPNumberSetting(vm);
               }
        function  documentUploadForRegistedUserResponse(response){
        console.log(this);
        	console.log("in document upload for registerd user");
        	var res= response.body;
        	 $rootScope.dataLoading = false;
        	if(res.applicationStatusCode===1007){
        		console.log(doc);
        	vm.uploadStatus.push(res);
        	}
        	else if(res.applicationStatusCode===2015){
        		 vm.unsuccessfullUpload = true;
        		 console.log("upload docs");
        		 console.log(doc);
        		 console.log(vm.uploadDocuments[doc-1]);
        		 vm.failedFile= (vm.uploadDocuments[doc-1]).type;
        	}
        	if(vm.uploadStatus.length == vm.uploadDocuments.length){
        			var request= angular.extend({},{
        			     loginName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
        			      });
        			
        			continueHandler(request).then(processContinueHandlerResponse);

        	
        	}
        	console.log(vm.uploadStatus.length);
        	
        	
        }
		
        function generateOTP(){
        	angular.element('#reg_otp_generate').text($filter('translate')('origo.account.otp.resend'));
        	vm.generateOtpEnterInvalid= false;
        	var loginName = angular.extend({},{
        		loginName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
			  });
        	$rootScope.dataLoading = true;
        	callGenerateOtp(loginName).then(processGenerateOtpResponse);
        	
        }
        function callGenerateOtp(request){
			return forgetPasswordService.generateOTPUrl(request);
		}
        function processGenerateOtpResponse(response){
		      var res= response.body;
		      $rootScope.dataLoading = false;
			  if(res.applicationStatusCode===1018){
			  vm.forgetpasswordPanel=false;
			  vm.generateotpsuccess=true;
			  vm.notexistingusererror= false;
			  vm.isGenerateOTPNumber= true;
			  vm.enterLoginName=false;
			  vm.generateOtpEnter= true;
			  vm.generatedOtp = true;
			  vm.failedtosend = false;
			  vm.generateOtpEnterInvalid=false;
			  //forgetPasswordService.OTPNumber = response.body[0].otp;
			 // vm.secureUserName=response.body[0].userName;
			 // forgetPasswordService.mobileNumber = 
			  vm.mobileNumber=response.body.data[0];
			  console.log(vm.mobileNumber)
			  
			  }else if (res.applicationStatusCode === 2032) {
					vm.generatedOtp = false;
					vm.generateOtpEnterInvalid=false;
					angular.element('#generateOTPmsg').hide();
					vm.failedtosend=true;
					for (var i = 0, len = res.errorCodes.length; i < len; i++) {
						if (res.errorCodes[i].errcode === 2033) {
						}
					}
				}
			  
		}
        function generateOTPForRegistedUserResponse(response){
        	var res= response.body;
        	if(res.applicationStatusCode===1018){
        		vm.generateotpsuccess=true;
        		registrationUserService.nextOTPSubmitSetting(vm);
        		vm.genereatedOtp= res.data.otp;
        		vm.generateOtpEnterInvalid=false;
        	}else if(res.applicationStatusCode===2033 ||res.applicationStatusCode===2032){
        		vm.generateotpsuccess=false;
        		vm.generateOtpEnterInvalid=true;
        	}
        }
        
		function callGenerateOTPForRegistedUser(loginName){
        	return registrationUserService.callGenerateOTPForRegistedUser(loginName);
        }
		
		function callManualVerificalUser(){
			return registrationUserService.callManualVerificalUser();
		}
		function generateManualVerificationResponse(){
			
		}
		function processOtpNumberResponse(response){
			var res= response.body;
			if(res.applicationStatusCode===1002){
				vm.validateotpfailed=false;
				registrationUserService.nextOTPSubmitSetting(vm);
			}else if(res.applicationStatusCode===2034){
				vm.validateotpfailed=true;
				
				angular.element('#generateButton').text('ReGenerate OTP');
			}
			
		}
       function OTPSubmit(){
    	   vm.generatedOtp=false;
    	   if(utilityService.isCheckEmpty(vm.OTPNumberTyped)){
				vm.generateOtpEnterInvalid= true;
			}else{
				 var request=angular.extend({},{
					 loginName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
					 otpCode:vm.OTPNumberTyped,
					 registrationPage:true
					 
				 });
				 $rootScope.dataLoading = true;
				 validateOtp(request).then(processOtpNumberResponse);	
			}
    	  
    	   
           }
       function validateOtp(request){
			
			return forgetPasswordService.submitOtpNumberUrl(request);
		}
       function callOtpNumber(request){
    	   return  registrationUserService.validateOtp(request);
       }
   	function processOtpNumberResponse(response){
		var res= response.body;
		$rootScope.dataLoading = false;
		if(res.applicationStatusCode===1001){
			 vm.relogin=true;
     		   vm.forgetpasswordOTPNumber=false;
     		   vm.retypeforgetpassword=true;
			   vm.otpvalidated=true;
			   registrationUserService.nextOTPSubmitSetting(vm);
		}else if(res.applicationStatusCode===2034){
			
				vm.generateOtpEnterInvalid= true;
				
			for(var i=0,len=res.errorCodes.length;i<len;i++){
				if(res.errorCodes[i].errcode===2003){
					vm.forgetpasswordOTPNumber=true;
					
					}
			}
			
			
		}
		
	}
       function backHome(){
    	   $state.go('start');
       }

  
}]);
});