'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
	controllers.controller("placeorderSuccessCtrl", ['$state', '$rootScope','utilityService','stateService','$timeout','loginService','placeorderService', function($state,$rootScope, utilityService,stateService,$timeout,loginService,placeorderService) {
	
		var vm = this;
		vm.userInfo = loginService.getUserInfo();
		var productIDS = loginService.getUserInfo().productsIDS;
	 var vm = this;
	 vm.orderresponse='';
	 vm.orderresponseproduct ;
	 vm.address='';
	 vm.product='';
	 vm.orderDetails='';
	 vm.rupees ='';
	 vm.paise ='';
     vm.parmentAdddress = vm.userInfo.parmentAdddress;
     vm.deliveryBoth = false;
     var ipickup = false,shipping=false;
 
		init();
		function init(){
			vm.orderresponse = stateService.get(constants.ORDER_FULL_RESPONSE);
			vm.orderresponseproduct = stateService.get(constants.ORDER_USERDETAIL_RESPONSE);
			for(var img=0,imgLen = vm.orderresponseproduct.length;img<imgLen;img++){
				vm.orderresponseproduct[img].productTable.productImgPath = connection.storeImage+vm.orderresponseproduct[img].productTable.productImgPath;
				
			}
			/*if(vm.orderresponseproduct[0].addressDTO!=null){
				vm.address = vm.orderresponseproduct[0].addressDTO.address;
			}else if(vm.orderresponseproduct[0].locatorDTO!=null){
				var _address = vm.orderresponseproduct[0].locatorDTO;
			    vm.address={};
			    vm.address.name = _address.name;
			    vm.address.address = _address.address;
			    //vm.address.landmark = 
			    vm.address.district = _address.district;
			    vm.address.state = _address.state;
			    vm.address.country = "INDIA";
			    vm.address.pinCode = _address.pincode;
			    vm.address.wd_open_time = _address.wd_open_time;
			    vm.address.wd_close_time= _address.wd_close_time;
			    vm.address.we_open_time = _address.we_open_time;
			    vm.address.we_close_time = _address.we_close_time;	
			}
			*/
			
			vm.product=vm.orderresponseproduct;
			for(var _prod=0,_prodLen=vm.product.length;_prod<_prodLen;_prod++){
			   if(vm.product[_prod].addressDTO!=null){
				   vm.addressDTOItem = true;
				   shipping=true;
				   vm.prodAddressDTO = vm.product[_prod].addressDTO;
				   vm.shippingaddress = vm.product[_prod].addressDTO.address;
				   vm.billTo = vm.billToAddress = vm.address = vm.product[_prod].addressDTO.address;
				   
			   }else if(vm.product[_prod].locatorDTO!=null){
				   vm.locatorDTOItem = true;
				   ipickup=true;
				   vm.prodLocatorDTO = vm.product[_prod].locatorDTO;
				   var _address = vm.product[_prod].locatorDTO;
				   vm.billTo = vm.userInfo.parmentAdddress;
				   if(vm.ipickupAddress==null){
					    vm.ipickupAddress = {};
					    vm.address={};
					     vm.ipickupAddress.name = vm.address.name =_address.name;
					     vm.ipickupAddress.address = vm.address.address =_address.address;
					    //vm.address.landmark = 
					    vm.ipickupAddress.district = vm.address.district = _address.district;
					    vm.ipickupAddress.state = vm.address.state = _address.state;
					    vm.ipickupAddress.country =  vm.address.country = "INDIA";
					    vm.ipickupAddress.pinCode =  vm.address.pinCode = _address.pincode;
					    vm.ipickupAddress.wd_open_time = vm.address.wd_open_time = _address.wd_open_time;
					    vm.ipickupAddress.wd_close_time= vm.address.wd_close_time=_address.wd_close_time;
					    vm.ipickupAddress.we_open_time = vm.address.we_open_time =_address.we_open_time;
					    vm.ipickupAddress.we_close_time = vm.address.we_close_time =_address.we_close_time;
				   }
				   	
			   }
			}
			
			if(shipping && ipickup){
				vm.deliveryBoth = !vm.deliveryBoth;
				vm.address = vm.billToAddress;
				
				
			}
			counterSetOfCart();
		}
	       vm.convert = function(i){
               var i = parseInt(i);
               var units =["","One","Two","Three","Four",
                      "Five","Six","Seven","Eight","Nine","Ten",
                      "Eleven","Twelve","Thirteen","Fourteen","Fifteen",
                      "Sixteen","Seventeen","Eighteen","Nineteen"];
               var tens = ["","","Twenty","Thirty","Forty","Fifty",
                      "Sixty","Seventy","Eighty","Ninety"];
      if( i < 20)  return units[i];
      if( i < 100) return tens[parseInt(i/10)] + ((i % 10 > 0)? " " + vm.convert(i % 10):"");
      if( i < 1000) return units[parseInt(i/100)] + " Hundred " + ((i % 100 > 0)?"  " + vm.convert(i % 100):"");
      if( i < 10000) return units[parseInt(i/1000)] + " Thousand" + ((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
      if(i >10000&&i<20000) return units[parseInt(i/1000)] +" Thousand " +((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
      if(i<100000) return tens[parseInt(i/10000)]+" "+units[parseInt((i/1000)%10)] +"Thousand" +((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
      if(i<2000000) return units[parseInt(i/100000)]+" Lakh "+vm.convert(i%100000);
      if(i<10000000) return tens[parseInt(i/1000000)]+" "+ units[parseInt((i/100000)%10)]+" Lakh "+vm.convert(i%100000);
               
        }


		vm.convertToNumberName = function(){
			var rupees;
			var paise;
			var i= vm.orderresponse.amountTotal + (vm.orderresponse.amountTotal *0.05);
			console.log("Rupeee"+i);
				i = Math.round(i*100)/100;
			var number = (i.toString()).split('.');
			console.log(number);
			rupees = vm.convert(parseInt(number[0]));
			if(number.length>1){
			paise = vm.convert(parseInt(number[1]));
			rupees= rupees + ' rupees and ' + paise +'  paise only.' ;
			}
			return rupees+'/-';
			 
		}
		
		
	
	
		function counterSetOfCart(){
			 var orderObj = placeorderService.getOrderDetailsOnSuccess();
			 if(!orderObj.isBuyNow)
				 {
				 	var orderDetailsArray = orderObj.orderDetails;
				 	var orderProductIds = [];
				 	for(var i=0; i<orderDetailsArray.length; i++)
				 	{
				 		orderProductIds.push(orderDetailsArray[i].productId);
				 	}
				 	for(var count=0;count<productIDS.length;count++){
				 	if(isInArray(productIDS[count],orderProductIds))
					 {
					 	productIDS.splice(count,1);
					 	count-=1;
					 }
				 }
			 var val = productIDS.length;
				angular.element('#cartcounterlist').text(val);
				if(val===0)
				  {
				  	vm.userInfo.pincode = null;
				  }
			 }
			 
		 }
		
		function isInArray(value, array) {
			  return array.indexOf(value) > -1;
			}
		vm.download = function(){
			console.log("download");
			angular.element("#table_div").css("height","100%");
			$rootScope.dataLoading = true;
			 var pdf = new jsPDF();

			    var specialElementHandlers = {
			    '#table_div': function (element, renderer) {
			        return true;
			        }
			    };

			    pdf.addHTML($('#table_div').get(0), function() {
			    	var filename = 'invoice_'+vm.orderresponse.orderId;+'.pdf';
			        pdf.save(filename);
			    });
			    
			    $timeout(function() {
			    	angular.element("#table_div").css("height","0px");
			    	$rootScope.dataLoading = false;
			    }, 200);
		}
}]);
});
