define(
		[ 'angular', 'controllers-module', 'underscore' ],
		function(angular, controllers, underscore) {controllers.controller("adminRolesCtrl",
			[
				'$scope','$rootScope',
				'$state','$window',
				'utilityService',
				'stateService',
				'$q',
				'ajaxService',
				'urlService',
				'$timeout','$stateParams','adminRolesService','userWishlistService',
				function($scope,$rootScope, $state, $window, utilityService,
						stateService, $q, ajaxService,
						urlService, $timeout,$stateParams,adminRolesService,userWishlistService) {
					var vm = this;
					vm.enterSuccess = false;
					vm.walletField = false;
					vm.ofAddrApproval=false;
					vm.currentTab = 'welcome';
					vm.statusList = [{'statusName':'Order Placed'},{'statusName':'Approved'},{'statusName':'Shipped'},{'statusName':'Delivered'}];
					vm.cancelStatus = [{'statusName':'Cancelled'}];
					vm.getOrderDetails = getOrderDetails;
					
					vm.getUsers = getUsers; 
					init();
					vm.goToOrderDetails = function(){
						$state.go('admin',{"id":"orderDetails"},{reload:true});
					};
					vm.goToActiveUsers = function(){
						$state.go('admin',{"id":"activeUsers"},{reload:true});
					};
					vm.goToDeactivateUsers = function(){
						$state.go('admin',{"id":"deactiveUsers"},{reload:true});
					};
					vm.goToReadyToActivateUsers = function(){
						$state.go('admin',{"id":"readyToActivate"},{reload:true});
					};
					vm.goToAllUsers = function(){
						$state.go('admin',{"id":"allUsers"},{reload:true});
					};
					vm.goToWalletDetails = function(){
						$state.go('admin',{"id":"walletDetails"},{reload:true});
					};
					vm.goToCancelledOrders = function(){
						$state.go('admin',{"id":"cancelledOrders"},{reload:true});
					};
					vm.goToBuyerDemands = function(){
						$state.go('admin',{"id":"buyerDemands"},{reload:true});
					};
					vm.goToListingDetails = function(){
						$state.go('admin',{"id":"listingDetails"},{reload:true});
					};
					$scope.gridOptions = {
						rowHeight : 40,
						enableColumnMenu : false,
						paginationPageSizes : [ 10, 50, 100 ],
						paginationPageSize : 10,
						rowEditWaitInterval : -1,
						 enableFiltering: true,
						
					};
					function getUsers() {
						// show all users in ui-grid
						var statusDetails = {
							status : ""
						};
						$rootScope.dataLoading = true;
				    	$rootScope.dataStillLoading = true;
						getUsersRequest(statusDetails).then(getUsersResponse);
					}
					vm.addMoneyForAUser = function(user) {
						/*$scope.walletForm.$setPristine();
						$scope.walletForm.$setUntouched();*/
						vm.user_requested = user;
					}
					vm.addSubCategory = function() {
						// give form to fill to add new
						// subcat
					}
					function getUsersRequest(statusDetails) {
						return adminRolesService.getUsersReq(statusDetails);
					}
					function getUsersResponse(response) {
						var res = response.body;
						if (res.applicationStatusCode == 1025) {
							vm.walletField = true;
							vm.users = res.data;
						}
						$scope.gridOptions.data = vm.users;
						$scope.gridOptions.columnDefs =[
										{
											field : 'firstName',
											width : '18%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											enableFiltering : true,
										},
										{
											field : 'lastName',
											width : '18%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											enableFiltering : true,
										},
										{
											field : 'mobileNo',
											width : '12%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											type:'number',
										},
										{
											field : 'walletAmountDTOList',
											width : '12%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											name: 'Farm Input',
											type:'number',
											enableFiltering : false,
											cellTemplate : "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD'>{{field.inputUsageAmnt | number:2}}</div></div>"
										},
										{
											field : 'walletAmountDTOList',
											width : '14%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											name: 'Commodities',
											type:'number',
											enableFiltering : false,
											cellTemplate : "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD'>{{field.commodityUsageAmnt | number:2}}</div></div>"
										},
										{
											field : 'walletAmountDTOList',
											width : '12%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											name: 'Equipment',
											type:'number',
											enableFiltering : false,
											cellTemplate : "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD'>{{field.machinaryUsageAmnt | number:2}}</div></div>"
										},
										{
											field : 'actions',
											width : '13%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : false,
											enableFiltering : false,
											cellTemplate : '<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#addMoney" ng-click="grid.appScope.vm.addMoneyForAUser(row.entity)">Add Money</a>'
			
										}, ]
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);
					}
					vm.addMoneyToWallet = function(user_detail) {
						var amount = parseFloat(user_detail.amountEntered);
						var purpose = parseInt(vm.user_requested.category);
						var req = angular.extend({},
										{
											loginName : user_detail.loginName,
											amount : amount,
											purposeUsage : purpose
										});
						$rootScope.dataLoading = true;
				    	$rootScope.dataStillLoading = true;
						addMoneyToUserWalletReq(req).then(addMoneyToUserWalletRes);
					}
					function addMoneyToUserWalletReq(request) {
						return adminRolesService.addMoneyToWallet(request);
					}
					function addMoneyToUserWalletRes(response) {
						var res = response.body;
						vm.userCurrentBal=0;
						$rootScope.dataLoading = false;
				    	$rootScope.dataStillLoading = false;
						if (res.applicationStatusCode == 1054) {
							vm.enterSuccess = true;
							vm.userCurrentBal=res.data[0].amount;
							switch(res.data[0].purposeUsage){
							case 1:
								vm.purposeUsage="Farm Inputs";
								break;
							case 2:
								vm.purposeUsage="Equipments";
								break;
							case 3:
								vm.purposeUsage="Commodities";
								break;
							}
							vm.amountAdded = "Amount updated";
						}
					}
					vm.clearContent=function(){
						vm.purposeUsage=null;
						vm.enterSuccess=false;
						/*$scope.walletForm.$setPristine();
						$scope.walletForm.$setUntouched();*/
					}
					function activateAddress(){
						vm.walletField = false;
						vm.ofAddrApproval=true;
						var statusDetails = {
								status : "inactive"
							};
						$rootScope.dataLoading = true;
				    	$rootScope.dataStillLoading = true;
							getUsersRequest(statusDetails).then(getInActiveUsersResponse);
					}
					function filterUsers(source,criteria){
						//return otpVerification phase users
						var filteredUsers=[];
						for(var user_index=0;user_index<source.length;user_index++){
							if(source[user_index].progressStatus==criteria){
								filteredUsers.push(source[user_index]);
							}
						}
					return filteredUsers;
					}
					function getInActiveUsersResponse(response){
						var res=response.body;
						vm.otpPhase="otpVerification";
						if (res.applicationStatusCode == 1025) {
							vm.inActiveUsers=filterUsers(res.data,vm.otpPhase);
						}
						$scope.gridOptions.data = vm.inActiveUsers;
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);//
						//console
						$scope.gridOptions.columnDefs =
										[
            								{
          									field : 'firstName',
          									width : '15%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : true,
          									enableFiltering: true,
          								},
          								{
          									field : 'lastName',
          									width : '15%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : true,
          									enableFiltering: true,
          								},
          								{
          									field : 'mobileNo',
          									width : '18%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : true,
          									enableFiltering: true,
          									type:'number',
          								},
          								{
          									field : 'progressStatus',
          									width : '20%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : true,
          									enableFiltering: false,
          								},
          								{
          									field : 'userStatus',
          									width : '15%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : true,
          									enableFiltering: false,
          								},
          								{
          									field : 'actions',
          									width : '15%',
          									enableCellEdit : false,
          									enableColumnMenu : false,
          									enableSorting : false,
          									enableFiltering: false,
          									cellTemplate : '<div><input ng-disabled="!(row.entity.progressStatus==grid.appScope.vm.otpPhase)" ng-click="grid.appScope.vm.collectOTPPhaseUsers(row.entity)" type="checkbox"> Approve<br/></div>'
          						}, ]
					
					}
					vm.addressToBeVerifiedUsers=[];
					vm.collectOTPPhaseUsers=function(item){
						var unchecked=false,delIndex=-1;
						for(var user=0; user<vm.addressToBeVerifiedUsers.length;user++){
							if(vm.addressToBeVerifiedUsers[user]!=null&&vm.addressToBeVerifiedUsers[user]!=undefined){
							if(item.loginName==vm.addressToBeVerifiedUsers[user].loginName){
								unchecked=true;
								delIndex=user;
							}
							}
						}
						if(unchecked==true){
						vm.addressToBeVerifiedUsers = vm.addressToBeVerifiedUsers.filter(function(obj){
							return item != obj;
						});
			
						}else{
							vm.addressToBeVerifiedUsers.push(item);
						}
					
					}
					vm.approveAddress=function(){
						for(var user=0;user<vm.addressToBeVerifiedUsers.length;user++){
							vm.addressToBeVerifiedUsers[user].userStatus="active";
							vm.addressToBeVerifiedUsers[user].progressStatus="addressVerified";
						}
						var usersDetails = {
							users:vm.addressToBeVerifiedUsers
						};
					sendAddrVerifiedUsersToActivateReq(usersDetails).then(sendAddrVerifiedUsersToActivateRes);
					}
					function sendAddrVerifiedUsersToActivateReq(request){
						var url = urlService.addrApprovalUsers();
						return ajaxService.doPost(url, {},request);
					}
					function sendAddrVerifiedUsersToActivateRes(response){
						var res=response.body;
						if(res.applicationStatusCode==1055){
							vm.addressToBeVerifiedUsers=[];
							activateAddress();
						}
					}
					
					function getInactiveUsersResponse(response){
						var res=response.body;
						if(res.applicationStatusCode==1054){
							//alert();
						}
					}
					vm.checkedItems=[];
					vm.approve=function(item){
						
						var unchecked=false,delIndex=-1;
						for(var user=0; user<vm.checkedItems.length;user++){
							if(vm.checkedItems[user]!=null&&vm.checkedItems[user]!=undefined){
							if(item.loginName==vm.checkedItems[user].loginName){
								unchecked=true;
								delIndex=user;
							}
							}
						}
						if(unchecked==true){
							vm.checkedItems = vm.checkedItems.filter(function(obj){
								return item != obj;
							});
			
						}else{
							vm.checkedItems.push(item);
						}
					
					}
					vm.approveAddrHandler=function(){
						
							//give a call
							var usersDetails = {
									users:vm.checkedItems
								};
								sendUsersDetailsForAddrApprovalReq(usersDetails).then(sendUsersDetailsForAddrApprovalRes);
					}
					function sendUsersDetailsForAddrApprovalReq(request){
						var url = urlService.addrApprovalUsers();
						return ajaxService.doPost(url, {},request);
					}
					function sendUsersDetailsForAddrApprovalRes(response){
						var res=response.body;
						if(res.applicationStatusCode==1055){
							//	vm.checkedItems=[];
						}
					}
					
					function getOrderDetails(){
						var request = {
								ordertype:""
						};
						$rootScope.dataLoading = true;
		    			$rootScope.dataStillLoading = true;
						getAllorderDetails(request).then(processOrderDetailsResponse);
					}
					function getAllorderDetails(req){
						return adminRolesService.getAllOrdersDetails(req);
					}
					function processOrderDetailsResponse(response){
						var res = response.body;
						if(res.applicationStatusCode==2048){
				    		vm.ordersNotFound=false;
				    		var products= res.data;
				    		for(var prod=0;prod<products.length;prod++){
								products.actions;
							}
				    		for(var prod=0;prod<products.length;prod++){
				    			var prodItem=products[prod].userOrderDetailsDTO;
					    		for(var img=0,_imgLen=prodItem.length;img<_imgLen;img++){
					    			prodItem[img].productTable.productImgPath = connection.store+"images/"+prodItem[img].productTable.productImgPath;
					    		}
				    		}
				    		vm.orders_requested=products;
				    		$scope.gridOptions.columnDefs =[ 
				    		                                /*{
				    		                                	field: 'userOrderDetailsDTO', 
				    		                                	displayName:'origo.submitdemand.prodName', 
				    		                                	headerCellFilter:'translate', 
				    		                                	enableCellEdit: false, 
				    		                                	enableColumnMenu: true, 
				    		                                	enableSorting: true, 
				    		                                	enableHiding: false , 
				    		                                	width:'20%',
				    		                                	enableFiltering: true,
				    		                                	cellTemplate: "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD' data-toggle='tooltip' title='{{field.productTable.productName}}'>{{field.productTable.productName}}</div></div>" 
				    		                               },*/	
				    		                               { 
				    		                            	   field: 'orderId',  
				    		                            	   displayName:'origo.orders.orderNumber', 
				    		                            	   headerCellFilter:'translate', 
				    		                            	   enableCellEdit: false, 
				    		                            	   enableColumnMenu: true, 
				    		                            	   enableHiding: false ,
				    		                            	   enableSorting: true,
				    		                            	   width:'20%',
				    		                            	   type:'number',
				    		                            	   enableFiltering: true
				    		                               },
				    		                               { 
				    		                            	   field: 'orderDate',  
				    		                            	   displayName:'origo.orders.orderDate', 
				    		                            	   headerCellFilter:'translate', 
				    		                            	   enableCellEdit:false, 
				    		                            	   enableColumnMenu: true, 
				    		                            	   enableHiding: false , 
				    		                            	   enableSorting: true,
				    		                            	   width:'15%',
				    		                            	   enableFiltering: false,
				    		                            	   sort: { direction: 'desc', priority: 0 }
				    		                               },
				    		                               { 
				    		                            	   field: 'amountTotal', 
				    		                            	   displayName:'origo.orders.total', 
				    		                            	   headerCellFilter:'translate', 
				    		                            	   type:'number', 
				    		                            	   enableCellEdit: false, 
				    		                            	   enableColumnMenu: true, 
				    		                            	   enableHiding: false , 
				    		                            	   enableSorting: true,
				    		                            	   width:'10%',
				    		                            	   enableFiltering:true
				    		                            	 },
				    		                               { 
				    		                            	   field: 'orderStatus',  
				    		                            	   displayName:'origo.wallet.status', 
				    		                            	   headerCellFilter:'translate', 
				    		                            	   enableCellEdit:false, 
				    		                            	   enableColumnMenu: true, 
				    		                            	   enableHiding: false , 
				    		                            	   enableSorting: true,
				    		                            	   width:'15%',
				    		                            	   enableFiltering:false
				    		                               },
				    		                               { 
				    		                            		field: 'tpaymentMode.paymentDesc', 
				    		                            		displayName:'origo.order.payment.mode', 
				    		                            		headerCellFilter:'translate', 
				    		                            		enableCellEdit: false, 
				    		                            		enableColumnMenu: true, 
				    		                            		enableHiding: false , 
				    		                            		enableSorting: true, 
				    		                            		width:'20%',
				    		                            		enableFiltering:true
				    		                            	},
				    		                            	{ 
				    		                            		field: 'actions', 
				    		                            		displayName:'origo.demand.actions', 
				    		                            		headerCellFilter:'translate',
				    		                            		enableCellEdit:false, 
				    		                            		enableColumnMenu: false, 
				    		                            		enableHiding: false , 
				    		                            		enableSorting: false,
				    		                            		width:'20%',
				    		                            		enableFiltering:false,
				    		                            		cellTemplate:'<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#viewOrders" ng-click="grid.appScope.vm.viewOrder(row.entity)">View</a><a class="ui-grid-cell-contents" data-toggle="modal" data-target="#viewStatus" ng-click="grid.appScope.vm.statusOrder(row.entity)">Transact</a>' 
				    		                            	} ]
				    		
				    		$scope.gridOptions.data = vm.orders_requested;
				    		$timeout(function() {
				    			$(window).resize();
				    			$rootScope.dataLoading = false;
					    		$rootScope.dataStillLoading = false;
				    	    }, 100);
						}
					    if(res.applicationStatusCode==2049){
					    	vm.ordersNotFound=true;
					    	$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
					    }
						
					}
					vm.statusOrder = function(order){
						vm.order = order;
						if(vm.order.tpaymentMode.paymentDesc=='DD'||vm.order.tpaymentMode.paymentDesc=='POD'||vm.order.tpaymentMode.paymentDesc=='COD'){
							vm.statusDisplay = vm.statusList.concat(vm.cancelStatus);
						}else{
							vm.statusDisplay = vm.statusList;
						}
						vm.statusChange = vm.order.orderStatus;
						//console.log(vm.statusDisplay);
					}
					vm.downloadInvoice= function(){
						angular.element("#table_div").css("height","100%");
						$rootScope.dataLoading = true;
						var pdf = new jsPDF();
						var specialElementHandlers = {
						    '#table_div': function (element, renderer) {
						        return true;
						    }
						};
						pdf.addHTML($('#table_div').get(0), function() {
							var filename = 'invoice_'+vm.order.orderId+'.pdf';
						    pdf.save(filename);
						});
						$timeout(function() {
						  	angular.element("#table_div").css("height","0px");
						  		$rootScope.dataLoading = false;
						}, 200);
					}
					
					vm.viewOrder = function(order){
						vm.ship=false;
						vm.store=false;
						vm.order= order;
						vm.deliveryBoth = false;
						vm.orderresponse=vm.order;
						if(vm.order.shippingAddress!=null){
							vm.shipAddress = vm.order.shippingAddress.address;
							vm.ship=true;
						}
						for(var i =0;i<vm.order.userOrderDetailsDTO.length;i++){
							if(vm.order.userOrderDetailsDTO[i].productTable.storeLocatorDTO!=null && vm.order.userOrderDetailsDTO[i].deliveryType!='SHIPPING'){
								vm.storeAddress = vm.order.userOrderDetailsDTO[i].productTable.storeLocatorDTO;
								vm.store=true;
							}
						}
						var ipickup = false,shipping=false;
						vm.product = vm.order.userOrderDetailsDTO;
						for(var _prod=0,_prodLen=vm.product.length;_prod<_prodLen;_prod++){
							var deliveryType = vm.product[_prod].deliveryType;
							if(deliveryType==="SHIPPING"){
							   shipping=true;
							   vm.shippingaddress = vm.order.shippingAddress.address;
							   vm.billTo = vm.billToAddress = vm.address = vm.order.shippingAddress.address;
							}else{
								vm.locatorDTOItem = true;
								ipickup=true;
								var _address = vm.product[_prod].locatorDTO;
								vm.billTo = vm.userInfo.parmentAdddress;
								if(vm.ipickupAddress==null){
								    vm.ipickupAddress = {};
								    vm.address={};
								    vm.ipickupAddress.name = vm.address.name =_address.name;
								    vm.ipickupAddress.address = vm.address.address =_address.address;
								    vm.ipickupAddress.district = vm.address.district = _address.district;
								    vm.ipickupAddress.state = vm.address.state = _address.state;
								    vm.ipickupAddress.country =  vm.address.country = "INDIA";
								    vm.ipickupAddress.pinCode =  vm.address.pinCode = _address.pincode;
								    vm.ipickupAddress.wd_open_time = vm.address.wd_open_time = _address.wd_open_time;
								    vm.ipickupAddress.wd_close_time= vm.address.wd_close_time=_address.wd_close_time;
								    vm.ipickupAddress.we_open_time = vm.address.we_open_time =_address.we_open_time;
								    vm.ipickupAddress.we_close_time = vm.address.we_close_time =_address.we_close_time;
								}
							}
					   
						}
						if(shipping && ipickup){
							vm.deliveryBoth = !vm.deliveryBoth;
							vm.address = vm.billToAddress;
						}
					}
					vm.orderStatusChange = function(){
						var request = angular.extend({},
								{
									orderId:vm.order.orderId,
									orderStatus:vm.statusChange
								});
						$rootScope.dataLoading = true;
						orderStatusChangeDetails(request).then(processOrderStatusChangeDetailsResponse);
					}
					function orderStatusChangeDetails(request){
						return adminRolesService.orderStatusChange(request);
					}
					function processOrderStatusChangeDetailsResponse(response){
						//console.log(response);
						//angular.element('#status-modal').trigger('click');--todo
						getOrderDetails();
					}
					function inActiveUsers(){
						var statusDetails = {
								status: "inactive"
							};
							$rootScope.dataLoading = true;
					    	$rootScope.dataStillLoading = true;
							getInactiveUsersRequest(statusDetails).then(getInactiveUsersResponse);
					}
					function getInactiveUsersRequest(request){
						return adminRolesService.getUsersReq(request);
					}
					function getInactiveUsersResponse(response){
						var res = response.body;
						if (res.applicationStatusCode == 1025) {
							vm.inactiveUsers = res.data;
						}
						$scope.gridOptions.data = vm.inactiveUsers;
						$scope.gridOptions.columnDefs =[
										{
											field : 'firstName',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'lastName',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'mobileNo',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											type:'number',
										},
										
										{
											field : 'userStatus',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: false,
										},
										/*{
											field : 'progressStatus',
											width : '17%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: false,
										},*/
										{
											field : 'actions',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : false,
											enableFiltering: false,
											cellTemplate : '<div><input class="ui-grid-cell-contents" ng-click="grid.appScope.vm.collectInactiveUsers(row.entity)" type="checkbox"> Activate<br/></div>'
			
										}, ]
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);
					
					}
					vm.arrayOfInactiveUsers=[];
					vm.collectInactiveUsers=function(item){
						var unchecked=false,delIndex=-1;
						for(var user=0; user<vm.arrayOfInactiveUsers.length;user++){
							if(vm.arrayOfInactiveUsers[user]!=null&&vm.arrayOfInactiveUsers[user]!=undefined){
							if(item.loginName==vm.arrayOfInactiveUsers[user].loginName){
								unchecked=true;
								delIndex=user;
							}
							}
						}
						if(unchecked==true){
						vm.arrayOfInactiveUsers = vm.arrayOfInactiveUsers.filter(function(obj){
							return item != obj;
						});
			
						}else{
							
							vm.arrayOfInactiveUsers.push(item);
							
						}
					}
					vm.activateHandler=function(){
						for(var user=0;user<vm.arrayOfInactiveUsers.length;user++){
							vm.arrayOfInactiveUsers[user].userStatus="active";
							//vm.arrayOfInactiveUsers[user].progressStatus="addressVerified";
						}
						var usersDetails = {
								users:vm.arrayOfInactiveUsers
							};
						sendInActivatedUsersToActivateReq(usersDetails).then(sendInActivatedUsersToActivateRes);
					}
					function sendInActivatedUsersToActivateReq(request){
						var url = urlService.addrApprovalUsers();
						return ajaxService.doPost(url, {},request);
					}
					function sendInActivatedUsersToActivateRes(response){
						var res=response.body;
						if(res.applicationStatusCode==1055){
							vm.arrayOfInactiveUsers=[];
							inActiveUsers();
						}
					}
					function activeUsers(){
						//get all active user
						var statusDetails = {
								status: "active"
							};
							$rootScope.dataLoading = true;
					    	$rootScope.dataStillLoading = true;
							getActiveUsersRequest(statusDetails).then(getActiveUsersResponse);
					}
					function getActiveUsersRequest(request){
						return adminRolesService.getUsersReq(request);
					}
					function getActiveUsersResponse(response){
						var res = response.body;
						if (res.applicationStatusCode == 1025) {
							vm.users = res.data;
						}
						$scope.gridOptions.data = vm.users;
						$scope.gridOptions.columnDefs =[
										{
											field : 'firstName',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'lastName',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'mobileNo',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											type:'number',
										},
										
										{
											field : 'userStatus',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: false,
										},
										/*{
											field : 'progressStatus',
											width : '17%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
										},*/
										{
											field : 'actions',
											width : '20%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : false,
											enableFiltering: false,
											cellTemplate : '<div><input class="ui-grid-cell-contents" ng-click="grid.appScope.vm.collectActiveUsers(row.entity)" type="checkbox"> Deactivate<br/></div>'
			
										}, ]
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);
					
					}
					vm.arrayOfActiveUsers=[];
					vm.collectActiveUsers=function(item){
						var unchecked=false,delIndex=-1;
						for(var user=0; user<vm.arrayOfActiveUsers.length;user++){
							if(vm.arrayOfActiveUsers[user]!=null&&vm.arrayOfActiveUsers[user]!=undefined){
							if(item.loginName==vm.arrayOfActiveUsers[user].loginName){
								unchecked=true;
								delIndex=user;
							}
							}
						}
						if(unchecked==true){
						vm.arrayOfActiveUsers = vm.arrayOfActiveUsers.filter(function(obj){
								return item != obj;
						});
			
						}else{
							vm.arrayOfActiveUsers.push(item);
					}
						console.log(vm.arrayOfActiveUsers);
					}
					vm.deactivateHandler=function(){
						for(var user=0;user<vm.arrayOfActiveUsers.length;user++){
							vm.arrayOfActiveUsers[user].userStatus="deactive";
						}
						var usersDetails = {
								users:vm.arrayOfActiveUsers
							};
							sendActivatedUsersToDeactivateReq(usersDetails).then(sendActivatedUsersToDeactivateRes);
					}
					function sendActivatedUsersToDeactivateReq(request){
						var url = urlService.addrApprovalUsers();
						return ajaxService.doPost(url, {},request);
					}
					function sendActivatedUsersToDeactivateRes(response){
						var res=response.body;
						if(res.applicationStatusCode==1055){
							vm.arrayOfActiveUsers=[];
							activeUsers();
						}
					}
					function showAllUsers(){
						var statusDetails = {
								status: ""
							};
							$rootScope.dataLoading = true;
					    	$rootScope.dataStillLoading = true;
							getAllUsersRequest(statusDetails).then(getAllUsersResponse);
					}
					function getAllUsersRequest(request){
						return adminRolesService.getUsersReq(request);
					}
					function getAllUsersResponse(response){
						var res = response.body;
						if (res.applicationStatusCode == 1025) {
							vm.allUsers = res.data;
						}
						$scope.gridOptions.data = vm.allUsers;
						$scope.gridOptions.columnDefs =[
										{
											field : 'firstName',
											width : '18%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'lastName',
											width : '18%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
										},
										{
											field : 'mobileNo',
											width : '18%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: true,
											type:'number',
										},
										{
											field : 'userStatus',
											width : '12%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: false,
										},
										{
											field : 'progressStatus',
											width : '17%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : true,
											enableFiltering: false,
										},
										{
											field : 'actions',
											width : '17%',
											enableCellEdit : false,
											enableColumnMenu : false,
											enableSorting : false,
											enableFiltering: false,
											//cellTemplate : '<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#addMoney" ng-click="grid.appScope.vm.addMoneyForAUser(row.entity)">Add Money</a>'
			
										}, ]
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);
					}
					function getBuyerDemands(){
						var request = {
								loginName: ""
							};
						$rootScope.dataLoading = true;
					    $rootScope.dataStillLoading = true;
						getAllBuyerDemandsRequest(request).then(getAllDemandsResponse);
					}
					function getAllBuyerDemandsRequest(request){
						return adminRolesService.getBuyerDemands(request);
					}
					function getAllDemandsResponse(response){
						var response = response.body.data;
						$scope.gridOptions.data = response;
						$scope.gridOptions.columnDefs =[
												//{ field: 'category',enableFiltering:false, width:'20%',displayName:'origo.demand.category', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true,},	
												{ field: 'getFullName()', enableFiltering:false, width:'15%',displayName: 'Full Name', headerCellFilter:'translate', sort: { direction: 'desc', priority: 0 }, enableCellEdit: false, enableColumnMenu: false,  enableSorting: true},
												{ field: 'productName',enableFiltering:false, width:'30%', displayName: 'origo.submitdemand.prodName',  headerCellFilter:'translate',enableCellEdit: false, enableColumnMenu: false, enableSorting: true,
													  cellTemplate:'<div class="ui-grid-cell-contents word-wrap"><div data-toggle="tootltip" title="{{row.entity.productName}}">{{row.entity.productName}}</div></div>'},	
												/*{ field: '', width:'19%',name: 'Price (Rs.)', displayName: 'origo.cart.price', enableCellEdit:false, headerCellFilter:'translate', enableColumnMenu: false, enableSorting: true,
													  cellTemplate:"<div class='ui-grid-cell-contents word-wrap'>Min:{{row.entity.minPrice}}  &nbsp;&nbsp;&nbsp;&nbsp; Max:{{row.entity.maxPrice}}</div>"},*/
												//   { field: 'maxPrice', name: 'Maximum Price', enableCellEdit:false, enableColumnMenu: true, enableSorting: true},
												{ field: 'updatedDate', enableFiltering:false, width:'15%',displayName: 'origo.demand.createdDate', headerCellFilter:'translate', sort: { direction: 'desc', priority: 0 }, enableCellEdit: false, enableColumnMenu: false,  enableSorting: true},
												{ field: 'demandDate',enableFiltering:false,width:'15%', displayName: 'origo.submitdemand.expectedDate',  headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true},
												/*{ field: 'location', width:'12%', displayName: 'origo.submitdemand.location', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true},*/
												{ field: 'actions', enableFiltering:false,width:'25%', displayName: 'origo.demand.actions', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: false,
												cellTemplate: 
														'<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#viewDemands" ng-click="grid.appScope.vm.viewDemand(row.entity)">View</a>' +
														'<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#updateDemands" ng-click="grid.appScope.vm.updateDemand(row.entity)">Update</a>' +
														'<a href="javascript:void(0)" ng-click="grid.appScope.vm.deleteDemand(row.entity);$event.stopPropagation();">Delete</a>'},
													 ];

						angular.forEach($scope.gridOptions.data,function(row){
							  row.getFullName = function(){
							    return this.minPrice + '-' + this.maxPrice;
							  }
						});
						$timeout(function() {
							$(window).resize();
							$rootScope.dataLoading = false;
					    	$rootScope.dataStillLoading = false;
							}, 600);
					}
					$scope.updateForm={};
					vm.setFormOnDelete=function(){
						$scope.updateForm.$setPristine();
						$scope.updateForm.$setUntouched();
					}
					vm.viewDemand=function(demand){
						vm.modalDemand=demand;
						//sendDemandToViewToService(demand);
					}
					vm.updateDemand=function(demand){
						vm.demandUpdation=demand;
					}
					vm.updateParticularDemand=function(thisDemand){
						
						var updateDemand={
								category:demand.category,
								wishListId:demand.wishListId,
								updateInfo:demand.updateDemandDesc
						};
						callUpdateDemand(updateDemand).then(callUpdateDemandResponse);
					}
					function callUpdateDemand(request){
						
					}
					function callUpdateDemandResponse(response){
						
					}
					vm.deleteDemand=function(demand){
						var delDemand={
								category:demand.category,
								wishListId:demand.wishListId
						};
						callDeleteDemand(delDemand).then(callDeleteDemandResponse);
					}
					function callDeleteDemand(delDemand){
						return userWishlistService.deleteDemand(delDemand);
					}
					function callDeleteDemandResponse(response){
						var res=response.body;
						if(res.applicationStatusCode==1036){
							getBuyerDemands();
						}
					}
					function addActiveClass(oldVal,newVal){
						if(newVal == 'farminput'){
							newVal='listingDetails';
						}
						angular.element("#"+oldVal).removeClass('active-tab');
						angular.element("#"+newVal).addClass('active-tab');
					}
					function init(){
						//vm.templateUrl = 'assets/templates/admin/'+$stateParams.id+'.html';
						vm.templateContainer = $stateParams.id;
						addActiveClass(vm.currentTab,vm.templateContainer);
						vm.currentTab = vm.templateContainer;
						if(vm.templateContainer=='orderDetails'){
							getOrderDetails();
						}else if(vm.templateContainer=='activeUsers'){
							//get all active users
							activeUsers();
						}else if(vm.templateContainer=='deactiveUsers'){
							//get all inactive users
							inActiveUsers();
						}else if(vm.templateContainer=='readyToActivate'){
							activateAddress();
						}else if(vm.templateContainer=='allUsers'){
							showAllUsers();
						}else if(vm.templateContainer=='walletDetails'){
							getUsers();
						}else if(vm.templateContainer=='cancelledOrders'){
							
						}else if(vm.templateContainer=='buyerDemands'){
							getBuyerDemands();
						}else if(vm.templateContainer=='listingDetails'){
							
						}
						
					}
		} ]);

		});
