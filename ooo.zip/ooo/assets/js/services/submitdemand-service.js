/**
 * 
 */
/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("submitDemandService",['$q', 'ajaxService', 'urlService',function($q, ajaxService, urlService){
	 return {
		 getCategoryProducts:function(category_req){
			 var url = urlService.getCategoryBasedProducts();
			 return ajaxService.doGet(url,category_req);
		 },
		 sendSubmit:function(demand){
			 var url = urlService.sendSubmitDemand();
			 return ajaxService.doPost(url,{},demand);
			 
		 },
	      getFarmFilterListRequest:function(){
	      	  var url = urlService.getFilterListUrl();
	            return ajaxService.doGet(url,{});
	      },
	      getProductNamesReq:function(req){
	    	  var url = urlService.getProducts();
				 return ajaxService.doPost(url,{},req);
	      }
	    
		
	};
	}]);
    
	return services;
});