'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("loginCtrl", ['$rootScope','$scope','$state','utilityService','loginService','stateService','registrationUserService', "$sessionStorage",'productDetailService','$timeout','$document','setupAllSearchService','$q', function($rootScope,$scope,$state, utilityService,loginService,stateService,registrationUserService, $sessionStorage,productDetailService,$timeout,$document,setupAllSearchService,$q) {
	var vm = this;
    $scope.loading = true;
    vm.secureLoginHandler = secureLoginHandler;
    vm.forgetPasswordHandler = forgetPasswordHandler;
    vm.forgetUserNameHandler = forgetUserNameHandler;
    vm.registrationHandler = registrationHandler;
    vm.secureloginbtn = true;
    vm.userDeactivated = false;
    $timeout(function() {
    	$rootScope.showSessionTimeOutError = false;
    }, 5000);
    init();
    function init(){
    	changeCurrentSelector();
    }
    function changeCurrentSelector(){
    	if($rootScope.currentSelector==undefined){
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}else{
    		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}
    	$rootScope.currentSelector = $rootScope.toState.name;
    }
	function secureLoginHandler() {
		if(!utilityService.isEmptyObject(vm.secureUserName) || !utilityService.isEmptyObject(vm.secureUserPassword) ) {
    		vm.loginerror=true;
    		vm.userLocked=false;
    		vm.invalidUser=false;
    	} else {
    		vm.loginerror=false;
    		var secureUser = {
     				 userName:vm.secureUserName,
     				 password:vm.secureUserPassword
     		 	}
    		$rootScope.dataLoading = true;
    		callUserSecureLogin(secureUser).then(processUserSecureLoginResponse);
    	}
	}
	function forgetPasswordHandler() {
		$state.go('forgotPassword');
	}
	
 	function forgetUserNameHandler() {
 		 $state.go('forgotUserName');
	}
	function registrationHandler() {
 		$state.go('userRegistration');
	}
	function callUserSecureLogin(secureUser) {
		vm.waitingForPageToLoad = true;
        return loginService.secureUserLogin(secureUser);
	};
 	
	function setUserDetails(vm,data) {
 		angular.element('#loginuser').hide();
 		angular.element('#loginuserdevide').hide();
        angular.element('#signuser').hide();
        angular.element('#userLoggedIn').show();
        angular.element('#signeduser').text([constants.HELLO,data.fullName].join(" "));

        var prdLen= utilityService.isCheckEmptyArray(data.productsIDS)?data.productsIDS.length:0;
		angular.element('#cartcounterlist').text(prdLen);
		  
		/*//Session//
		stateService.set(constants.USER_CART_DETAILS_AFTER_LOGIN,data.productsIDS);
		stateService.set(constants.STATE_USER_STATUS,data.progress);
		stateService.set(constants.STATE_USER_STATUS_VALUE,data.status);
		stateService.set(constants.USER_SHIPPING_ADDRESS,data.shippingAddress);
		*/
 	}
	
	
	function processUserSecureLoginResponse(response) {
		var res = response.body;
		$rootScope.dataLoading = false;
		if(res.applicationStatusCode===1000){
			var data=res.data[0];
 	    	setUserDetails(vm,data);
			
 	    	$sessionStorage.$reset();
			//set local session
			$sessionStorage["userInfo"] = data;
					
			stateService.set(constants.LOGIN_DETAILS,data);

			if(data.status===constants.INACTIVE){
     			//registrationUserService.progress = data.progress; - Session	
     			vm.userLoginOrRegistration= false;
 				//stateService.set(constants.STATE_USER_NAME,vm.secureUserName); - Session
 				$state.go('userRegistration');
     		} else if (data.status===constants.ACTIVE){
     			//registrationUserService.userName=vm.secureUserName; - Session
     			//registrationUserService.authenticated=data.authenticated; - Session
     			//stateService.set(constants.STATE_USER_NAME,vm.secureUserName); - Session
     			//stateService.set(constants.USER_SHIPPING_ADDRESS,data.shippingAddress); - Session
     			
     			if(stateService.get(constants.STATE_USER_ACTION)===constants.HOME_ACTION){
     				$state.go('start');
     			} else if(stateService.get(constants.STATE_USER_ACTION)===constants.BUYNOW_ACTION){
     				$state.go('placeorder');
     			} else if(stateService.get(constants.STATE_USER_ACTION)===constants.ADDTO_CART || stateService.get(constants.STATE_USER_ACTION)===constants.HOME_CART_DETAILS){
     				$state.go('myCart');
     			} else if(stateService.get(constants.STATE_USER_ACTION)===constants.SUBMIT_DEMAND){
     				$state.go('submitDemand');
     			}else if(stateService.get(constants.STATE_USER_ACTION)===constants.FARM_INPUTS){
    				 $state.go('mylisting');
    			}else if(stateService.get(constants.STATE_USER_ACTION)===constants.ADDTO_WISHLIST){
    				var id_prod=productDetailService.getProductIdOnLogin();
    				productDetailService.navigateOnLoginToWIshlist(null);
     				$state.go('productdetails',{"id":id_prod});
     			}
     		 }
		} else if (+res.applicationStatusCode === 2039) {
     			for(var errCode=0, len = res.errorCodes.length; errCode<len; errCode++) {
 	    			if(res.errorCodes[i].errcode===2001) {
 	     				vm.userLocked=true;
 	     				vm.invalidUser=false;
 	     				vm.loginerror=false;
 	     				$('[data-toggle="tooltip"]').tooltip(); 
 	     			} else if(res.errorCodes[i].errcode===2002){
 	     				vm.loginerror=true;
 	     			}
     			 }
     		 } else if (+res.applicationStatusCode === 2000) {
     			 for(var i=0,len=res.errorCodes.length;i<len;i++) {
     				  if(res.errorCodes[i].errcode===2001){
 	     				 vm.userLocked=true;
 	     				 vm.invalidUser=false;
 	     				 $('[data-toggle="tooltip"]').tooltip(); 
     				  } else if(res.errorCodes[i].errcode===2002||res.errorCodes[i].errcode===2039) {
 	     				 vm.loginerror=false;
 	     				 vm.invalidUser=true;
 	     				 vm.userLocked=false;
     				  } else if(res.errorCodes[i].errcode===2000) {
 	     				 vm.loginerror=false;
 	     				 vm.invalidUser=false;
 	     				 vm.userLocked=true; //vm.logininvalid
     				  } else if(res.errorCodes[i].errcode===2093){
     					 vm.userDeactivated = true;
     					 vm.loginerror=false;
	     				 vm.invalidUser=false;
	     				 vm.userLocked=false;
     				  }
     			 }
     		 }
     	}
	
}]);
});
