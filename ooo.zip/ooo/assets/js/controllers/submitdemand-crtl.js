/**
 *

 */
'use strict';


define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("submitDemandCtrl", ['$rootScope','$scope','$window','$state','submitDemandService','registrationUserService','utilityService','loginService','stateService','userWishlistService', 
                                         function($rootScope,$scope,$window,$state,submitDemandService,registrationUserService,utilityService,loginService,stateService,userWishlistService) {
	
	var vm=this;
	vm.submit_success=false;
	vm.btnHide=false;
	vm.category={};
	vm.isOthers=false;
	vm.onlyFarmInputs=false;
	vm.successSD=false;
	vm.subCategories=[];
	vm.products=[],vm.product_skus=[],vm.grades=[],vm.varieties=[];
	vm.sdStatus,vm.startsWithZero=false;
	vm.updatingDemand=false;
	var demand=[];
	var wishId;
	vm.maxLess=false;
	var updation=false;
	vm.pinStartsWithZero=false;
	vm.res_products=null;
	init();
	vm.sdPinCheck=function(){
		vm.pinStartsWithZero=vm.demandPin.length>0&&vm.demandPin.charAt(0)=='0';	
	}
	/*
	$scope.subcats=obj.subcategories;
	$scope.prods=obj.Products;
	$scope.skuList=$scope.prods[0].skus;*/
	 vm.onParentCategoryChange=onParentCategoryChange;
     vm.onSubCategoryLevel1Change=onSubCategoryLevel1Change;
     vm.onSubCategoryLevel2Change=onSubCategoryLevel2Change;
     vm.onSubCategoryLevel3Change=onSubCategoryLevel3Change;
	 function onParentCategoryChange(){
		 vm.category.type =vm.levelOne;
		 vm.categoryListLevel1=vm.categoryListLevel2=vm.categoryListLevel3=[];
		 var category= getSubCategoryByName(vm.levelOne,vm.categoryList);
		 vm.categoryListLevel1=category!=null?category.subCategory:[];
		 vm.categoryListLevel1Show=vm.categoryListLevel1.length>0?true:false;
		 vm.categoryListLevel2Show=vm.categoryListLevel3Show=false;
		 if(updation){
		  		vm.levelTwo = vm.demand.levelTwo;
		  		onSubCategoryLevel1Change();
		  }
		 if(vm.levelOne=="Others"){
				vm.isOthers=true;
			}else{
				vm.isOthers=false;
			}
		 
	 }
	function onSubCategoryLevel1Change(){
		vm.fromAnother1=true;
		var category= getSubCategoryByName(vm.levelTwo,vm.categoryListLevel1);
		vm.categoryListLevel2=category!=null?category.subCategory:[];
		vm.categoryListLevel2Show=vm.categoryListLevel2.length>0?true:false;
		if(updation){
	  		vm.levelThree = vm.demand.levelThree;
	  		onSubCategoryLevel2Change();
	  		}
		if(!(vm.categoryListLevel2.length>0)){
			getProductNameBasedOnSubCats(vm.levelOne,vm.levelTwo,"","");
		}
		vm.categoryListLevel3Show=false;
		vm.categoryListLevel3=[];
		
		 }
	function onSubCategoryLevel2Change(){
		vm.fromAnother2=true;
		var category=getSubCategoryByName(vm.levelThree,vm.categoryListLevel2);
		vm.categoryListLevel3=category!=null?category.subCategory:[];
		vm.categoryListLevel3Show=vm.categoryListLevel3.length>0?true:false;
		if(updation){
	  		vm.levelFour = vm.demand.levelFour;
	  		onSubCategoryLevel3Change(vm.levelFour);
		}
		if(!(vm.categoryListLevel3.length>0)){
			getProductNameBasedOnSubCats(vm.levelOne,vm.levelTwo,vm.levelThree,"");
		}
	}
	function onSubCategoryLevel3Change(){
		vm.fromAnother3=true;
		var category=getSubCategoryByName(vm.levelThree,vm.categoryListLevel3);
		vm.categoryListLevel4=category!=null?category.subCategory:[];
		vm.categoryListLevel4Show=vm.categoryListLevel4.length>0?true:false;
		if(updation){
	  		vm.levelFive = vm.demand.levelFive;
	  		//onSubCategoryLevel3Change(vm.levelFive);
		}
		if(!(vm.categoryListLevel4.length>0)){
			getProductNameBasedOnSubCats(vm.levelOne,vm.levelTwo,vm.levelThree,vm.levelFour);	
		}
		
	}
	function getProductNameBasedOnSubCats(lev1,lev2,lev3,lev4){
		var request= angular.extend({},{
			category:"Farm Input",		
			categoryLevelDTOs:[{level1:lev1,level2:lev2,level3:lev3,level4:lev4,level5:""}],
			priceRange:[],
			grades:[],
			brands:[],
			searchText:"",
			start:0,
			rows:100,
			sortField:""
			
		});
		getProductsRequest(request).then(getProductsResponse); 
	}
	
	function getSubCategoryByName(name,categoryList){
		 for(var list=0,listLen=categoryList.length;list<listLen;list++){
			 if(categoryList[list].categoryName===name){
				 return categoryList[list];
			 }
		 }
	}
	function getProductsRequest(request){
		return submitDemandService.getProductNamesReq(request);
	}
	function getProductsResponse(response){
		vm.res_products=response;
		
		console.log(vm.res_products);
		
		if(updation){
			vm.categoryProductName=vm.demand.productName;
			vm.demandGrade=vm.demand.grade;
			vm.demandSku=vm.demand.sku;
		}
	}
	vm.checkMax=function(){
		if(parseInt(vm.demandMaxPrice)<=parseInt(vm.demandMinPrice)){
			vm.maxLess=true;
		}else{
			vm.maxLess=false;
		}
	
	}
	
    function init(){
    	//getting in update submit demand, the demand shared
    	
    	//getting states and districts-call for it
    	 getFarmFilterRequest().then(getFarmFilterResponse);
    	callAddressDetails().then(processAddressStateDataResponse);	
    
    	//since by default Farm Inputs check btn is checked, also call to get subcategories related to it
    	
    	demand=userWishlistService.retrieveDemandInSD();
    	updation=userWishlistService.retrieveUpdationstatus();
    	userWishlistService.sendDemandToSD(null,false);
    	if(updation){
    		vm.demand = demand;	
			vm.category=demand.category;
    		vm.categoryProduct=demand.subCategory,
        	vm.categoryProductName=demand.productName;
        	vm.demandDesc=demand.demandDescription;
        	vm.demandGrade=demand.grade;
    		vm.demandVariety=demand.variety;
    		vm.demandQuantity=demand.quantity;
    		vm.demandSku=demand.sku;
    		vm.expDate=demand.demandDate;
    		vm.demandMinPrice=demand.minPrice;
    		vm.demandMaxPrice=demand.maxPrice;
    		vm.demandState=demand.stateId.toString();
    		vm.demandDistrict=demand.district.toString();
    		vm.demandLocation=demand.location;
    		wishId=demand.wishListId;
    		vm.levelOneProxy=demand.levelOne;
    		vm.levelTwoProxy=demand.levelTwo;
    		vm.levelThreeProxy=demand.levelThree;
    		vm.levelFourProxy=demand.levelFour;
    		var category={
        			category:demand.category,
        			demand:true
        	};
        	getCategoryBasedProductsRequest(category).then(getCategoryBasedProductsResponse); 
    	}    	
    	changeCurrentSelector();
    }
    function changeCurrentSelector(){
    	if($rootScope.currentSelector==undefined){
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}else{
    		angular.element("#"+$rootScope.currentSelector).removeClass('currentSelected');
    		angular.element("#"+$rootScope.toState.name).addClass('currentSelected');
    	}
    	$rootScope.currentSelector = $rootScope.toState.name;
    }
    function getFarmFilterRequest(){
  		return submitDemandService.getFarmFilterListRequest();
  	}
  	function getFarmFilterResponse(response){
  		var _resBody = response.body.data[0];
		var arrayList = {};
	   _resBody.categoryList.map(function(element){
		   return arrayList[element['categoryName']] = element.subCategory;
		});
  		//vm.categoryList=response.body.data[0].categoryList[2].subCategory;
	   vm.categoryList=arrayList["Farm Input"];
  		if(updation){
  		vm.levelOne = vm.demand.subCategory;
  		onParentCategoryChange();
  		}
  	}
    function callAddressDetails(){
    	return registrationUserService.getAddressDetails();
    }
	function processAddressStateDataResponse(response){
		//list of states
    	vm.statesList = response.body.data;
    	if(updation){
    		vm.demandState=vm.demand.stateId.toString();
    	}
    }
	
	vm.subCategoryChanged=function(categoryProduct){
		if(vm.levelOne=="Others"){
			vm.isOthers=true;
		}else{
			vm.isOthers=false;
		}
	}
	vm.checkStartsWithZero=function(){
		if(vm.demandQuantity.length>0){			
		if(vm.demandQuantity.charAt(0)=="0"){
			vm.startsWithZero=true;
		}
		else{
			vm.startsWithZero=false;
		}
		}
	}
	vm.onCategoryChange=function(category_selected){
	//sending category get response and set them to dropdowns
	if(category_selected=="FarmInputs"){
		vm.onlyFarmInputs=true;
	}
	else{
		vm.onlyFarmInputs=false;
	}
	var category={
			category:vm.categoryname
	};
	getCategoryBasedProductsRequest(category).then(getCategoryBasedProductsResponse);
	};
	function getCategoryBasedProductsRequest(category_req){
		return submitDemandService.getCategoryProducts(category_req);
	}
	function getCategoryBasedProductsResponse(response){
		//response 
		var res = response.body;
    	if(res.applicationStatusCode==1033){
    		var responseList=res.data;
    		vm.subCategories=responseList[0].subcategories;
    		vm.products=responseList[0].products;
    		vm.skus=responseList[0].skus;
    		vm.grades=responseList[0].grades;
    		vm.varieties=responseList[0].varieties;
    	}
	}	
	vm.submitDemand=function(){
		var login_name=loginService.getUserInfo().userName;//stateService.get(constants.STATE_USER_NAME);
		var pname, pid;
		if(vm.isOthers){
			pname=$("#sdProdName").val();		
			pid=null;
			skuDemand=vm.demandSku;
			sizeDemand=vm.demandSize;
		}else{
			var pname1=$("#sdProdName option:selected").html();
			var arrSkuSize=pname1.split('(');
			pname=arrSkuSize[0].slice(0,-1);
			var skuDemand, sizeDemand;
			if(arrSkuSize[1].length>0){
				var skuSize=arrSkuSize[1].split(' ');
				skuDemand=skuSize[1].slice(0,-1);
				sizeDemand=skuSize[0];
			}
			pid=vm.categoryProductName
		}
		if(updation==true){
			var demand= angular.extend({},{
				loginname:login_name,
				wishListId:wishId,
				category:vm.categoryname,
				subCategory:vm.levelOne,
				productId:pid,
				productName:pname,
				unitSize:sizeDemand,
				demandDescription:vm.demandDesc,
				grade:vm.demandGrade,
				variety:vm.demandVariety,
				quantity:vm.demandQuantity,
				sku:skuDemand,
				demandDate:vm.expDate,
				minPrice:vm.demandMinPrice,
				maxPrice:vm.demandMaxPrice,
				state:vm.demandState,
				district:vm.demandDistrict,
				location:vm.demandLocation,
				pincode:vm.demandPin,
				//subCategory:vm.levelOne,
	    		//levelTwo:vm.levelTwo,
	    		//levelThree:vm.levelThree,
	    		//levelFour:vm.levelFour,
				demand:true	
	       	});
		}
		else{
			
			var demand= angular.extend({},{
				loginname:login_name,
				category:vm.categoryname,
				subCategory:vm.levelOne,
				productId:pid,
				productName:pname,
				unitSize:sizeDemand,
				demandDescription:vm.demandDesc,
				grade:vm.demandGrade,
				variety:vm.demandVariety,
				quantity:vm.demandQuantity,
				sku:skuDemand,
				demandDate:vm.expDate,
				minPrice:vm.demandMinPrice,
				maxPrice:vm.demandMaxPrice,
				state:vm.demandState,
				district:vm.demandDistrict,
				location:vm.demandLocation,
				subCategoryOthers:vm.levelTwo,
				pincode:vm.demandPin,
				levelOne:vm.levelOne,
	    		levelTwo:vm.levelTwo,
	    		levelThree:vm.levelThree,
	    		levelFour:vm.levelFour,
				demand:true
	       	});
		}
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		sendSubmitDemand(demand).then(sentSubmitDemandResponse);
		userWishlistService.sendDemandToSD(null,false);
	}
	
	function sendSubmitDemand(demand){
		return submitDemandService.sendSubmit(demand);
	}
	function sentSubmitDemandResponse(response){
		
		var res = response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		//2065
			if(res.applicationStatusCode==1037){
				vm.sdStatus=true;
				vm.successSD=true;
				vm.submit_success=true;
				vm.sdMsd="Demand Successfully Updated";
				angular.element('#submitSD').text("Demand Updated");				
			}
			else{
				vm.sdStatus=false;
				vm.submit_success=false;
			}
			
			if(res.applicationStatusCode==1029){
				vm.sdStatus=true;
				vm.successSD=true;
				vm.submit_success=true;
				//angular.element('#submitSD').text("Demand Submitted");
				//vm.sdMsd="Demand Submitted Successfully";
				$state.go("demands");
			}
			else{
				vm.sdStatus=false;
				vm.submit_success=false;
			}		
	}
	function updateDemand(){
		var demand=userWishlistService.retrieveDemandInSD();
		vm.updatingDemand=true;	
	}
	vm.newDemand=function(){
		//$window.location.reload();	
		//hide subcategory fields and set form pristine
		vm.submitted = false;
		vm.submit_success=false;
		vm.levelOne="",
		vm.levelTwo="",
		vm.levelThree="",
		vm.levelFour="",
		vm.levelFive="",
		vm.categoryProductName="",
		vm.demandDesc="",
		vm.demandGrade="",
		vm.demandVariety="",
		vm.demandQuantity="",
		vm.demandSku="",	
		vm.demandSize="",
		vm.expDate="",
		vm.demandMinPrice="",
		vm.demandMaxPrice="",
		vm.demandState="",
		vm.demandDistrict="",
		vm.demandLocation="",
		vm.fromAnother1=false;
		vm.fromAnother2=false;
		vm.fromAnother3=false;
		vm.demandPin="",
		$scope.sdForm.$setPristine();
	   	$scope.sdForm.$setUntouched();	
	};
	vm.goToDemands=function(){
		$state.go('demands');
	}	
}]);//controller

});