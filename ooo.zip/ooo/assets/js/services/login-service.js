/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("loginService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService', '$sessionStorage' ,function($q, ajaxService, stateService, utilityService,urlService, $sessionStorage){
		return	{
			secureUserLogin : function(secureUser) {
		      	  var url = urlService.secureUserLoginUrl();
		            return ajaxService.doPost(url, {},secureUser);
		    },
		    // Logout to kill the session
			logout: function() {
				if(typeof $sessionStorage["userInfo"] != "undefined") {
					$sessionStorage.$reset(); // Remove localstorage data
				}
			},
		    // get userinfo from session storage
			getUserInfo: function() {
				return typeof $sessionStorage["userInfo"] != "undefined" ? $sessionStorage["userInfo"] : false;
			}
		};
	}]);
    
	return services;
});