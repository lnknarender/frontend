'use strict';
 
App.controller('TestController', ['$scope', 'TestService', function($scope, TestService) {
	//App.controller('TestController', ['TestService', function($scope, TestService) {

          var self = this;

          self.testAnguJs = function(){
        	 //alert("calling TestService.testAngJs function");
        	 $scope.name1 =TestService.testAngJs();
        	alert("Rest obj from server: "+ $scope.name1);
          };
 
         self.submit = function() {
        	 //alert("Submitting page");
              self.testAnguJs();
          };
      }]);