'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("myCartCtrl", ['$rootScope','$scope','$state','utilityService','setupAllSearchService','myCartService','stateService','$timeout','loginService', '$sessionStorage', function($rootScope,$scope,$state, utilityService,setupAllSearchService,myCartService,stateService,$timeout,loginService,$sessionStorage) {
	
        var vm = this;
		vm.opacity=1;
       	vm.inStock=false;
       	vm.onQtyKeyPress= onQtyKeyPress;
        vm.userInfo = loginService.getUserInfo();
        
        if(!vm.userInfo) {
        	$state.go('start');
        }
        
        //$scope.loading=true;
        //$rootScope.dataLoading = true;
        vm.productsDisplay = true;
        vm.qtyDetails = [1,2,3,4,5,6,7,8,9,10];
        vm.addProductDetailsToCart=addProductDetailsToCart;
        vm.removeFromCart=removeFromCart;
        vm.updateQuantity=updateQuantity;
        vm.getCart=getCart;
        vm.gotoproductdetails = gotoproductdetails;
        vm.placeorderhandler =placeorderhandler;
        vm.errorResProductDetails = false;
        vm.prd_farminput_type = constants.PRD_ROOT_TYPE_FARMINPUT;
        vm.onQtyFocus = onQtyFocus;
        vm.homePageHandler = function(){
      	   $state.go('start');
         };
        init();
        
        function onQtyKeyPress(event){
			  var key = event.keyCode;
			  if(key < 48 || key > 57)
				  {
				  	event.preventDefault();
				  }
			  return false;
		}
        
        function onQtyFocus(id)
        {
        	angular.element("#qtySave_"+id).css( "display", "block" );
        	vm.isQtyGreater=false;
        	vm.isMaxQty=false;
        }
        
        function checkMaxAndValidQty(productDetail)
        {
        	var isTrue = false;
        	vm.isQtyGreater=false;
        	vm.isMaxQty=false;
        	var id = productDetail.product.productId;
        	vm.qtyPrdId=id;
        	var qtyValue = angular.element("#qty_"+id).val();
        	var isValid = checkQtyEntry(productDetail);
        	if(isValid){
    		
		  		if(qtyValue!=''&&qtyValue>0 && (qtyValue)>productDetail.quantityAvailable){
		  			vm.isQtyGreater=true;
		  			updateQtyEntry(productDetail);
		  		}
		  		else if(productDetail.product.prdType ===  vm.prd_farminput_type && qtyValue> productDetail.product.maxPurchasableQty)
		  		{
		  			vm.isMaxQty=true;
		  			updateQtyEntry(productDetail);
		  		}
		  		else{
		  			isTrue = true;
		  		}
		  		angular.element("#qtySave_"+id).css('display','none');
		  		//angular.element("#qty_"+id).val(qtyValue);
        	}
    		return isTrue;
		 }

        function checkQtyEntry(productDetail)
        {
        	var id = productDetail.product.productId;
        	var isValid = false;
        	var qtyValue = angular.element("#qty_"+id).val();
        	if(qtyValue==''||qtyValue==null||qtyValue==undefined ||!$.isNumeric(qtyValue)||qtyValue<=0){
        		updateQtyEntry(productDetail);
           	}
        	else{
        		isValid=true;
        	}
        	return isValid;
        }
        
        function updateQtyEntry(productDetail)
        {
        	var id = productDetail.product.productId;
        	var qty = Math.floor(productDetail.subTotal-productDetail.shippingCharges)/productDetail.discountedPrice;
			angular.element("#qty_"+id).text(qty);
			angular.element("#qty_"+id).val(qty);
			angular.element("#qtySave_"+id).css( "display", "none" );
			productDetail.quantity=qty;
        }
        
        function gotoproductdetails(productDetail){
        	
        	stateService.set(constants.STATE_USER_PRODCUT_DETAILS,"cart");
        	$sessionStorage["cartProduct.productId"] = productDetail.product.productId;
        	$sessionStorage["cartProduct.quantity"] = productDetail.quantity;
        	$sessionStorage["cartProduct.pinCode"] = productDetail.store.pincode; //TODO Ratna
        	//setupAllSearchService.productId=productDetail.product.productId;
        	//setupAllSearchService.quantity=productDetail.quantity;
        	//setupAllSearchService.pinCode=productDetail.store.pincode;//TODO Ratna
        	$sessionStorage["fromWhere"] = "mycart";
        	stateService.set(constants.PRODUCT_DISABLE_ADD_CARD,"mycart");
        	//setupAllSearchService.cartPincode =productDetail.store.pincode;
        	$state.go('productdetails',{"id":productDetail.product.productId});
        }
        function init(){
      //  if(stateService.get(constants.STATE_USER_ACTION)===constants.HOME_CART_DETAILS){
        	vm.getCart();
        	vm.isNotFarmer= vm.userInfo.farmer=="N"||vm.userInfo.farmer==="n";
			vm.placeorderbtn=!(utilityService.isEmptyObject(vm.userInfo.progress) && utilityService.isEmptyObject(vm.userInfo.status) && vm.userInfo.progress===constants.MANUAL_VERIFICATION && vm.userInfo.status===constants.ACTIVE);

       /* }else if(stateService.get(constants.STATE_USER_ACTION)===constants.ADDTO_CART){
        	vm.productDetails=setupAllSearchService.addToCartRequest;
      		 angular.extend(setupAllSearchService.addToCartRequest,{
      			 loginName:stateService.get(constants.STATE_USER_NAME)
      			 });
      		 callProductDetailsToCart(vm.productDetails).then(processAddCartDetailsResponse);
        }*/
        }
        function getTotal(){
          	  vm.total = 0;
              for(var i = 0; i < vm.cartDetails.length; i++){
            	  if(vm.cartDetails[i].inStock){
            		  vm.total = vm.total +(+vm.cartDetails[i].subTotal);
            	  }
              }
              vm.total=+(vm.total).toFixed(2);
              return vm.total;
          };
  
         function setProductDetails(cartDetails){
        	 for(var i = 0; i < vm.cartDetails.length; i++){
        		 if(cartDetails.product.productId===vm.cartDetails[i].product.productId){
        			 vm.cartDetails[i].shippingCharges=cartDetails.shippingCharges.toFixed(2);
        			 vm.cartDetails[i].subTotal=cartDetails.subTotal.toFixed(2);
        			 vm.cartDetails[i].discountedPrice=cartDetails.discountedPrice.toFixed(2);
        			 vm.cartDetails[i].inStock = true;
        		 }
                }
        	 
         }
       
        
        function placeorderhandler(){
        	//myCartService.cartDetails =vm.cartDetails;
        	var myCart = [];
        	//myCartService.isShipping=false;
        	//myCartService.isIPickup=false;
        	$sessionStorage["isShipping"] = false;
        	$sessionStorage["isIPickup"] = false;
        	for(var count=0; count<vm.cartDetails.length; count++)
        	{
        		vm.cartDetails[count].quantity = Math.floor((vm.cartDetails[count].subTotal-vm.cartDetails[count].shippingCharges)/vm.cartDetails[count].discountedPrice);
        		if(vm.cartDetails[count].inStock){
        			
        			myCart.push(vm.cartDetails[count]);
        		}
        			
        	}
        	vm.cartDetails.filter(function(item){ 
        		                              if(item.deliveryMode==="SHIPPING"){
        		                            	  $sessionStorage["isShipping"]=true;
        		                                }else{
        		                                	$sessionStorage["isIPickup"]=true;
        		                                	$sessionStorage["storeSelected"] = item.store;
        		                                }
        		                              return item.inStock});
        	//myCartService.cartDetails = vm.cartDetails;
        	//myCartService.isBoth=myCartService.isShipping && myCartService.isIPickup;
        	//stateService.set(constants.STATE_USER_ACTION,constants.PLACE_ORDER);
        	//myCartService.orderAmount =getTotal();
        	//$sessionStorage["cartDetails"] = vm.cartDetails; - commented for check
        	$sessionStorage["cartDetails"] = myCart;
        	$sessionStorage["isBoth"] = $sessionStorage["isShipping"] && $sessionStorage["isIPickup"];
        	$sessionStorage[constants.STATE_USER_ACTION] = constants.PLACE_ORDER;
        	$sessionStorage["orderAmount"] =getTotal();
        	$state.go('placeorder');
        }
      
        function removeFromCartCounter(){
        	var prdLen = vm.userInfo.productsIDS, _countE=angular.element('#cartcounterlist'),val=0; //stateService.get(constants.USER_CART_DETAILS_AFTER_LOGIN);
			   if(utilityService.isCheckEmptyArray(prdLen) && prdLen.length>0){
				   var index= vm.userInfo.productsIDS.indexOf(vm.product.productId);
				   vm.userInfo.productsIDS.splice(index,1);
				   //stateService.set(constants.USER_CART_DETAILS_AFTER_LOGIN,stateService.get(constants.USER_CART_DETAILS_AFTER_LOGIN));
				   /*if(vm.userInfo.productsIDS.length===0){
					   angular.element('#cartcounterlist').text(0);
				   }else{
					   angular.element('#cartcounterlist').text(vm.userInfo.productsIDS.length);
				   }*/
				 
				   val = prdLen.length;
				  if(val===0)
					  {
					  	vm.userInfo.pincode = null;
					  }
			   }
			   _countE.text(val);
        }
    	
        function removeFromCart(product,index){
        	vm.product=product;
        	vm.index= index;
        	var request= angular.extend({},{
        		loginName: vm.userInfo.userName,//stateService.get(constants.STATE_USER_NAME),
        		pid:product.productId
        	});
        	$rootScope.dataLoading = true;
        	callRemoveFromCart(request).then(processRemoveFromCartResponse);
        }
        function callRemoveFromCart(request){
        	return myCartService.removeFromCart(request);
        }
        function processRemoveFromCartResponse(response){
        	var body= response.body;
        	$rootScope.dataLoading = false;
			 if(body.applicationStatusCode===1015){
				     var product=vm.product;
				//     angular.element('#cartcounterlist strong').text(vm.cartDetails.length-1);
				     vm.cartDetails.splice(vm.index,1);
				     placeOrderBtn(vm.cartDetails);
				     getTotal();
				     removeFromCartCounter();
		            if(vm.cartDetails.length==0){
		            	//$state.go('noproductfound');
		            	vm.productsDisplay = false;
		            }
			 }else{
				 console.log("Remove from cart failed");
				 vm.errorResProductDetails = true;
			 }
        }
		function updateQuantity(productDetail, _event){
			/*if(+productDetail.quantity<=0){
				vm.quantityNegative=true;
				
				return false;
			}else{
				vm.quantityNegative=false;
			}*/
			vm.productDetail=productDetail;
			vm.product=productDetail.product;
			vm['vm.validQtyLoading'+vm.product.productId]=true;
			vm.uqProduct=vm.product;
			vm._currentElement = _event.currentTarget;
			
			vm.updatedQuantity=productDetail.quantity;
			var isTrue = checkMaxAndValidQty(productDetail);
			if(isTrue)
			{
        	var request= angular.extend({},{
        		loginName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
        		product:{
        			productId:vm.product.productId,
        			productQuantity:+productDetail.quantity
        		}
        		
        	});
        	angular.element("#qtySave_"+vm.product.productId).css( "display", "none" );
        	angular.element("#qtywait_"+vm.product.productId).css( "display", "block" );
        	angular.element("#qtycheck_"+vm.product.productId).css( "display", "none" );
        	$rootScope.dataLoading = true;
			callUpdateQuantityForCart(request).then(processUpdateQuantityResponse);	
			}
		}
		function callUpdateQuantityForCart(request){
			
			return myCartService.updateQuantity(request);
		}
		function processUpdateQuantityResponse(response){
			var body= response.body,product=vm.product;
			$rootScope.dataLoading = false;
			 if(body.applicationStatusCode===1016){
				    setProductDetails(body.data[0]);
				    var updatedQty = vm.updatedQuantity,
				 	subTotalUpdated = updatedQty * product.unitPrice;
		        	vm.noEnoughtQuantity=false;
		        	 getTotal();
		        	 angular.element("#qtySave_"+product.productId).css( "display", "none" );
		        	 angular.element("#qtywait_"+product.productId).css( "display", "none" );
		        	 
			 }else if(body.applicationStatusCode===2027){
				 var product=vm.product;
				 angular.element("#qtywait_"+product.productId).css( "display", "none" );
				 angular.element("#qtySave_"+product.productId).css( "display", "block" );
	        	 angular.element("#qtycheck_"+product.productId).css( "display", "block" );
	        	 
	        	 for(var i = 0; i < vm.cartDetails.length; i++){
						if(vm.cartDetails[i].product.productId== product.productId)
							{
								vm.cartDetails[i].quantityAvailable =  body.data[0]['Quantity Available'];
								vm.cartDetails[i].inStock = false;
								angular.element("#qtySave_"+product.productId).css( "display", "none" );
								break;
							}
		         }
	        	 
	        /*	 var _errElement = document.createElement("span");
	        	 //_errElementChild = document.createElement("td");
	        	 //_errElement.setAttribute("id", "qtycheck_"+product.productId);
	        	 _errElement.setAttribute("class", "origo-table-inline-error");
	        	 //_errElementChild.setAttribute("colspan","2");
	        	 //_errElementChild.innerHTML = "Quantity is not available with selected store. Available Quantity : ";
	        	 //_errElementChild.innerHTML = _errElementChild.innerHTML + body.data[0]['Quantity Available']; 
	        	 _errElement.innerHTML = "Quantity is not available with selected store. Available Quantity : ";
	        	 _errElement.innerHTML = _errElement.innerHTML + body.data[0]['Quantity Available']; 
	        	 
	        	 //$(_errElement).append(_errElementChild);
	        	 //$(vm._currentElement).parents("#innerTable_"+product.productId).after(_errElement);
	        	 $("#qtycheck_"+product.productId).after(_errElement);*/
	        	 
	        	 /*$timeout(function() {
	        		 $(vm._currentElement).parents("tbody").find(_errElement).remove(".origo-table-inline-error");
	        	 }, 5000);*/
	        	 
				 vm.noEnoughtQuantity=true;
			 }
		  placeOrderBtn(vm.cartDetails);
		}
		function placeOrderBtn(cartDetails){
			var isDisable=false,len=0;
			for(var i = 0; i < cartDetails.length; i++){
			   if(!cartDetails[i].inStock){
				   isDisable = true;
				   len++;
			   }
			  
		     }
			if(cartDetails.length===len){
				vm.placeorderbtn = isDisable;
			}
			
		}
		function getCart(){
			vm.mycartdetailresponse=false;
			var request= angular.extend({},{
        		loginName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
        	});
			$rootScope.dataLoading = true;
			$rootScope.dataStillLoading = true;
			callGetCart(request).then(processGetCartDetailsResponse);
		}
		function callGetCart(request){
			return myCartService.getCart(request);
		}
		function processGetCartDetailsResponse(response){
			var body= response.body;
			$rootScope.dataLoading = false;
			$rootScope.dataStillLoading = false;
			if(body.applicationStatusCode===1020){
				  //$scope.loading=false;
				var data= body.data;
				if(data===null){
					//$state.go('noproductfound');
					vm.productsDisplay = false;
				}else{
					vm.cartDetails=data;
					 for(var i = 0; i < vm.cartDetails.length; i++){
							vm.opacity=1;
			                vm['qupdate'+vm.cartDetails[i].product.productId] =vm.cartDetails[i].quantity;
							vm.prodId = vm.cartDetails[i].product.productId;
							vm.cartDetails[i].product.productImgPath=connection.store+"images/"+vm.cartDetails[i].product.productImgPath;
							vm.maxQuantityPurchase =  vm.cartDetails[i].product.maxPurchasableQty;
			         }
					 placeOrderBtn(vm.cartDetails)
		            
					getTotal();
					vm.productsDisplay=true;
					vm.mycartdetaillist=true;
					vm.productsErrorDisplay=false;
					angular.element('#cartcounterlist').text(vm.cartDetails.length);
				}
				
			}else {
				console.log("Get Cart failed");
				vm.errorResProductDetails = true;
			}
		}
        function addProductDetailsToCart(productDetails) {
            vm.waitingForPageToLoad = true;

            return myCartService.addproductDetailsToCart(productDetails);
        };
      
      
      //showCart() in header.html
      function showCart(){
      	//should give login details
    	  stateService.set(constants.STATE_USER_ACTION,constants.ADDTO_CART);
    		 var userName= vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
     	if(userName===null||userName===undefined ||userName===""){		
     			$state.go('login');
     		
     	}
     	else{
     		var request= angular.extend({},{
       		   loginName:userName
       	
       	});
     		callViewAllInCart(request).then(viewAllInCartResponse);
     	} 
      
      }
      function callViewAllInCart(request){
      	//return pinCodeAvailService.callCheckPinCodeAvail(request);
      }
      
      function viewAllInCartResponse(response){
      	//set vm.notAvailable_pin=true if the output contains 
      	//store_name, distance and timings
      	
      	//check with status code of pin availability
      	if(response.body.statusCode==1000){
      		vm.cart_productss=response.body.data;
      		
      	}
      }
      
}]);
});