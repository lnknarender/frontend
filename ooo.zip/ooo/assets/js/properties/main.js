
/*
 * load angular app.directives files - angular.module("app.directives");
 */
define([
"./connections",
"./constants",
"./locale-eng",
"./locale-hin",
"./locale-tel"
], function() {
             
});