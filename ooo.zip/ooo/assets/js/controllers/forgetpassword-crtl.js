'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("ForgetPasswordCtrl", ['$rootScope','$state', 'utilityService','forgetPasswordService', function($rootScope,$state, utilityService,forgetPasswordService) {
	


        var vm = this;
        vm.forgetPassword= forgetPassword;
        vm.OTPSubmit=OTPSubmit;
        vm.changePassword=changePassword;
        vm.forgetpasswordPanel=true;
        vm.forgetpasswordOTPNumber=false;
        vm.retypeforgetpassword=false;
        vm.generateOTP=generateOTP;
        vm.reTypePassword=reTypePassword;
        vm.isGenerateOTPNumber= true;
        vm.enterLoginName= false;
        vm.otpEnteredHandler=otpEnteredHandler;
		vm.reloginAgain=reloginAgain;
		vm.enteredOtpNumber = enteredOtpNumber;
		vm.enteredNewPassword = enteredNewPassword;
		function enteredOtpNumber(){
			vm.generateOtpEnterInvalid= false;
			vm.emailsentunsuccefully = false
			vm.generatedOtp = false;
			angular.element('#generateOTPmsg').hide();
		}
		function enteredNewPassword(){
			angular.element('#otpvalidated').hide();
			vm.reTypePasswordFailed = false;
		}
        function otpEnteredHandler(){
        	if(utilityService.isCheckEmpty(vm.OTPNumberTyped)){
        		vm.isGenerateOTPNumber= true;
        	}else{
        		vm.isGenerateOTPNumber= false;
        	}
        	
        }
        function generateOTP(){
        	
        	angular.element('#otp').val("");
        	angular.element('#generate-otp').text('Resend OTP');
        	 var request=angular.extend({},{
			 loginName:vm.loginName
		 });
        	 $rootScope.dataLoading = true;
		callGenerateOtp(request).then(processGenerateOtpResponse);
        }
        
        function callGenerateOtp(request){
			return forgetPasswordService.generateOTPUrl(request);
		}
		function forgetPassword(){
			if(utilityService.isCheckEmpty(vm.loginName)){
				vm.enterLoginName= true;
				vm.notexistingusererror=false;
				
			}else{
				vm.enterLoginName=false;
				var request = angular.extend({},{
					userName:vm.loginName
				});
				$rootScope.dataLoading = true;
				callForgetPassword(request).then(processForgetPasswordResponse);
			}
        	
        	
        }
		function callForgetPassword(loginName){
			return forgetPasswordService.callForgetPassword(loginName);
		}
		
		function processGenerateOtpResponse(response){
				var res = response.body;
				$rootScope.dataLoading = false;
				vm.generateOtpEnterInvalid= false;
				if (res.applicationStatusCode === 1018) {
					vm.forgetpasswordPanel = false;
					vm.forgetpasswordOTPNumber = true;
					vm.generatedOtp = true;
					vm.notexistingusererror = false;
					vm.isGenerateOTPNumber = true;
					vm.enterLoginName = false;
					vm.generateOtpEnter = true;
					vm.generateOtpEnterInvalid=false;
					angular.element('#generate-otp').text('Resend OTP');
					angular.element('#generateOTPmsg').hide();
				} else if (res.applicationStatusCode === 2032) {
					vm.generatedOtp = false;
					angular.element('#generateOTPmsg').hide();
					vm.generateOtpEnterInvalid = true;
					
					/*for (var i = 0, len = res.errorCodes.length; i < len; i++) {
						if (res.errorCodes[i].errcode === 2033) {
							vm.emailsentunsuccefully = true;
							vm.generatedOtp = false;
						}
					}*/
				}else if (res.applicationStatusCode === 2033) {//smtp mail sending failed
					vm.emailsentunsuccefully = true;
					vm.generatedOtp = false;
					angular.element('#generateOTPmsg').hide();
				}
		}
		function OTPSubmit(){
			if(utilityService.isCheckEmpty(vm.OTPNumberTyped)){
				//vm.generateOtpEnterInvalid= true;
				vm.generatedOtp=false;
				vm.emailsentunsuccefully = false;
				vm.generateOtpEnterInvalid=false;
				 angular.element('#generateOTPmsg').hide();
			}else{
				 var request=angular.extend({},{
					 loginName:vm.loginName,
					 otpCode:vm.OTPNumberTyped,
					 registrationPage:false
				 });
				 $rootScope.dataLoading = true;
				validateOtp(request).then(processOtpNumberResponse);	
			}
    } 
		function validateOtp(request){
						
			return forgetPasswordService.submitOtpNumberUrl(request);
		}
		function processOtpNumberResponse(response){
			var res= response.body;
			vm.emailsentunsuccefully = false;
			$rootScope.dataLoading = false;
			if(res.applicationStatusCode===1001){
				 vm.relogin=true;
	     		   vm.forgetpasswordOTPNumber=false;
	     		   vm.retypeforgetpassword=true;
				   vm.otpvalidated=true;
				   angular.element(".item-text").hide();
				   angular.element("#otpvalidated").show();
				 
			}else if(res.applicationStatusCode===2034){
				 angular.element(".item-text").hide();
				for(var i=0,len=res.errorCodes.length;i<len;i++){
					if(res.errorCodes[i].errcode===2003){
						vm.forgetpasswordOTPNumber=true;
						vm.generateOtpEnterInvalid= true;
						
						angular.element("#generateOTPmsg").hide();
						 vm.generatedOtp=false;
						 vm.emailsentsuccefully=false;
						}
				}
				
				
			}
			
		}
		function changePassword(){
			if(utilityService.isCheckEmpty(vm.secureUserPassword)||utilityService.isCheckEmpty(vm.retypeSecureUserPassword)){
				vm.reTypePasswordFailed= true;
				vm.otpvalidated=false;
			}else{
				if(vm.secureUserPassword===vm.retypeSecureUserPassword){
					var secureUser ={
		    				 userName:vm.loginName,
		    				 password:vm.secureUserPassword
		    		 };
					$rootScope.dataLoading = true;
		        	callChangePassword(secureUser).then(submitForgetPasswordResponse);
                }
			}
			
			   	
        }
		function reTypePassword(){
			vm.otpvalidated=false;
			vm.reTypePasswordFailed= false;
        	vm.passwordIncorrect=!(vm.secureUserPassword===vm.retypeSecureUserPassword);
        	
        }
		function callChangePassword(secureUser){
			return forgetPasswordService.callChangePassword(secureUser);
			
		}
		function reloginAgain(){
			$state.go('login');
		}
		function submitForgetPasswordResponse(response){
			var body= response.body;
			$rootScope.dataLoading = false;
			if(body.applicationStatusCode===1002){
			   vm.retypeforgetpassword= false;
				vm.passwordChanges= true;
				 
			}// need to discuss if change password is failed else if (applicationStatusCode===) 
			
		}
		function processForgetPasswordResponse(response){
			  var body= response.body;
			  $rootScope.dataLoading = false;
			   if(body.applicationStatusCode===1003){
				   angular.element(".item-text").hide();
				      var data =body.data[0];
				      vm.forgetpasswordPanel=false;
					  vm.forgetpasswordOTPNumber=true;
					  vm.notexistingusererror= false;
					  vm.isGenerateOTPNumber= true;
					  vm.enterLoginName=false;
					  vm.generateOtpEnter= true;
					  forgetPasswordService.OTPNumber = data.otp;
					  vm.secureUserName=data.userName;
					  forgetPasswordService.mobileNumber = vm.mobileNumber=data.formatMobile;
			   }else if(body.applicationStatusCode===2002){
				   for(var i=0,len=body.errorCodes.length;i<len;i++){
						if(body.errorCodes[i].errcode==2002){
							
				    	   vm.notexistingusererror= true;
						   vm.forgetpasswordPanel=true; 
				       }
				      
			   }
			  
			  
			  
		}
    }
}]);
});