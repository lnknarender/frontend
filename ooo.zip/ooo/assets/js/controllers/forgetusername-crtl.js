'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("ForgetUserNameCtrl", ['$state','utilityService', function($state, utilityService) {
	   var vm = this;
  
}]);
});