
define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  
	controllers.controller("addToWalletCtrl", ['$scope','$state','utilityService','stateService', function($scope,$state, utilityService,stateService) {
		var vm = this;
		vm.addMoneyToWallet=function(){
			alert(vm.amount);
		}
	
	}]);

	

});
