/* global requirejs, define */

'use strict';
/**
 * This file sets up the basic module libraries you'll need
 * for your application.
 */
requirejs.onError = function(err) {
    //console.log(err.requireType);
    if (err.requireType === 'timeout') {
        //console.error('modules: ' + err.requireModules);
    }
    throw err;
};
/**
 * RequireJS Config
 * This is configuration for the entire application.
 */
require.config({
    enforceDefine : false,
    xhtml : false,    
	//Cache buster
    //urlArgs : '_=' + Date.now(),
    waitSeconds : 15,
    config : {
        text : {
            env : 'xhr'
        }
    },
    paths : {
        
       directives : './directives',
        // Named References
        config: './config',
        app: './app',

        //Angular App Modules
        'controllers-module': 'controllers/module',
        'directives-module': 'directives/module',
        'services-module': 'services/module',
        'filters-module': 'filters/module',

        // angularjs + modules
    
        jquery: 'bower_components/jquery/jquery-1.11.3',
        jueryUI:'bower_components/jquery/jquery-ui',
         angular: 'bower_components/angular/angular.min',
        'angular-ui-router': 'bower_components/angular-ui-router/angular-ui-router.min',
		'ngStorage': 'bower_components/ngstorage/ngStorage.min',
		underscore: 'bower_components/underscore/underscore-min',
		
		bootstrap: 'bower_components/bootstrap/js/bootstrap',
		angularUi: 'bower_components/angular-ui-bootstrap/ui-bootstrap',
		angularUitpls: 'bower_components/angular-ui-bootstrap/ui-bootstrap-tpls',
		//autocomplete:'bower_components/autocomplete/simpleAutocomplete',
		translate:'bower_components/translate/angular-translate.min',
		moment:'bower_components/moment/moment.min',
		jssorSlider:'bower_components/slider/jssor.slider.min',
		jsSlider:'bower_components/slider/jsSlider',
		angularGird: 'bower_components/ui-grid/ui-grid',
		jquerySlider:'bower_components/jquery/slick',
		pdf:'bower_components/jquery/jspdf.min',
		canvas:'bower_components/jquery/html2canvas'
		
			
		
    },
   
    priority: [
        'jquery',
        'jueryUI',
        'angular',
        'angular-ui-router',
		'ngStorage',
        'bootstrap',
		'canvas',
        'pdf'
    ],    
    shim : {
		'angular' : {
			deps: ['jquery'],
			exports : 'angular'
		},
		'jueryUI':['jquery'],
		'angular-route': ['angular'],
		'angular-ui-router': ['angular'],
		'ngStorage': ['angular'],
        'bootstrap': ['jquery'],
        'angularUi': ['angular'],
		'angularUitpls': ['angular'],
        //'autocomplete': ['angular'],
        'translate':['angular'],
        'moment':['jquery'],
        'jssorSlider':['jquery'],
        'jsSlider':['jquery'],
        'angularGird':['angular'],
		'pdf':['jquery'],
        'canvas':['pdf'],
        underscore : {
            exports : '_'
        },
		bootstrapper: {
			deps: [
				'app',
				'directives-module',
				'services-module',
				'controllers-module',
				'filters-module',
				'routes'
			]
		}
    }
});
