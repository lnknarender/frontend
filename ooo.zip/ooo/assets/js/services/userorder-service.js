/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("userOrdersService",['$q', 'ajaxService', 'urlService',function($q, ajaxService, urlService){
	 return {
	    	getActiveOrders:function(loginDetails){
	    	
	    		var url = urlService.getUserOrdersUrl();
	            return ajaxService.doGet(url,loginDetails);
	      },
	      
	    getHistoryOrders:function(loginDetails){
	    	  var url = urlService.getUserOrdersUrl();
	          return ajaxService.doGet(url,loginDetails);
	    }
		
	};
	}]);
    
	return services;
});