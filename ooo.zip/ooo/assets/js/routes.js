
/**
 * Router Config
 * This is the router definition that defines all application routes.
 */
/*global define */
define([ 'angular', 'controllers/main', 'angular-ui-router' ], function (angular, controllers) {
    
    'use strict';
    
    return angular.module('app.routes', [ 'ui.router','pascalprecht.translate' ]).config([ "$stateProvider", "$urlRouterProvider", "$locationProvider", '$translateProvider',function ($stateProvider, $urlRouterProvider, $locationProvider,$translateProvider) {
        //Turn on or off HTML5 mode which uses the # hash
        $locationProvider.html5Mode(false);
          /**
           * Router paths
           * This is where the name of the route is matched to the controller and view template.
		    current no abstarct route is set...
           */
    	
		$translateProvider.translations('tel', translationsTE);
		$translateProvider.translations('eng', translationsEN);
		$translateProvider.translations('hin', translationsHINDI);
	
		//$translateProvider.translations('mar', translationsMARATI);
		//$translateProvider.translations('tam', translationsTAMIL);
		$translateProvider.preferredLanguage('eng');
		$translateProvider.fallbackLanguage('eng');
      $stateProvider
        .state('gotoviewdetails', {
        		url:'/gotoviewdetails',
        		templateUrl: 'assets/templates/search/search.html',
        		//controller: 'defaultSearchCtrl',
        		controllerAs: 'vm'
         })
         .state('error', {
      	    	url:'/error',
      	    	templateUrl: 'assets/templates/error.html',
      	    	controllerAs: 'vm'
          })
          .state('start', {
          	 	url:'/start',
          	 	templateUrl: 'assets/templates/home.html',
          	 	controller: 'homePageCtrl',
          	 	controllerAs: 'vm'
          })
          .state('login', {
          	 	url:'/login',
          	 	templateUrl: 'assets/templates/login/login.html',
          	 	controller: 'loginCtrl',
          	 	controllerAs: 'vm'
          })
          .state('productdetails', {
          	 	url:'/productdetails/:id',
          	 	templateUrl: 'assets/templates/orderManagement/productDetails.html',
          	 	controller: 'productDetailCtrl',
          	 	controllerAs: 'vm'
          })
          .state('myCart', {
          	 	url:'/myCart',
          	 	templateUrl: 'assets/templates/orderManagement/myCart.html',
          	 	controller: 'myCartCtrl',
          	 	controllerAs: 'vm'
          })
          .state('advancedsearchviewall', {
           	 	url:'/advancedsearchviewall?srchtxt&type&level&cats&brands&prices&grades&sp&bs&pin&state&season',
           	 	templateUrl: 'assets/templates/search/advancedSearch.html',
           	 	controller: 'AdvancedSearchCtrl',
           	 	controllerAs: 'vm'
         })
          .state('advancedsearchdetails', {
          	 	url:'/advancedsearchdetails?srchtxt&type&brands&prices&grades&catlevel&pin&state&season',
          	 	templateUrl: 'assets/templates/search/groupedSearch.html',
          	 	controller: 'GroupedSearchCtrl',
          	 	controllerAs: 'vm'
          })
          .state('buyFinancing', {
          	 	url:'/buyFinancing',
          	 	templateUrl: 'assets/templates/search/buyFinancing.html',
          	 	controller: 'AdvancedSearchCtrl',
          	 	controllerAs: 'vm'
         })
         .state('sellCommodities', {
          	 	url:'/sellCommodities',
          	 	templateUrl: 'assets/templates/search/sellCommodities.html',
          	 	controller: 'AdvancedSearchCtrl',
          	 	controllerAs: 'vm'
          }) 
		.state('submitDemand', {
          	 	url:'/submitDemand',
          	 	templateUrl: 'assets/templates/search/submitDemand.html',
          	 	controller: 'submitDemandCtrl',
          	 	controllerAs: 'vm'
          }) 
          .state('downloadApp', {
        	  url:'/downloadApp',
              templateUrl: 'assets/templates/search/downloadApp.html',
              controller: 'homePageCtrl',
              controllerAs: 'vm'
          })
          .state('freebies', {
        	  url:'/freebies',
              templateUrl: 'assets/templates/search/freebies.html',
              controller: 'AdvancedSearchCtrl',
              controllerAs: 'vm'
          })
          .state('specialAuctions', {
        	  url:'/specialAuctions',
              templateUrl: 'assets/templates/search/specialAuctions.html',
              controller: 'AdvancedSearchCtrl',
              controllerAs: 'vm'
          })
          .state('findStoreOrWarhouse', {
        	  url:'/findStoreOrWarhouse',
              templateUrl: 'assets/templates/search/findStoreOrWarhouse.html',
              controller: 'AdvancedSearchCtrl',
              controllerAs: 'vm'
          })
          .state('forgotPassword', {
        	  url:'/forgotPassword',
              templateUrl: 'assets/templates/login/forgetpassword.html',
              controller: 'ForgetPasswordCtrl',
              controllerAs: 'vm'
          })
          .state('forgotUserName', {
        	  url:'/forgotUserName',
              templateUrl: 'assets/templates/login/forgetusername.html',
              controller: 'ForgetUserNameCtrl',
              controllerAs: 'vm'
          })
          .state('userRegistration', {
        	  url:'/userRegistration',
              templateUrl: 'assets/templates/login/registration.html',
              controller: 'registrationCtrl',
              controllerAs: 'vm'
          })
          .state('contactUs', {
        	  url:'/contactUs',
              templateUrl: 'assets/templates/header/contactUs.html',
              //controller: 'registrationCtrl',
              controllerAs: 'vm'
          })
          .state('aboutUs', {
        	  url:'/aboutUs',
              templateUrl: 'assets/templates/header/aboutUs.html',
              //controller: 'registrationCtrl',
              controllerAs: 'vm'
          })
          .state('crops', {
        	  url:'/crops',
              templateUrl: 'assets/templates/header/crops.html',
              //controller: 'registrationCtrl',
              controllerAs: 'vm'
          })
         .state('mylisting', {
        	  url:'/mylisting',
              templateUrl: 'assets/templates/inputFarmListing/inputFarmListing.html',
              controller: 'farmInputCtrl',
              controllerAs: 'vm'
          })
          .state('farminput', {
        	  url:'/farminput',
              templateUrl: 'assets/templates/inputFarmListing/createFarmInput.html',
              controller: 'createFarmInputCtrl',
              controllerAs: 'vm'
          })
          .state('faq', {
        	  url:'/faq',
              templateUrl: 'assets/templates/header/faq.html',
              //controller: 'registrationCtrl',
              controllerAs: 'vm'
          })
          .state('storeLocator', {
        	  url:'/storeLocator/:state/:district/:type',
              templateUrl: 'assets/templates/search/storeLocator.html',
              controller: 'storeLocatorCtrl',
              controllerAs: 'vm'
          })
          .state('storeLocator1', {
        	  url:'/storeLocator/:state/:type',
              templateUrl: 'assets/templates/search/storeLocator.html',
              controller: 'storeLocatorCtrl',
              controllerAs: 'vm'
          })
          .state('knowMore', {
        	   url:'/knowMore',
              templateUrl: 'assets/templates/header/comingSoon.html',
              //controller: 'homePageCtrl',
              controllerAs: 'vm'
          })
          .state('placeorder', {
        	  url:'/placeorder',
              templateUrl: 'assets/templates/orderManagement/placeOrder.html',
              controller: 'placeorderCtrl',
              controllerAs: 'vm'
          })
          .state('offers',{
        	  url:'/offers',
          	templateUrl:'assets/templates/userAccount/offers.html',
          	controller: 'userAccountCtrl',
          	controllerAs:'vm'
          })
          .state('noResultFound',{
        	  url:'/noResultFound',
          	templateUrl:'assets/templates/header/noResultFound.html'
          })
          .state('noproductfound',{
        	  url:'/noproductfound',
          	templateUrl:'assets/templates/orderManagement/noResultFound.html'
          })
          .state('useraccount',{
        	  url:'/useraccount',
        	  controller: 'userAccountCtrl',
          	templateUrl:'assets/templates/userAccount/useraccount.html',
          	 controllerAs: 'vm'
          })
          .state('ordersuccess',{
        	  url:'/ordersuccess',
          	templateUrl:'assets/templates/orderManagement/order-summary.html',
          	 controller: 'placeorderSuccessCtrl',
               controllerAs: 'vm'
          }).
          state('nowarehouse',{
        	  url:'/nowarehouse',
          	templateUrl:'assets/templates/header/noWareHouseResultFound.html',
          	controller: 'orderSuccessCtrl',
            controllerAs: 'vm'
          }).state('wallet',{
        	    url:'/wallet',
            	templateUrl:'assets/templates/userAccount/wallet.html',
            	controller: 'userAccountCtrl',
              controllerAs: 'vm'
            }).
			state('orders', {
        	  url:'/orders',
              templateUrl: 'assets/templates/userAccount/userOrders.html',
              controller: 'userOrdersCtrl',
              controllerAs: 'vm',
              title: "Orders"
          }).
          state('wishlist', {
    	  url:'/wishlist',
          templateUrl: 'assets/templates/userAccount/userWishlist.html',
          controller: 'userWishlistCtrl',
          controllerAs: 'vm',
          title: "Wishlist"
      })
       .state('demands', {
    	  url:'/demands',
          templateUrl: 'assets/templates/userAccount/userDemands.html',
          controller: 'userDemandsCtrl',
          controllerAs: 'vm',
          title: "Demands"
      })
       .state('admin', {
    	  url:'/admin/:id',
          templateUrl: 'assets/templates/admin/adminRoles.html',
          controller: 'adminRolesCtrl',
          controllerAs: 'vm',
          title: "Admin"
      });
        $urlRouterProvider.otherwise('start');
    } ]);
});
