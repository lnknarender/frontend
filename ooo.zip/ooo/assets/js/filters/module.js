
/*
 * Define Angular app.directives module
 */
define(['angular'], function (angular) {
    
    var module =  angular.module('app.filters', []);
	
    module.config(['$compileProvider',function($compileProvider){
	
        module._filter = module.filter;
	
        module.filter = function(name, factory) {
            $compileProvider.filter( name, factory );
            return( this );
        };
	
    }]);
  	

	return module;	
});