/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("myCartService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService', '$sessionStorage',function($q, ajaxService, stateService, utilityService,urlService,$sessionStorage){
		return	{
			  addProductDetailsToCart: function (productDetails) {
            var url =  urlService.addproductDetailsToCartUrl();
            return ajaxService.doPost(url,{},productDetails);
        },
        removeFromCart:function (request) {
            var url =  urlService.removeFromCartUrl();
            return ajaxService.doDelete(url,request);
        },
        checkAvailibality: function (request) {
            var url =  urlService.checkAvailibalityUrl();
            return ajaxService.doGet(url,request);
        },
        updateQuantity: function (request) {
            var url =  urlService.updateQuantityUrl();
            return ajaxService.doPut(url,{},request);
        },
        getCart: function (request) {
            var url =  urlService.getCartUrl();
            return ajaxService.doGet(url,request);
        },
        getCartPincode: function() {
			return typeof $sessionStorage["cartProduct.pinCode"] != "undefined" ? $sessionStorage["cartProduct.pinCode"] : false;
		},
		getCartQuantity:function() {
			return typeof $sessionStorage["cartProduct.quantity"] != "undefined" ? $sessionStorage["cartProduct.quantity"] : false;
		},
        getCartProductId: function(){
        	return typeof $sessionStorage["cartProduct.productId"] != "undefined" ? $sessionStorage["cartProduct.productId"] : false; 
        }
		};
	}]);
    
	return services;
});