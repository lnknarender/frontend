/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("forgetUserNameService",['$q', 'ajaxService', 'stateService', 'utilityService',,function($q, ajaxService, stateService, utilityService){
		return	{
			callForgetUserName: function (request) {
	            var url = urlService.callForgetUserNameUrl();
	            return ajaxService.doPost(url, {},request);
	        }
		};
	}]);
    
	return services;
});