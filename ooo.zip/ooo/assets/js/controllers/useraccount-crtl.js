'use strict';

define(['angular',
        'controllers-module',
              'underscore'
        ], function(angular, controllers, underscore) {  

              // Add Attribute Controller
controllers.controller("userAccountCtrl", ['$rootScope','$scope','$state','stateService','userAccountService','$window','loginService','$sessionStorage', function($rootScope,$scope,$state,stateService,userAccountService,$window,loginService,$sessionStorage) {
       
       
       

        var vm = this;
      //  var userAdd={};
        var bankInfo={};
        var userInfo = loginService.getUserInfo();
        vm.userInfo = angular.copy(userInfo);
        $scope.loading = true; 
        vm.successchange=false;
         vm.transactions=[];
         vm.farminput=0.00;
         vm.commodities=0.00;
         vm.machinary=0.00;
         vm.exportBtnStatus=true;
         vm.failureMessage = false;
        // vm.userAccountClick=userAccountClick; 
         vm.backHome=backHome;   
         vm.showOTP=false;
         vm.verifyPassword=verifyPassword;
         vm.changePassword=changePassword;
         vm.resetField=resetField;
         vm.reGenerateOTP=reGenerateOTP;
         vm.tabPersonalInfo = tabPersonalInfo;
         vm.tabChangePswd = tabChangePswd;
         vm.tabaddresschange=tabaddresschange;
         vm.tabbankaccount=tabbankaccount;
         vm.tabMobileEmail=tabMobileEmail;
         vm.addBankDetails = addNewBankDetails;
         vm.addAddressDetails=addAddressDetails;
         vm.getStateChange=getStateChange;
         vm.districtList =userAccountService.districtList;
         vm.userOffers = userOffers;
         vm.loanApplying = ['FarmInput','Commodities','Machinery'];
         vm.loanExistOrNot = ['Yes','No'];
         vm.sourceOfIncome = ['Business','Government Service','Private Job'];
        var newpassword=null;
         vm.userStatus='';
         vm.bankaddedsucess= false;
         vm.bankaddedfailure=false;
       
         vm.farm_input_loan = function(){
               vm.loanType="Farm Input";
               vm.success=false;
               vm.failure=false;
              
               vm.loanApplyingFor='';
              vm.loan_amount='';
               vm.tenure='';
               $scope.loanForm.$setPristine();
               $scope.loanForm.$setUntouched();
              }
              vm.export_excel = function(e){
              
                                     var uri = 'data:application/vnd.ms-excel;base64,'
                                  , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
                                                , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
                                                , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
                                           var table= $(".transaction-table").clone();
                                           var row = $(table).find("tr")[0];
                                           var head ="<tr><th>PROCESS</th><th>WITHDRAWAL</th><th>DEPOSIT</th><th>STATUS</th><th>COMMENT</th></tr>"
                                                  $(head).css({"background-color" :"yellow"});
                                                $(head).insertBefore(row);
                                                
                                  var ctx = {worksheet: 'Trasnsaction Details' || 'Worksheet', table: $(table).html()}
                                         
                                           $window.open(uri+base64(format(template,ctx)));
              }
         
         vm.farm_equipment_loan=function(){
               vm.loanType="Farm Equipments";
               vm.success=false;
               vm.failure=false;
            
               vm.loanApplyingFor='';
              vm.loan_amount='';
               vm.tenure='';
               $scope.loanForm.$setPristine();
               $scope.loanForm.$setUntouched();
         }
         vm.farm_commodity_loan=function(){
               vm.loanType="Farm Commodities";
               vm.success=false;
               vm.failure=false;
               
               vm.loanApplyingFor='';
              vm.loan_amount='';
               vm.tenure='';
               $scope.loanForm.$setPristine();
               $scope.loanForm.$setUntouched();
         }
         if(!vm.userInfo) {
              $state.go('start');
         }
         
         vm.isFormValid = function(){
               if(vm.existingLoan==='Yes'){
                      var myenable = ($scope.loanForm.$invalid||$scope.existloanForm.$invalid);
                      return myenable;
               }
               else{
                      return ($scope.loanForm.$invalid);
               }
         }
         vm.onExistLoanChange = function() {
               if(vm.existingLoan==='Yes'){
                      angular.element('#loanexist').show();
               }
               else{
                      angular.element('#loanexist').hide();
               }
         }
         wallet();
         function wallet(){
               var userInfo = angular.extend({},{
                      userName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
               });
               $rootScope.dataLoading = true;
				$rootScope.dataStillLoading = true;
               return callUserWalletDetails(userInfo).then(processUserWalletDetails);
         }
         
         function callUserWalletDetails(userInfo){
                      
               return userAccountService.getUserWallet(userInfo);
         }
         
         function processUserWalletDetails(response){
               
                var applicationStatusCode=response.body.applicationStatusCode;
                $rootScope.dataLoading = false;
				$rootScope.dataStillLoading = false;
                if(applicationStatusCode==1025){
                       var data =response.body.data[0];
                       vm.farminput = (data.farminput==null)?0:data.farminput;
                       vm.commodities = (data.commodites==null)?0:data.commodities;
                       vm.machinary=(data.machinary==null)?0:data.machinary;
                       vm.transactions=data.userwalletTransaction;
                       console.log(vm.transactions);
                       vm.exportBtnStatus= (vm.transactions.length>0)?false:true;
                       //console.log(farminput);
                }
              
         }
         function addAddressDetails(){
					 var userAdd1 = {
						loginName : vm.userInfo.userName,
						address : {
							name : vm.userName,
							address : vm.newShippingAddress,
							landmark : vm.landMark,
							district : $("#districtNameAddr option:selected").html(),
							state : $("#stateNameAddr option:selected").html(),
							pinCode : vm.pincode,
							landLineNo : vm.landline,
							country : 'India',
							addressAttribute : 'SA'
						}
               
					 }
               vm.userAdd = angular.copy(userAdd1.address);
					 $rootScope.dataLoading = true;
               return callAddShipAdd(userAdd1).then(processUserAddResponse);
         }
         
        function callAddShipAdd(userAdd1){
               return userAccountService.getAddShipping(userAdd1);
         }
        
        function processUserAddResponse(response){
        	$rootScope.dataLoading = false;
              if(response.body.applicationStatusCode===1023){
            	 
                    var p ={
                    		'nameShip' :vm.userAdd.name,
                    		'addressLine1': vm.userAdd.address,
                    			'addressLine2': "",
                    				'landmark': vm.userAdd.landmark,
                    					'district': vm.userAdd.district,
                    						'state': vm.userAdd.state,
                    							'countryName': 'India',
                    									'phoneNo' : vm.userAdd.landLineNo,
                    									'addrAttr' : 'SA'
                    }
                     vm.successMessage=true;
                    vm.address.push(p);
                    vm.shiipingAddrSelected=false;
              }
              else{
            	  vm.successMessage=false;
            	  vm.failureMessage = true;
            	  
            	  
              }
              vm.userName='';
              $("#newShippingAddress").val('')
              vm.landMark='';
       
              document.getElementById('districtNameAddr').selectedIndex=0;
              document.getElementById('stateNameAddr').selectedIndex=0;
       
              vm.pincode='';
              vm.landline='';
    		  $('body').scrollTop(0);
              $scope.addressDetailsAdd.$setPristine();
              $scope.addressDetailsAdd.$setUntouched();
              
        }
         
        vm.bankAdd = function(){
        	vm.showOTP = true;
        	vm.OTPNumberTyped1='';
            reGenerateOTP(vm.userInfo.userName);
            $scope.otpForm1.$setPristine();
            $scope.otpForm1.$setUntouched();
        }
        
         function addNewBankDetails(){
               vm.accountNoVerify=false;
               vm.userbankdetailsadded=false;
            bankInfo = angular.extend({},{
                      userName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
                      //accountHolderName:vm.accountHolderName,
                      userFullName:vm.accountHolderName,
                      bankName:vm.bankName,
                     // accountNumber:vm.accountNumber,
                      accountNo:vm.accountNumber,
                      ifscCode:vm.ifscCode,
                      branch:vm.branch,
                      //state:vm.statename,
                      state:$("#stateName option:selected").html(),
                     district:vm.districtName
               });
               vm.userInfo.userName='';
               vm.accountHolderName='';
               vm.bankName='';
               vm.accountNumber='';
               vm.ifscCode='';
               vm.branch='';
               vm.districtName='';
               document.getElementById('stateName').selectedIndex=0;
               vm.bankdetailsSelected=false;
               $scope.changeBank.$setPristine();
               $scope.changeBank.$setUntouched();
               $rootScope.dataLoading = true;
               return callAddBankDetails(bankInfo).then(processAddBankDetailsResponse);
               //alert("added succefully");
              // $('#bankdetails-change').toggle();
               vm.bankdetailsAdd=null;
         }
         vm.onSelectOfAddBank =function onSelectofAddBank(){
        // vm.isDisabled();
         vm.showBank = !vm.showBank;
         
         }
         vm.onSelectOfShiipingAddr=function onSelectOfShiipingAddr(){
              vm.showShippingAddr =!vm.showShippingAddr;
         }
         
         function callAddBankDetails(bankInfo){
               return userAccountService.addBankDetails(bankInfo);
         }
         
         function processAddBankDetailsResponse(response){
        	 $rootScope.dataLoading = false;
               if(response.body.applicationStatusCode===1026)
                 {
                     
                     vm.showOTP=false;    
                     vm.bankaddedsucess=true;
                     vm.bankDetails.push(bankInfo);
                     vm.bankdetailsSelected=false;
                     
                 }else if(response.body.applicationStatusCode===2076){
                       vm.accountNoVerify=true;
                       vm.bankaddedsucess=false;
                       vm.bankaddedfailure=true;
                 }
         }
         function tabPersonalInfo(){
               
              $(".or-user-detail-tab1").show();
              $('.or-user-detail-tab2').hide();
              $('.or-user-detail-tab3').hide();
              $('.or-user-detail-tab4').hide();
              $('.or-user-detail-tab5').hide();
              
         }
         function tabChangePswd(){
        	 vm.oldPassword='';
        	 vm.newUserPassword='';
        
        	 vm.retypeUserPassword='';
        	  vm.OTPNumberType='';
        	 $(".passwordconfirmationmsg forgot-success").css('display','none');
        	 $(".newpasswordsetwithOTP").css('display','none');
        	 $(".or-change-passowrd").css('display','block');
        	 vm.changepasswordnotEqaul=false;
        	 vm.notexistingusererror=false;
        	 vm.successchange=false;
               angular.element('#old_password').val("");
               angular.element('#new_password').val("");
               angular.element('#reTypePswd').val("");
               $scope.setNewPswd.$setPristine();
               $scope.setNewPswd.$setUntouched();
             
               
              $(".or-user-detail-tab1").hide();
              $('.or-user-detail-tab2').show();
              $('.or-user-detail-tab3').hide();
              $('.or-user-detail-tab4').hide();
              $('.or-user-detail-tab5').hide();
              
         }
         function tabaddresschange(){
        	 vm.shiipingAddrSelected=false;
               angular.element('#user_name').val("");
               angular.element('#newShippingAddress').val("");
               angular.element('#shpAddrLandmark').val("");           
               angular.element('#landline').val("");
               angular.element('#pincode').val("");
               document.getElementById('stateNameAddr').selectedIndex=0;
               document.getElementById('districtNameAddr').selectedIndex=0;
               vm.successMessage=false;
               vm.failureMessage=false;
               $scope.addressDetailsAdd.$setPristine();
               $scope.addressDetailsAdd.$setUntouched();
               
              // $("#addresschange").click(function(){$('.class').toggle()});
               $('.or-user-detail-tab3').show();
               $(".or-user-detail-tab1").hide();
              $('.or-user-detail-tab2').hide();
              $('.or-user-detail-tab4').hide();
              $('.or-user-detail-tab5').hide();
         }
         function tabbankaccount(){
               
               angular.element('#accnt_holder_name').val("");
               angular.element('#bankname').val("");
               angular.element('#acntnumber').val("");                
               angular.element('#IFSCCode').val("");
               angular.element('#branchname').val("");
               vm.showOTP=false;
               vm.bankdetailsSelected=false;
               $scope.changeBank.$setPristine();
               $scope.changeBank.$setUntouched();
               vm.bankaddedsucess= false;
               vm.bankaddedfailure=false;
             
               
               
              $(".or-user-detail-tab1").hide();
              $('.or-user-detail-tab2').hide();
              $('.or-user-detail-tab3').hide();
              $('.or-user-detail-tab4').show();
              $('.or-user-detail-tab5').hide();
         
         }
         function tabMobileEmail(){
               $(".or-user-detail-tab1").hide();
               $('.or-user-detail-tab2').hide();
               $('.or-user-detail-tab3').hide();
               $('.or-user-detail-tab4').hide();
               $('.or-user-detail-tab5').show();
             //  vm.showOTP = true;
          }
         
         
     
     
     
         function changePassword(){
               angular.element("#newpasswordsetwithOTP").hide();
               var generateOTPInfo = angular.extend({},{
                        userName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
                      //userName:"anurag",
                 newPassword:newpassword,
                 otpCode:vm.OTPNumberTyped
                 
          });
               return callChangePassword(generateOTPInfo).then(processChangePasswordResponse);
         }
         vm.checkBankOTP = function(){
        	  var  loginName=
        		  angular.extend({},{
                  'loginName': vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME)
                  'otpCode':vm.OTPNumberTyped1,
                  'registrationPage':false
              
           });
        	 userAccountService.ValidateOTP(loginName).then(processResponse);
        	 
        	 
         }
         function processResponse(response){
        	 if(response.body.applicationStatusCode===1001){
        		 addNewBankDetails();
        		 
        		 
          }else if(response.body.applicationStatusCode===2034){
                 vm.otpInvalid=true;
                 vm.generatedOTP=false;
          }
        	 
         }
         
         function callChangePassword(generateOTPInfo){
               return userAccountService.changePassword(generateOTPInfo);
               
         }
         function processChangePasswordResponse(response){
               if(response.body.applicationStatusCode===1002){
            	   	vm.successchange =true;
                      angular.element(".newpasswordsetwithOTP").hide();
               }else if(response.body.applicationStatusCode===2034){
                      vm.otpInvalid=true;
                      vm.generatedOTP=false;
               }
               
         }
         
         init();
         function backHome(){
              
         }
         function init(){  
               //angular.element('.generateOTP-class').hide();
              var  useraccount=angular.extend({},{
                     userName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
                     //userName:"anurag"
              });
             callUserAccount(useraccount).then(processUserAccountResponse);
             callStateDetails().then(processStateDataResponse);
             }
       function callUserAccount(useraccount) {
             vm.waitingForPageToLoad = true;

             return userAccountService.userAccount(useraccount);
         };
    function processUserAccountResponse(response){
      
          var data = response.body.data[0].personalInfo;
              vm.fullName=data.fullName;
             vm.email=data.email;
             vm.mobileNo=data.mobileNo;
             if(data.birthDate){
             vm.dob=formatDate(data.birthDate); 
             }
             /*
             console.log(vm.dob);
             console.log(formatDate(data.birthDate));*/
             if(data.gender=='M'){
                    vm.gender='Male';
             }
             else{
                    vm.gender='Female'
             }
       
              vm.status=data.status;
             vm.progressStatus=data.progressStatus;
             
              if(vm.progressStatus==='otpVerification' && vm.status==='Inactive'){
                    vm.userStatus='Manual Verification is Pending.';
             }else if (vm.progressStatus==='documentUpload' && vm.status==='Inactive'){
                    vm.userStatus='OTP Verification is Pending.';
             }else if(vm.progressStatus==='registration' && vm.status==='Inactive'){
                    vm.userStatus ='Document Upload is Pending.';
             }else{
              vm.userStatus= 'Manual Verification Completed.';
             }
             //console.log("data");
             //console.log(response.body.data);
             
              vm.address = response.body.data[0].addressDetails;
             //console.log(vm.address);
             
              
              vm.bankDetails = response.body.data[0].bankDetails;
             
              
    }
    function formatDate (input) {
         var datePart = input.match(/\d+/g),
         year = datePart[0].substring(0), // get only two digits
         month = datePart[1], day = datePart[2];

         return day+'/'+month+'/'+year;
       }
    function verifyPassword(){
         var userInfo  =angular.extend({},{
                userName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
               // userName:"anurag",
                oldPassword:vm.oldPassword
         });
         newpassword = vm.newUserPassword;
         if(vm.newUserPassword!=vm.oldPassword ){
                if(vm.newUserPassword!=vm.retypeUserPassword)
                       {
                          angular.element("#passerror").show();
                       }
                else
                       {
                return callverifyPassword(userInfo).then(processverifyPasswordResponse);
                       }
         }else{vm.changepasswordnotEqaul=true;}
    }
    
    function callverifyPassword(userInfo){
         
          return userAccountService.verifyPassword(userInfo);
    }
    
    function processverifyPasswordResponse(response){
         if(response.body.applicationStatusCode===1024)
                {
                   
                  var userName = angular.extend({},{
                       loginName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
                     //loginName:"anurag"
                });
                 
                 angular.element(".or-change-passowrd").hide();
             angular.element(".newpasswordsetwithOTP").show();
                 return callGenerateOTP(userName).then(processGenerateOTPResponse); 
                 
                 }
         else if(response.body.applicationStatusCode===2050){              
               
                vm.notexistingusererror=true;
         }
         else{
                //Internal Server Error
               
          }
          }
   function resetField(){
          vm.notexistingusererror=false;
   }
    function callGenerateOTP(userName){
       return userAccountService. generateOTP(userName);
       
    }
    
    function processGenerateOTPResponse(response){
        var res= response.body;
       if(response.body.applicationStatusCode===1018){ 
              vm.failedtosend=false;
                vm.generatedOTP=true;
          } else if (response.body.applicationStatusCode === 2032) {
                     vm.failedtosend=true;
                   vm.generatedOTP=true;
                     for (var i = 0, len = res.errorCodes.length; i < len; i++) {
                           if (res.errorCodes[i].errcode === 2033) {
                           
                           }
                     }
              }
    }
    function reGenerateOTP(userName){
       var userName = angular.extend({},{
                       loginName: $sessionStorage["userInfo"].userName //stateService.get(constants.STATE_USER_NAME)
                      //loginName:"anurag"
                });
       
        return callGenerateOTP(userName).then(processGenerateOTPResponse); 
    }
    function userOffers(){
       if(vm.existingLoan==='Yes')
              {
                var exist = true;
              }
       else{
              var exist = false;
       }
              
              
       var userOffer = angular.extend({},{
            userName: vm.userInfo.userName, //stateService.get(constants.STATE_USER_NAME),
            loanApplyingFor:vm.loanType,
            amountOfLoan:+vm.loan_amount,
            tenure:+vm.tenure,
            paymentMode:vm.paymentMode 
            
       });
       $rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
                 callUserOffer(userOffer).then(processOfferResponse);
       }
       

function callUserOffer(userOffer) {
   vm.waitingForPageToLoad = true;

   return userAccountService.userOffer(userOffer);
};

function processOfferResponse(response){
	$rootScope.dataLoading = false;
	$rootScope.dataStillLoading = false;
       if(response.body.applicationStatusCode===1017){
              vm.success=true;     
              vm.loanApplyingFor='';
              vm.loan_amount='';
              vm.tenure='';

              $scope.loanForm.$setPristine();
        $scope.loanForm.$setUntouched();
              
       }else{
              vm.failure=true;
              
       }
       
};
//State & District List
function callStateDetails(){      
       return userAccountService.getIndianStateList();
}
function processStateDataResponse(response){
       var body = response.body||{};
       vm.statesList = body.data;

       //console.log(vm.statesList[0]);
       userAccountService.statesList =vm.statesList;
       //console.log(vm.statesList);
}
function getStateChange(){
       
       //vm.districtList=null;
       var request= angular.extend({},{
              stateName:vm.statename
       });    
}
vm.checkPinCodeStart = function(){
       var pin = vm.pincode;
       if(pin.charAt(0)=="0"){
              
              vm.pinValid = true;
       }else{
              
              vm.pinValid = false;
       }
}
vm.goToHomePage=function(){
	$state.go('start');
}


  
}]);
});
