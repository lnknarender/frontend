define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("userDemandsCtrl", ['$rootScope','$scope','$state','userWishlistService','utilityService','loginService','stateService','productDetailService','$timeout','$translate','$filter',
                                         function($rootScope,$scope,$state,userWishlistService,utilityService,loginService,stateService,productDetailService,$timeout,$translate,$filter) {
	var vm=this;
	var userName;
	vm.goToHomePage=function(){
		$state.go('start');
	}
	vm.goToSubmitDemand=function(){
		$state.go('submitDemand');
	}
	vm.showDemands=function(){
		userName=loginService.getUserInfo().userName;//stateService.get(constants.STATE_USER_NAME);
		var wlDetails={loginName:userName};
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		callGetSumittedDemands(wlDetails).then(callGetSumittedDemandsResponse);
		angular.element("#demands").addClass("wl_active_heading");
	}
	/*<a class='ui-grid-cell-contents' data-toggle=modal' ng-click='grid.appScope.viewDemand(row)' data-target='#viewDemands'><img src='assets/images/view.png' width='15' height='15' alt='' title='View'/></a>" +*/
	$scope.gridOptions = {  	
			 enableColumnMenu: false,
			 paginationPageSizes: [10, 50, 100],
	            paginationPageSize: 10,
			 rowEditWaitInterval: -1,
			 columnDefs: [
              { field: 'category', width:'10%',displayName:'origo.demand.category', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true,},	
		      { field: 'productName', width:'20%', displayName: 'origo.submitdemand.prodName',  headerCellFilter:'translate',enableCellEdit: false, enableColumnMenu: false, enableSorting: true,
            	  cellTemplate:'<div class="ui-grid-cell-contents word-wrap"><div data-toggle="tootltip" title="{{row.entity.productName}}">{{row.entity.productName}}</div></div>'},	
		      { field: '', width:'19%',name: 'Price (Rs.)', displayName: 'origo.cart.price', enableCellEdit:false, headerCellFilter:'translate', enableColumnMenu: false, enableSorting: true,
		    	  cellTemplate:"<div class='ui-grid-cell-contents word-wrap'>Min:{{row.entity.minPrice}}  &nbsp;&nbsp;&nbsp;&nbsp; Max:{{row.entity.maxPrice}}</div>"},
		   //   { field: 'maxPrice', name: 'Maximum Price', enableCellEdit:false, enableColumnMenu: true, enableSorting: true},
		      { field: 'updatedDate', width:'12%',displayName: 'origo.demand.createdDate', headerCellFilter:'translate', sort: { direction: 'desc', priority: 0 }, enableCellEdit: false, enableColumnMenu: false,  enableSorting: true},
		      { field: 'demandDate',width:'12%', displayName: 'origo.submitdemand.expectedDate',  headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true},
		      { field: 'location', width:'12%', displayName: 'origo.submitdemand.location', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: true},
		      { field: 'actions', width:'15%', displayName: 'origo.demand.actions', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: false,
		     cellTemplate: 
		     		'<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#viewDemands" ng-click="grid.appScope.vm.viewDemand(row.entity)">View</a>' +
		     				'<a href="javascript:void(0)" ng-click="grid.appScope.vm.deleteDemand(row);$event.stopPropagation();">Delete</a>'},
		    	
		     //displayName: 'origo.demand.actions', headerCellFilter:'translate'
		  ]
		  };
	/*data-target="#viewDemands"
	 *  data-toggle="modal" 
	 */
	function init(){
		//$scope.loading=true;
		vm.showDemands();
	}
	init();
	function callGetSumittedDemands(wlDetails){
		return userWishlistService.getSubmittedDemands(wlDetails);
	}
	function callGetSumittedDemandsResponse(response){
		var res=response.body;
		vm.demands=true;
		vm.wishlist=false;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		if(res.applicationStatusCode==1031){
			vm.userDemands=res.data;
			for(var demand=0;demand<vm.userDemands.length;demand++){
				vm.userDemands.actions;
			}
			$scope.gridOptions.data = vm.userDemands;
 			$timeout(function() {
 	    		$(window).resize();
 	    		}, 600);
		}else{
			vm.demands=false;
		}
		if(res.applicationStatusCode==1030){
			vm.userDemands=res.data;
			if(vm.userDemands==null){
				vm.noDemands=true;
			/*	$scope.gridOptions.data = vm.userDemands;
	 			$timeout(function() {
	 	    		$(window).resize();
	 	    		}, 600);*/
			}	
		}else{
			vm.noDemands=false;
		}
		//$scope.loading=false;
	}
	//Update Demand
	vm.updateDemand=function(demand){
		//go to submit demand page and pre-fill all the data related to submitted data.
		sendDemandToService(demand);
		//$state.go('submitDemand',{demandId:demand.productId});
		//$state.go('submitDemand');
		$state.go('submitDemandUpdate',{"id":demand.wishListId});
	}
	function sendDemandToService(demand){
		return userWishlistService.sendDemandToSD(demand,true);
	}
	//delete demand
	vm.deleteDemand=function(d){
		var demand=d.entity;
		//deleteFromWishList?category=Commodities&wishListId=37237
	//	var del_confirm=confirm("Are you sure you want to delete?");
		//if(del_confirm==true){
		var delDemand={
				category:demand.category,
				wishListId:demand.wishListId
		};
		callDeleteDemand(delDemand).then(callDeleteDemandResponse);	
		//}
	}
	function callDeleteDemand(delDemand){
		return userWishlistService.deleteDemand(delDemand);
	}
	function callDeleteDemandResponse(response){
		var res=response.body;
		if(res.applicationStatusCode==1036){
			
			vm.showDemands();
		}
	}
	//view demand
	vm.viewDemand=function(demand){
		vm.modalDemand=demand;
		//sendDemandToViewToService(demand);
	}
	function sendDemandToViewToService(demand){
		return userWishlistService.sendViewDemandToSD(demand);
	}
}]);

});