/*global define */
define(['angular', 'filters-module','bootstrap'], function(angular, filters,bootstrap) {
	'use strict';

	filters.filter('yesNo', function() {
	    return function(input) {
	        return input ? 'Yes' : 'No';
	    };
	});

	//Only takes date in the format yyyy-MM-dd and converts to dd/MM/yyyy
	filters.filter('reFormatDateToDDMMYYYY', function() {
	    return function(input) {
	        if(input){
	        var stringArr = input.split("-");
	        var formattedStr = stringArr[2] + "/" + stringArr[1] + "/" + stringArr[0];
	        return formattedStr;
	        }
	        else{
	            return "N/A";
	        }
	    };
	});

	//Only takes date in the format yyyy-MM-dd and converts to a string e.g. 'Friday 23rd June'
	filters.filter('reFormatDateToString', function() {
	    return function(input) {
	        if(input){
	            var dateToFormat = moment(input, 'yyyy-MM-DD');
	            var formattedDate =  moment(dateToFormat).format('dddd Do MMMM');
	            return formattedDate;
	        }
	        else{
	            return "";
	        }
	    };
	});

	//Only takes date in the format MM/YYYY and converts to a string in format MM/YY
	filters.filter('reFormatExpiryDate', function() {
	    return function(input) {
	        if(input){
	            var dateToFormat = moment(input, 'MM/YYYY');
	            var formattedDate =  moment(dateToFormat).format('MM/YY');
	            return formattedDate;
	        }
	        else{
	            return "";
	        }
	    };
	});

	filters.filter('checkForEmptyString', function() {
	    return function(input) {
	        if(input){
	            return input;
	        }
	        else{
	            return "N/A";
	        }
	    };
	});


	filters.filter('truncateString', function() {
	    return function(value) {
	        if(value!=null && value.length>12 ){
	            return [value.substring(0,12),"..."].join("");
	        }
	        else{
	            return value;
	        }
	    };
	});

	filters.filter('reFormatToRupee', function() {
	    return function(input) {
	        if(input){
	            return "RS "+input+"/-";
	        }
	        else{
	            return "RS 0/-";
	        }
	    };
	});
	filters.filter('uniqueFilter',function(){
        return function(input,ppt){
            
        var arr=input;
        
        var el=[];
        var i=0,j=0;
        if(arr!=null||arr!=undefined){
            
   
        for(i=0;i<arr.length;i++){
            var arr1=arr[i][ppt];
            if(arr1){
            if(i==0&&arr1!="NA"&&arr1!=""){
                      el.push(arr[i][ppt]);
            }
            else{
                      for(j=0;j<el.length;j++){
                                if(el.indexOf(arr[i][ppt]) > -1){
                                }    
                                else{
                                    if(arr1!="NA"&&arr1!=""){
                                         el.push(arr[i][ppt]);
                                    }
                                    
                                }
                      }
            }
            }
        }
        }
        return el;
        }
        });
   

	
	filters.filter('roundOff',function(){
		return function (input){
			
			return Math.round(input*100)/100;
			
		}
	});
	filters.filter('removespace',function(){
		return function (input){
			
			return input.replace(/ /g,'');
			
		}
	});



	return filters;
});