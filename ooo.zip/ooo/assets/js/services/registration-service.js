/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("registrationUserService",['$q','$http','ajaxService', 'stateService', 'utilityService','urlService', 'loginService',function($q,$http,ajaxService, stateService, utilityService,urlService, loginService){
		return	{
			  registrationUser: function (registrationUser) {
		            var url = urlService.registrationUserUrl();
		            return ajaxService.doPost(url, {},registrationUser);
		        },
		        expandOrCollapseAccordion: function (accordionStatus) {

		            //  Update each accordion header using the header's status and HTML id
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.registrationDetailsAccordionStatus, "registrationDetailsAccordionBodyId");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.documentUploadAccordionStatus, "documentUploadAccordionBodyId");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.otpVerificationAccordionStatus, "otpVerificationAccordionBodyId");
		            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.manualVerificationAccordionStatus, "manualVerificationAccordionBodyId");

		        },
		        callManualVerificalUser:function(registrationUser){
		        	 var url = urlService.manualVerificalUserUrl();
		             return ajaxService.doPost(url, {},registrationUser);
		        },
		        callValidLoginName:function(request){
		       	 var url = urlService.callValidLoginNameUrl();
		         return ajaxService.doGet(url, request);
		         },	
		        callValidEmail:function(request){
		       	 var url = urlService.callValidEmailUrl();
		         return ajaxService.doGet(url, request);
		         },
		        callValidMobileNumber:function(request){
		       	 var url = urlService.callValidMobileNumberUrl();
		         return ajaxService.doGet(url, request);
		        },
		        callAllDocumentServices:function(documentList){
		        	var promises = [];

		            for(var i = 0 ; i < documentList.length ; i++){

		                promises.push(this.callDocumentUploadForRegistedUser(documentList[i]));
		            }
		            $q.all(promises);
		        },
		        callDocumentUploadForRegistedUser: function (document) {
		        	  var deferred = $q.defer();
		            var url = urlService.documentUploadForRegistedUserUrl();
		            $http.post(url,document,{
		            	 transformRequest: angular.identity,
		            	 headers: {'Content-Type': undefined,'origoToken': loginService.getUserInfo().origoToken}
		            }).success(function (data, status, headers, config) {
		   			
				            deferred.resolve(data);
				        
		       
		     })  .error(function(){
		     });
		            console.log(deferred.promise);
		            return deferred.promise;
		          
		        },
					callGenerateOTPForRegistedUser: function (loginName) {
		            var url = urlService.generateOTPUrl();
		            return ajaxService.doGet(url, loginName);
		        },
		        continueHandler: function (request) {
		            var url = urlService.continueHandlerUrl();
		            return ajaxService.doGet(url, request);
		        },
		        validateOtp:function(request){
		        	var url = urlService.validateOtpUrl();
		            return ajaxService.doGet(url, loginName);
		        },
		        secureUserLogin:function(secureUser){
		        	  var url = urlService.secureUserLoginUrl();
		              return ajaxService.doPost(url, {},secureUser);
		        },
		        documentUploadForRegistedUser:function(userDocument){
		    	 var url = urlService.getSecurePath() + urlService.documentUploadForRegistedUserUrl();
		         return ajaxService.doPost(url, {},userDocument);
		    },
		    defaultSettings:function(vm){
		    	vm.accordionStatus =vm.accordionStatus||{};
		    	angular.extend(vm.accordionStatus,{
		    		registrationDetailsAccordionStatus:constants.ACCORDION_CURRENT,
		    		documentUploadAccordionStatus:constants.ACCORDION_NOTSTARTED,
		    		otpVerificationAccordionStatus:constants.ACCORDION_NOTSTARTED,
		    		manualVerificationAccordionStatus:constants.ACCORDION_NOTSTARTED
		    		});
		        this.setSetting(vm,false,true,true,true,"registrationDetails",false,false,false,false);
		     },
		     setSetting:function(vm,registrationDetailsNotStarted,registrationDocumentUploadNotStarted,registrationOTPVerificationNotStarted,registrationManualVerificationNotStarted,active,registrationDetailsCompleted,registrationDocumentUploadCompleted,registrationOTPVerificationCompleted,registrationManualVerificationCompleted){
		         this.expandOrCollapseAccordion(vm.accordionStatus);

		    	 angular.extend(vm,{
		     		registrationDetailsNotStarted:registrationDetailsNotStarted,
		     		registrationDocumentUploadNotStarted:registrationDocumentUploadNotStarted,
		     		registrationOTPVerificationNotStarted:registrationOTPVerificationNotStarted,
		     		registrationManualVerificationNotStarted:registrationManualVerificationNotStarted,
		     		tabs:{active:active},
		     		registrationDetailsCompleted:registrationDetailsCompleted,
		     		registrationDocumentUploadCompleted:registrationDocumentUploadCompleted,
		     		registrationOTPVerificationCompleted:registrationOTPVerificationCompleted,
		     		registrationManualVerificationCompleted:registrationManualVerificationCompleted
		     	});
		     },
		     nextUploadDocumentSetting:function(vm){
		    	 vm.accordionStatus= vm.accordionStatus||{};
		    	 vm.accordionStatus.documentUploadAccordionStatus=constants.ACCORDION_CURRENT;
		    	 vm.accordionStatus.registrationDetailsAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 this.setSetting(vm,false,false,true,true,"registrationDocumentUpload",true,false,false,false);
		     },
		     nextOTPNumberSetting:function(vm){
		    	 vm.accordionStatus= vm.accordionStatus||{};
		vm.otpGenereated=false;
		    	 vm.accordionStatus.documentUploadAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 vm.accordionStatus.registrationDetailsAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 vm.accordionStatus.otpVerificationAccordionStatus=constants.ACCORDION_CURRENT;
		    	 this.setSetting(vm,false,false,false,true,"registrationOTPVerification",true,true,false,false);
		     },
		     nextOTPSubmitSetting:function(vm){
		    	 vm.accordionStatus= vm.accordionStatus||{};
		    	 vm.accordionStatus.documentUploadAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 vm.accordionStatus.registrationDetailsAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 vm.accordionStatus.otpVerificationAccordionStatus=constants.ACCORDION_SUCCESS;
		    	 vm.accordionStatus.manualVerificationAccordionStatus=constants.ACCORDION_CURRENT;

		    	 
		    	 this.setSetting(vm,false,false,false,false,"registrationManualVerification",true,true,true,false);
		     },
		     getRegistrationFlow:function(vm,progress){
		    	 if(progress===constants.REGISTRATION){
		    		 vm.farmer=constants.YES;
		    		 this.nextUploadDocumentSetting(vm);
		    	 }else if(progress===constants.DOCUMENT_UPLOAD){
		    		 this.nextOTPNumberSetting(vm);
		    	 }else if(progress===constants.OTP_VERIFICATION){
		    		 this.nextOTPSubmitSetting(vm);
		    	 }else if(progress===constants.MANUAL_VERIFICATION){
		    		 
		    	 }
		     },
		        getStatesDetails:function(request){
		        	console.log("ajax getstate details");
		        //	var deferred = $q.defer();
		                var url = urlService.getStateDetailsUrl();
		                var searchDetailsResponse = ajaxService.doGet(url, request);
		              
		            return searchDetailsResponse; 
		        },
		        getAddressDetails:function(request){
		        	var deferred = $q.defer();
		            var url = urlService.getAddressDetailsUrl();
		            var searchDetailsResponse = ajaxService.doGet(url, request);
		          searchDetailsResponse.then(function (result) {
		                
		                deferred.resolve(result);
		            },
		            function (errorResult) {
		               deferred.reject(errorResult);
		            });
		        

		        return deferred.promise;
		        	
		        },
		        getCityDetails:function(request){
		        	var deferred = $q.defer();
		                var url = urlService.getCityDetailsUrl();

		                var searchDetailsResponse = ajaxService.doGet(url, request);

		               searchDetailsResponse.then(function (result) {
		                
		                    stateService.set(constants.CITY_DETAILS, result);
		                    deferred.resolve(result);
		                },
		                function (errorResult) {
		                   deferred.reject(errorResult);
		                });
		            

		            return deferred.promise;
		        }
		};
	}]);
    
	return services;
});