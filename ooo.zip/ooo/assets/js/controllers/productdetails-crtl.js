'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("productDetailCtrl", ['$rootScope','$scope','$state','utilityService','setupAllSearchService','stateService','productDetailService','myCartService','$stateParams','userWishlistService', 'loginService','$sessionStorage','$filter','$translate','$timeout', function($rootScope,$scope,$state, utilityService,setupAllSearchService,stateService,productDetailService,myCartService,$stateParams,userWishlistService, loginService,$sessionStorage,$filter,$translate,$timeout) {

		var vm = this;
		vm.userInfo = loginService.getUserInfo();
		//$scope.loading=true;
		vm.isMaxQty = false;
		vm.onQtyKeyPress= onQtyKeyPress;
		vm.productImageChange = changeProductDisplayImage;
		vm.isNotFarmer=false;
		vm.isQtyGreater = false;
		vm.checkAvailability=checkAvailability;
		vm.smallImageHandler=smallImageHandler;
		vm.addToCart =addToCart;
		vm.onStoreChange=onStoreChange;
		vm.buynowHandler=buynowHandler;
		vm.getProductDetails = getProductDetails;
		vm.checkAvailabilityOnProductChange =checkAvailabilityOnProductChange;
		vm.productDtlsResp=productDtlsResp;		
		vm.onRadioSIChange=onRadioSIChange;
		vm.onSkuChange=onSkuChange;
		vm.prodQtyUpdate=prodQtyUpdate;
		vm.productshow=false;
		vm.getCart=getCart;
		vm.quantityChange=quantityChange;
		vm.add="add";
		$sessionStorage["isShipping"]=true;
		$sessionStorage["isIPickup"]=false;
		vm.wishlistdisable=false;
		vm.prodAddedToWl=false;
		vm.displayDiscount = true;
		vm.onkeyPress=onkeyPress;
		vm.quantity_req=1;
		vm.prd_equip_type = constants.PRD_ROOT_TYPE_EQUIP;
		vm.errorResProductDetails = false;
		vm.errorAddToCart = false;
		vm.goToAdvanceSearch = goToAdvanceSearch;
		vm.goToSebCategoryViewAll = goToSebCategoryViewAll;
		var userName= vm.userInfo.userName, 
		fromWhere = productDetailService.getfromWhere();
		init();
		vm.goToHomePage=function(){
			$state.go('start');
		}
		vm.goToFarmInputs=function(){
			$state.go('advancedsearchdetails',{"srchtxt":'',"type":'Farm Input',"catlevel":false},{reload:true});
		}
		

		function onQtyKeyPress(event){
			  var key = event.keyCode;
			  if(key < 48 || key > 57)
				  {
				  	event.preventDefault();
				  }
			  return false;
		}
		
		function quantityChange(){
			var storeQuantity= vm.storeSelected.quantity;
			vm.buynowbtn = vm.addtocardttbn=false;
			vm.isMaxQty=vm.isQtyGreater=false;
			
			if(vm.quantity_req>storeQuantity)
				{
					vm.isQtyGreater=true;
					vm.buynowbtn = vm.addtocardttbn=true;
				}
			else if(vm.productDetails.maxPurchasableQty!=null)
				{
					if(vm.quantity_req>parseInt(vm.productDetails.maxPurchasableQty))
					{
						vm.isMaxQty=true;
						vm.buynowbtn = vm.addtocardttbn=true;
					}
				}
			}
				
		function setDefaultValues(){
			vm.shippingIpickup="shipping";
			productDetailService.isShipping=true;
			vm.notAvailable_pin=false;
			vm.quantityMinus = false;
			vm.quantityAdd = false;
			vm.isShipping=true;
			vm.isIpickUp=false;
			vm.buynowbtn=vm.addtocardttbn=true;	
			vm.quantity_req=1;
			vm.user_pincode=null;
			vm.userPincode = false;
		}
		function productExistForUser(){
			if(utilityService.isCheckEmptyArray(vm.userInfo.productsIDS) && vm.userInfo.productsIDS.indexOf(vm.productId)>=0){
				vm.productAlreadyExist=true;
              }else{
            	  vm.productAlreadyExist=false;
              }
		}
		function onkeyPress($event){
	    	if ($event.which === 13){
	    		checkAvailability();
	    	}
	    	  
	    	}
		function disableBtn(){
				var cartDetails = vm.userInfo.productsIDS;
				vm.isQtyGreater=false;
				if(vm.stores.length>0 && vm.quantity_req<=stateService.get(constants.MY_CART_QUANTITY)){
					if(vm.quantity_req<=stateService.get(constants.MY_CART_QUANTITY))
						{
							angular.element('#qty_drop').removeAttr("disabled");
						}
					vm.addtocardttbn= (utilityService.isCheckEmptyArray(cartDetails)  && (vm.userInfo.productsIDS.indexOf(vm.currentProduct)>=0));
					vm.buynowbtn=!(utilityService.isEmptyObject(vm.userInfo.progress) && utilityService.isEmptyObject(vm.userInfo.status) && vm.userInfo.progress===constants.MANUAL_VERIFICATION && vm.userInfo.status===constants.ACTIVE);
				}
				else{
					 vm.buynowbtn= vm.addtocardttbn =true;
					 if(vm.stores.length==0)
						 {
						 	angular.element('#qty_drop').attr("disabled", true);
						 }
					 else
						 {
						 	angular.element('#qty_drop').removeAttr("disabled");;
						 }
					 vm.isQtyGreater=false;
					 if(vm.stores.length!=0)
						{
						   vm.isQtyGreater=true;
						}
					
				}
		}
		
		function checkIfUserIsFarmer()
		{
			var loginDetails=vm.userInfo;
			if(utilityService.isEmptyObject(loginDetails)){
				if(vm.userInfo.farmer=="N"||vm.userInfo.farmer==="n")
					{
						vm.isNotFarmer = true;
					}
				else
					{
						vm.isNotfarmer = false;
					}
			}
		}
		
		function init(){
			setDefaultValues();
			//check is user is farmer
			checkIfUserIsFarmer();
			//from my cart
			vm.productId = $stateParams.id;
			if(utilityService.isEmptyObject(userName)){
				setPincode();
				if(fromWhere==="advanceaddtocart"||fromWhere==="homepageaddtocart"){
					vm.currentProduct=vm.productId;
				 }else if(fromWhere==="mycart"){
				 	vm.quantity_req=myCartService.getCartQuantity().toString();
				 	vm.currentProduct=myCartService.getCartProductId();
				 }
			 }
			getProductDetails();
			getBestSellingProducts();
			if($sessionStorage['userInfo']){
				checkIfProductAddedToWL();
			}
			
	  }
		function bestSellingCarousalControl(){
	    	
    	    // init carousel
    	    $('.carousel').carousel({
    	        pause: true,        // init without autoplay (optional)
    	        interval: false,    // do not autoplay after sliding (optional)
    	        wrap:false          // do not loop
    	    });
    	    // init carousels with hidden left control:
    	    $('.carousel').children('.left.carousel-control').hide();
    	

    	// execute function after sliding:
    	$('.carousel').on('slid.bs.carousel', function () {
    	    // This variable contains all kinds of data and methods related to the carousel
    	    var carouselData = $(this).data('bs.carousel');
    	    // get current index of active element
    	    var currentIndex = carouselData.getItemIndex(carouselData.$element.find('.item.active'));

    	    // hide carousel controls at begin and end of slides
    	    $(this).children('.carousel-control').show();
    	    if(currentIndex == 0){
    	        $(this).children('.left.carousel-control').hide();
    	    }else if(currentIndex+1 == carouselData.$items.length){
    	        $(this).children('.right.carousel-control').hide();
    	    }
    	});
    }
		
			function checkIfProductAddedToWL(){
				//get all wl items
				var wlDetails={loginName:userName};
				
				getProdsOfWLRequest(wlDetails).then(getProdsOfWLResponse);
				
			  
		  }
			
			function getProdsOfWLRequest(wlDetails){
				return userWishlistService.getProductsOfWL(wlDetails);
			}
			function getProdsOfWLResponse(response){
				var res=response.body;
				vm.userWLItems;
				if(res.applicationStatusCode==1043){
					vm.userWLItems=res.data;
					if(utilityService.isCheckEmptyArray(vm.userWLItems) && vm.userWLItems.length>=0){	
						for(var prod_count=0;prod_count<vm.userWLItems.length;prod_count++){
							if(vm.userWLItems[prod_count].productId===vm.productId){
								vm.add="added";
								vm.wishlistdisable=true;
							//	angular.element("#wishlistBtn").text("Added to Wishlist");
								//angular.element("#wishlistBtn").disabled=true;
								//break;
							}
						}
						}
				}
				
			}
		function prodQtyUpdate(type){
			if(type==="add"){
				if(vm.storeSelected!=null){
					if(parseInt(vm.storeSelected.quantity,10)===parseInt(vm.quantity_req,10)){
						vm.quantityAdd = false;
					}else{
						var quantity=parseInt(vm.quantity_req,10)+1;
						if(parseInt(vm.storeSelected.quantity,10)===parseInt(quantity,10)){
							vm.quantityAdd =false;
						}else{
							vm.quantityAdd = true;	
						}
						vm.quantityMinus= true;
						vm.quantity_req = quantity;
						
					}
				}
				
				
			}else{
				if(!(vm.quantity_req===1)){
					var quantity=parseInt(vm.quantity_req,10)-1;
					if(quantity===1){
						vm.quantityMinus =false;
					}else{
						vm.quantityMinus =	true;
					}
					vm.quantity_req =quantity;
					vm.quantityAdd = true;
				}else{
					vm.quantityMinus = false;
				}
				
			}
			
		}
		function onSkuChange(){
			var prodLen=vm.originalProdDetails.length;
			for(var prod=0;prod<prodLen;prod++){
				if(vm.originalProdDetails[prod].productId===vm.skuSelected){
					vm.productDetails=vm.originalProdDetails[prod];
					vm.productId=vm.skuSelected;
					vm.imageDisplayPath = vm.productDetails.productImgPath;
					vm.maxQuantityPurchase = vm.productDetails.maxPurchasableQty;
				}
				vm.quantity_req=(1).toString();
			}
			vm.currentProduct=vm.productId;
			vm.displayDiscount = true;
			
			vm.discountedProductPrice = parseInt(vm.productDetails.vendorDiscount)+parseInt(vm.productDetails.origoDiscount);
			if(vm.discountedProductPrice == 0){
				vm.displayDiscount = false;
			}
			$stateParams.id = vm.productId;
			checkAvailability();
			getBestSellingProducts();
		}
		
		function onRadioSIChange(change){
			productDetailService.isShipping=vm.isShipping= $sessionStorage["isShipping"]=(change==="shipping");
			productDetailService.isIpickUp=vm.isIpickUp=$sessionStorage["isIPickup"] = (change==="ipickup");
		}
		function buynowHandler(productDetails){
			var userName= vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
			//stateService.set(constants.STATE_USER_ACTION,constants.BUYNOW_ACTION);
			$sessionStorage[constants.STATE_USER_ACTION] = constants.BUYNOW_ACTION;
			productDetailService.productDetails = $sessionStorage["pd_productDetails"] = productDetails;
			productDetailService.quantity = $sessionStorage["pd_quantity"] = vm.quantity_req;
			productDetailService.storeSelected = $sessionStorage["pd_storeSelected"] = vm.storeSelected;
			myCartService.isShipping=vm.isShipping;
			myCartService.isIpickUp=vm.isIpickUp;
			vm.cartDetails=[vm.productDetails];
			myCartService.cartDetails = $sessionStorage["cartDetails"] = vm.cartDetails;
			$sessionStorage["isBoth"] = false;
			$sessionStorage["storeSelected"] =vm.storeSelected;
			if(utilityService.isCheckEmpty(userName)){
				
				$state.go('login');
			}else{
				vm.cartDetails=[vm.productDetails];
				myCartService.cartDetails=vm.cartDetails;
	        	$state.go('placeorder');
			}
			
        }
		function onStoreChange(store){
			vm.storeSelected=store;
		}
	  
		function getProductDetails(){
		//	vm.quantity_req=setupAllSearchService.quantity||1;
		
			var prodDetails=angular.extend({},{
	       		id:vm.productId
	       	});
			$rootScope.dataLoading = true;
			$rootScope.dataStillLoading = true;
			getProductDetailsById(prodDetails).then(processProductDetails);
		}
		function getProductDetailsById(request){
			return setupAllSearchService.getProductDetails(request);
		}
		function processProductDetails(response){
			//$scope.loading=false;
			$rootScope.dataLoading = false;
			$rootScope.dataStillLoading = false;
			vm.productshow=true;
			var body=response.body;
			if(body.applicationStatusCode===1032)
				{
					vm.breadcrumbs = body.data[1];
					var	productDetails=body.data[0],
					sku=[],
					len=productDetails.length;
					vm.originalProdDetails=productDetails;
					productExistForUser();
					for(var i=0;i<len;i++){
						productDetails[i].productImgPath=connection.store+"images/"+productDetails[i].productImgPath;
						var imageList = productDetails[i].images;
						for(var img=0,_length=imageList.length;img<_length;img++){
							imageList[img].imgPath = connection.store+"images/"+imageList[img].imgPath;
						}
						var _sku=[productDetails[i].unitSize,productDetails[i].sku].join(" ");
						sku.push(angular.extend({},
						{
							sku:_sku,
							productId:productDetails[i].productId
						}));
						if(productDetails[i].productId=== vm.productId){
							vm.productDetails=productDetails[i];
							/*vm.productDetails.images.forEach(function(value,index){
							vm.productDetails.images[index].imgPath = connection.store+ vm.productDetails.images[index].imgPath;
							})*/
							vm.imageDisplayPath = vm.productDetails.productImgPath;
							vm.maxQuantityPurchase = vm.productDetails.maxPurchasableQty;
						}
					}
					vm.sku=sku;
					vm.recomendedProducts=body.data[1];
					vm.skuSelected = vm.productDetails.productId;
					vm.discountedProductPrice = parseInt(vm.productDetails.vendorDiscount)+parseInt(vm.productDetails.origoDiscount);
					if(vm.discountedProductPrice == 0){
					vm.displayDiscount = false;
					}
					if(utilityService.isEmptyObject(userName)){
	            	   checkAvailability();
					}
				}
			else 
				{
					vm.errorResProductDetails=true;
				}
		}
	
	   function smallImageHandler(){
		   vm.smallImage =!vm.smallImage;
	   }
	   
	   function productDtlsResp(prodId){
		   vm.productId=prodId;
		   //getProductDetails();
		   //vm.recomendedProducts = setupAllSearchService.recommendedProductDetails;
		   $state.go('productdetails',{"id":vm.productId},{reload:true});
	   }
		function addToCart(){
			if(utilityService.isCheckEmpty(vm.user_pincode)){
				 vm.emptyPincode=true;
				return true;
			}else{
				vm.emptyPincode=false;
			}
			  stateService.set(constants.STATE_USER_ACTION,constants.ADDTO_CART);
			var userName= vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
			
			
			if(userName===null||userName===undefined ||userName===""){
					$state.go('login');
			}else{
				var request={
						loginName:vm.userName,
						product:{
							productId:vm.productId,
							productQuantity:+vm.quantity_req,
							storeId: vm.storeSelected!=null?+vm.storeSelected.storeId:null,
							pinCode:vm.user_pincode!=null?+vm.user_pincode:null,//TODO pincode from user system when not logged in
							distanceFromStore:vm.storeSelected!=null?vm.storeSelected.distance:null,
							deliveryModeDTO:{
										isShippingAddress:vm.isShipping,
										isIpickUp:vm.isIpickUp||false,
										shipAddressId:vm.isShipping?vm.userInfo.shippingAddress.shipId:null
									}
						}
						
				};
				setupAllSearchService.addToCartRequest=request;
				//vm.productDetails=setupAllSearchService.addToCartRequest;
	      		 angular.extend(setupAllSearchService.addToCartRequest,{
	      			 loginName: vm.userInfo.userName //stateService.get(constants.STATE_USER_NAME)
	      			 });
	      		$rootScope.dataLoading = true;
	      		 callProductDetailsToCart(setupAllSearchService.addToCartRequest).then(processAddCartDetailsResponse);
				
			}
			}
		function getCart(){
			$state.go('myCart');
		}
		function callProductDetailsToCart(request){
			return myCartService.addProductDetailsToCart(request);
		}  
		function setCartCounter(){
        	var prdLen = vm.userInfo.productsIDS||[];
			   
			   vm.userInfo.productsIDS.push(vm.productDetails.productId);
			   angular.element('#cartcounterlist').text(vm.userInfo.productsIDS.length);
			   vm.userInfo.pincode=+vm.user_pincode;
     }
		
	function setPincode(){
		 
		
		if(vm.userInfo.pincode!=null)
		 {
			if(parseInt(vm.userInfo.pincode)>0)
			{
				vm.user_pincode = vm.userInfo.pincode;
				vm.userPincode = true;
			}
		 }
			else{
				var shippingDetails= vm.userInfo.shippingAddress; //stateService.get(constants.USER_SHIPPING_ADDRESS);
				if(utilityService.isEmptyObject(shippingDetails)){
					 vm.user_pincode=shippingDetails.pinCode;
					 vm.userPincode=false;
				 }
			}
	}
		
		function processAddCartDetailsResponse(response){
			//if statusCode is 1000, increment products_cart by 1.
			
			//check with status code of pin availability
    		var body=response.body;
    		$rootScope.dataLoading = false;
			if(body.applicationStatusCode===1014){
				vm.mycartdetailresponse=true;
				  vm.addedtocard=true;
	          	  //vm.showcartafteradded=true;
				  vm.user_pincode = vm.storeSelected!=null?+vm.storeSelected.pinCode:null;
				  setCartCounter();
				  setPincode();
				  vm.addtocardttbn=true;
				  $('body').scrollTop(0);
			}else if(body.applicationStatusCode===2029){
				var  errorCodes= body.errorCodes;
				var flag = false;
				for(var i=0,len=errorCodes.length;i<len;i++){
					 if(errorCodes[i].errcode===2041){
						vm.productAlreadyExist=true;
						flag=true;
						break;
					}
				}
				if(!flag)
				vm.errorAddToCart = true;
			}
			vm.showcartbtn=true;
			vm.showcartafteradded=false;
		}
		function checkAvailabilityOnProductChange(){
			checkAvailability();
		}
		
		function checkAvailability(){
			//to check product availability at PINCODE
			//send vm.user_pincode
			vm.stores=[];
		  if(utilityService.isCheckEmpty(vm.user_pincode) || vm.user_pincode.length>6){
			  vm.emptyPincode=true;
			  return false;
		  }else{
			  vm.emptyPincode=false;
		  }
		  if(utilityService.isCheckEmpty(vm.quantity_req)){
			  vm.emptyQuantity=true;
		  }else{
			  vm.emptyQuantity=false;
		  }
		  
			var request= angular.extend({},{
				   pin:+vm.user_pincode,
				   productid:vm.productDetails.productId
			});
			vm.displayLoader = true;
			callCheckPinCodeAvail(request).then(processCheckAvailResponse);
		}
		
		function callCheckPinCodeAvail(request){
			return productDetailService.callCheckPinCodeAvail(request);
		}
		vm.checkPinCodeStart=function(){
			var pin=vm.user_pincode;
			if(pin.charAt(0)=="0"){
				
				vm.cartPinValid=true;
			}else{
				
				vm.cartPinValid=false;
			}
		}
		function processCheckAvailResponse(response){
			//set vm.notAvailable_pin=true if the output contains 
			//store_name, distance and timings
			//vm.defaultStoreId  moment("22:15:00", ["hh:mm:ss"]).format("HH:mm A")
			//check with status code of pin availability
			$scope.loading=false;
			productExistForUser();
			if(response.body.applicationStatusCode===1008){
				var body= response.body;
				vm.displayLoader = false;
				if(utilityService.isCheckEmpty(body.data)){
					vm.storeNotAvail= true;
					vm.quantityAdd = vm.quantityMinus=false;
					vm.outOfStock = true;
				}else{
					vm.storeNotAvail= false;
					vm.stores=response.body.data[0];
					
					/*for(var i=0,len=vm.stores.length;i<len;i++){
						vm.stores[i].timings= moment(vm.stores[i].storeWdOpenTime, ["hh:mm:ss"]).format("h:mm A") +" to "+ moment(vm.stores[i].storeWdCloseTime, ["hh:mm:ss"]).format("h:mm A");
					}*/
					vm.store_choosen =vm.stores[0].storeName;
					vm.defaultStoreId=vm.stores[0].storeId;
					vm.storeSelected=vm.stores[0];
					if(vm.stores[0].quantity>0){
						vm.outOfStock = false;
						vm.quantityAdd = true;
					}else{
						vm.outOfStock = true;
					}
					
					stateService.set(constants.USER_STORE_LOCATORS,vm.stores);
					stateService.set(constants.MY_CART_QUANTITY,vm.stores[0].quantity);
					//vm.expectedDelivertyDate=moment().add(7, 'days').format("Do MMMM, dddd");
					
				}
				disableBtn();
				
			}
			
		
			
		}
		vm.addToWishlistHandler=function(product){
			stateService.set(constants.STATE_USER_ACTION,constants.ADDTO_WISHLIST);
			var userName= vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
			//if equal to undefined-take to login
			if(userName===null||userName===undefined ||userName===""){
			
				//productDetailService.saveProductToAddToWlOnLogin(product);
				
				productDetailService.navigateOnLoginToWIshlist($stateParams.id);
				//stateService.set(constants.ADDTO_WISHLIST,"AddToWishlist");
				//stateService.set(constants.STATE_USER_ACTION,constants.SUBMIT_DEMAND);
				$state.go('login');
				
			}else{
				
				var prodDetails=angular.extend({},{
					loginname:userName,
		       		productName:product.productName,
		       		pincode:vm.user_pincode,
		       		quantity:vm.quantity_req,
		       		demand:false,
		       		productId:product.productId
		       	});
				callAddToWishlist(prodDetails).then(callAddToWishlistResponse);
				
			}  
		}
		function callAddToWishlist(prodDetails){
			return productDetailService.addToWishList(prodDetails);
		}
		function callAddToWishlistResponse(response){
			var res=response.body;
			if(res.applicationStatusCode==1029){
				vm.add="added";
				vm.addedToWL=true;
				vm.wishlistdisable=true;
				$('body').scrollTop(0);
			}
		}
		vm.getWishlist=function(){
			$state.go('wishlist');
		}
		
		function getBestSellingProducts(){
			//vm.quantity_req=setupAllSearchService.quantity||1;
			var prodDetails = angular.extend({},{
					id:vm.productId
		    });
			getBestSellingProductsById(prodDetails).then(processBestSellingProductsDetails);
		}
		
		function getBestSellingProductsById(request){
			return setupAllSearchService.getBestSellingProducts(request);
		}
		
		function processBestSellingProductsDetails(response){
			var res=response.body;
			vm.bestSellingShow = true;
			if(res.applicationStatusCode == 1053){
				vm.bestSellingProductsShow = true;
				vm.bestSellingProducts = res.data[0];
				for(var sell=0,sellLeng=vm.bestSellingProducts.length;sell<sellLeng;sell++){
					vm.bestSellingProducts[sell].productImgPath=connection.store+"images/"+vm.bestSellingProducts[sell].productImgPath;
				}
				
				//For bestSellingProducts Slider
				vm.bestSellingInitial=[];
		    	vm.bestSellingMiddle=[];
		    	/*vm.bestSellingLast=[];*/
		    	for(var i=0,len=vm.bestSellingProducts.length;i<len;i++){
		    		if(i<6){
		    			vm.bestSellingInitial.push(vm.bestSellingProducts[i]);
		    		}else if(i<12){
		    			vm.bestSellingMiddle.push(vm.bestSellingProducts[i]);
		    		}/*else if(i<18){
		    			vm.bestSellingLast.push(vm.bestSellingProducts[i]);
		    		}*/
		    	}
		    	
		    } else {
				vm.bestSellingProducts={};
				if(Object.keys(vm.bestSellingProducts).length == 0){
					vm.bestSellingShow = false;
				}
				console.log('error fetching best selling products...') //TODO: Saloni
			}
			
			$timeout(bestSellingCarousalControl,10);
			$scope.$watch(vm.bestSellingProducts, $scope.updateBestSellingCarousel, true);
		}
		$scope.updateBestSellingCarousel = function() {
	    	var _carouselBestSellingContainer = $('.carousel-inner.carousel-bestsellinglist');
	    	if (_carouselBestSellingContainer.children('.item').length < 2){
	    		_carouselBestSellingContainer.siblings('.carousel-control, .carousel-indicators').hide();
	    	} else {
	    		_carouselBestSellingContainer.siblings('.carousel-control, .carousel-indicators').show();
	    	}
		    $('.carousel').children('.left.carousel-control').hide();
	    }
		function changeProductDisplayImage(displayImgPath){
			vm.imageDisplayPath = displayImgPath;
		}
		function goToAdvanceSearch(){
			 $state.go('advancedsearchdetails', {
	                "srchtxt": "",
	                "type": vm.breadcrumbs[1],
	                "brands": null,
	                "grades": null,
	                "prices": null,
	                "catlevel": false
	            }, {
	                reload: true
	            });
			
		}
		function goToSebCategoryViewAll(){
			$state.go('advancedsearchviewall', {
                "srchtxt": "",
                "type": vm.breadcrumbs[1],
                "level": vm.breadcrumbs[2],
                
            });
		}
		
}]);
});