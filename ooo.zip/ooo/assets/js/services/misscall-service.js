/**/
define(['angular', 'services-module','underscore'],function(angular,services,underscore){
	services.factory("missCallService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService',function($q, ajaxService, stateService, utilityService,urlService){
		return{
			sendCallDetails:function(callDetails){
				var url = urlService.getCallUrl();
				 return ajaxService.doPost(url, {},callDetails);
				
			}
		};
	}]);
	return services;
});