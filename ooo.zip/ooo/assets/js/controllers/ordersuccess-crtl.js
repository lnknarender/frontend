'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("orderSuccessCtrl", ['$state','utilityService','setupAllSearchService','myCartService','stateService','$timeout','loginService', '$sessionStorage', function($state, utilityService,setupAllSearchService,myCartService,stateService,$timeout,loginService, $sessionStorage) {
	
	 var vm = this,cartCount=angular.element('#cartcounterlist'),_count=angular.element('#cartcounterlist').val();
	 stateService.get(constants.STATE_USER_ACTION)===constants.BUYNOW_ACTION?cartCount.text(_count-1):cartCount.text(0);
	 vm.userInfo = loginService.getUserInfo();
     vm.parmentAdddress = vm.userInfo.parmentAdddress;

}]);
});
