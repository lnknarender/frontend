/*global define */
define(['angular', 'directives-module','bootstrap'], function(angular, directives,bootstrap) {
	'use strict';

    /* Directives  */

	directives.directive('autocomplete', ['autocomplete-keys', '$rootScope','$window', '$timeout','setupAllSearchService','$state', function(Keys, $rootScope, $window, $timeout,setupAllSearchService,$state) {
		return {
			template: '<input type="text" id="srchtxt" class="autocomplete-input" placeholder="{{placeHolder}}"' +
							'ng-class="inputClass"' +
							'ng-model="searchTerm"' +
							'ng-keydown="keyDown($event)"' +
							'ng-blur="onBlur()" />' +

						'<div class="autocomplete-options-container">' +
							'<div class="autocomplete-options-dropdown" ng-if="showOptions">' +
								'<div class="autocomplete-option" ng-if="!hasMatches">' +
									'<span>No matches found</span>' +
								'</div>' +

								'<ul class="autocomplete-options-list" ng-if="hasMatches"><li class="noWords" data-ng-if="matchingOptionsData.length === 0"><span class="lookingFor">Are you looking for...</span></li>' +
									'<li class="autocomplete-option" ng-class="{selected: isOptionSelected(option)}" ' +
										'ng-style="{width: optionWidth}"' +
										'ng-repeat="option in matchingOptions"' +
										'ng-mouseenter="onOptionHover(option)"' +
										'ng-mousedown="selectOption(option)"' +
										'ng-if="!noMatches">' +
										'<span>{{option[displayProperty]}}</span>' +
									'</li>' +
								'</ul>' +
							'</div>' +
						'</div>',
			restrict: 'E',
			scope: {
				options: '=',
				//onSelect: '=',
				displayProperty: '@',
				inputClass: '@',
				clearInput: '@',
				placeHolder: '@'
			},
			controller: function($scope){
				$scope.searchTerm = '';
				$scope.highlightedOption = null;
				$scope.showOptions = false;
				$scope.matchingOptions = [];
				$scope.hasMatches = false;
				$scope.selectedOption = null;

				$scope.isOptionSelected = function(option) {
					return option === $scope.highlightedOption;
				};
				function callAutoCompleteDetails(term){
				return	setupAllSearchService.getAutoCompleteDetails(term);
				}
				function processAutoCompleteResponse(response){
					var tmpArr = [];
					angular.forEach(response, function(value, key) {
						angular.forEach(response[key], function(v, k) {
							tmpArr.push(response[key][k]);
						});
					});
					
					var tmp = [];
					for(var i = 0; i < tmpArr.length; i++){
						if(tmp.indexOf(tmpArr[i]) == -1){
							tmp.push(tmpArr[i]);
				        }
				    }
				    console.log(tmp);
					var autosuggest = new Array();
					/*angular.forEach(response, function(value, key) {
						angular.forEach(response[key], function(v, k) {
							autosuggest.push({'title': response[key][k]});
						});
					});*/
					angular.forEach(tmp, function(value, key) {
						autosuggest.push({'title': tmp[key]});
					});
					
					$scope.options =autosuggest;
					console.log($scope.options);
					$scope.matchingOptionsData = $scope.findMatchingOptions(setupAllSearchService.term);
					/*if(matchingOptionsData.length === 0){
						$( ".noWords" ).append( "<span class='lookingFor'>Are you looking for...</span>" );
					}*/
					var matchingOptions = $scope.options;
					$scope.matchingOptions = matchingOptions;
					if (!$scope.matchingOptions.indexOf($scope.highlightedOption) != -1) {
						$scope.clearHighlight();
					}
					$scope.hasMatches = matchingOptions.length > 0;
					$scope.showOptions = true;
				}
				$scope.selectedData = null;

				$scope.onSelect = function(selection) {
						//console.log(selection);
						$scope.selectedData = selection;
					};

					$scope.clearInput = function() {
						$scope.$broadcast('simple-autocomplete:clearInput');
					};
				$scope.processSearchTerm = function(term) {
					// console.log('ch-ch-ch-changin');
					if (term.length > 0) {
						if ($scope.selectedOption) {
							if (term != $scope.selectedOption[$scope.displayProperty]) {
								$scope.selectedOption = null;
							} else {
								$scope.closeAndClear();
								return;
							}
						}
						setupAllSearchService.term=term;
						if(term!=''){
							var request=angular.extend({},{
								searchText:term
							});
							 callAutoCompleteDetails(request).then(processAutoCompleteResponse);
						}
					} else {
						$scope.closeAndClear();
					}
				};

				$scope.findMatchingOptions = function(term) {
					return $scope.options.filter(function(option) {
						var searchProperty = option[$scope.displayProperty];
						if (searchProperty) {
							var lowerCaseOption = searchProperty.toLowerCase();
							var lowerCaseTerm = term.toLowerCase();
							return lowerCaseOption.indexOf(lowerCaseTerm) != -1;
						}
						return false;
					});
				};

				$scope.findExactMatchingOptions = function(term) {
					if(term!='' &&$scope.options!=null){
					return $scope.options.filter(function(option) {
						var lowerCaseOption = option[$scope.displayProperty].toLowerCase();
						var lowerCaseTerm = term.toLowerCase();
						return lowerCaseOption == lowerCaseTerm;
					});
					}else{
						return true;
					}
				};

				$scope.keyDown = function(e) {
					switch(e.which) {
						case Keys.upArrow:
							e.preventDefault();
							if ($scope.showOptions) {
								$scope.highlightPrevious();
							}
							break;
						case Keys.downArrow:
							e.preventDefault();
							if ($scope.showOptions) {
								$scope.highlightNext();
							} else {
								$scope.showOptions = true;
								if ($scope.selectedOption) {
									$scope.highlightedOption = $scope.selectedOption;
								}
							}
							break;
						case Keys.backSpace:
							if($scope.searchTerm==''){
								$scope.closeAndClear();
							}
							break;
						case Keys.enter:
							//e.preventDefault();
							if ($scope.highlightedOption) {
								$scope.selectOption($scope.highlightedOption);
							} else {
								var exactMatches = $scope.findExactMatchingOptions($scope.searchTerm);
								if (exactMatches[0]) {
									$scope.selectOption(exactMatches[0]);
								}
							}
							$scope.showOptions = false;
							//$rootScope.$emit("CallAdvSearchMethod", {});
							advSearchClickByEnter();
							break;
						case Keys.escape:
							$scope.closeAndClear();
							break;
					}
				};
				function advSearchClickByEnter(){
					var srchText;
					if($scope.searchTerm!=''){
						srchText = $scope.searchTerm;
					}else{

						srchText = angular.element("#srchtxt").val();	
					}
					
					var srchType = angular.element(".srchDrpDown").val();
					/*if(srchText==="/"){
						srchText='^';
						setupAllSearchService.srchText="/";
					}*/
					$state.go('advancedsearchdetails',{"srchtxt":srchText,"type":srchType},{reload:true});
					$scope.searchTerm='';
				};
				$scope.$watch('searchTerm', function(term){
					$scope.processSearchTerm(term);
				});

				$scope.highlightNext = function() {
					if (!$scope.highlightedOption) {
						$scope.highlightedOption = $scope.matchingOptions[0];
					} else {
						var currentIndex = $scope.currentOptionIndex();
						var nextIndex = currentIndex + 1 == $scope.matchingOptions.length ? 0 : currentIndex + 1;
						$scope.highlightedOption = $scope.matchingOptions[nextIndex];
					}
				};

				$scope.highlightPrevious = function() {
					if (!$scope.highlightedOption) {
						$scope.highlightedOption = $scope.matchingOptions[$scope.matchingOptions.length - 1];
					} else {
						var currentIndex = $scope.currentOptionIndex();
						var previousIndex = currentIndex == 0 ? $scope.matchingOptions.length - 1 : currentIndex - 1;
						$scope.highlightedOption = $scope.matchingOptions[previousIndex];
					}
				};

				$scope.onOptionHover = function(option) {
					$scope.highlightedOption = option;
				};

				$scope.$on('simple-autocomplete:clearInput', function() {
					$scope.searchTerm = '';
				});

				$scope.clearHighlight = function() {
					$scope.highlightedOption = null;
				};

				$scope.closeAndClear = function() {
					$scope.showOptions = false;
					$scope.clearHighlight();
				};

				$scope.selectOption = function(option) {
					// console.log('selected the option');
					$scope.selectedOption = option;
					$scope.onSelect(option);

					if ($scope.clearInput != 'False' && $scope.clearInput != 'false') {
						$scope.searchTerm = '';
					} else {
						$scope.searchTerm = option[$scope.displayProperty];
					}

					$scope.closeAndClear();
				};

				$scope.onBlur = function() {
					$scope.closeAndClear();
				};

				$scope.currentOptionIndex = function() {
					return $scope.matchingOptions.indexOf($scope.highlightedOption);
				};
			},
			link: function(scope, elem, attrs) {
				scope.optionWidth = '100%';
				var inputElement = elem.children('.autocomplete-input')[0];

				scope.setOptionWidth = function() {
					// console.log(inputElement.offsetWidth);
					$timeout(function() {
						var pixelWidth = inputElement.offsetWidth > 400 ? 400 : inputElement.offsetWidth - 2;
						scope.optionWidth = '100%';
					});
				};

				angular.element(document).ready(function() {
					scope.setOptionWidth();
				});

				angular.element($window).bind('resize', function() {
	                scope.setOptionWidth();
	            });
			}
		};
	}])

	.factory('autocomplete-keys', function() {
		return {
			upArrow: 38,
			downArrow: 40,
			enter: 13,
			escape: 27,
			backSpace: 8
		};
	});
	

	return directives;
});