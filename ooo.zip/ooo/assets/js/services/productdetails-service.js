/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("productDetailService",['$q', 'ajaxService', 'stateService', 'utilityService','urlService','$sessionStorage',function($q, ajaxService, stateService, utilityService,urlService,$sessionStorage){
	var product_wl;	
	var prodwl;
	return	{
			  addNewAddress:function(request){
        	 var url =  urlService.addNewAddressUrl();
             return ajaxService.doPost(url,{},request);
        },
        addProductToCartService:function(request){
       	 var url =  urlService.addToCartUrl();
            return ajaxService.doPost(url,{},request);
       },
       callCheckPinCodeAvail: function (request) {
           var url =  urlService.checkAvailibalityUrl();
           return ajaxService.doGet(url,request);
       },
	   addToWishList:function(request){
		   var url =  urlService.addToWishlistUrl();
            return ajaxService.doPost(url,{},request);
	   },
	   saveProductToAddToWlOnLogin:function(product){
		   product_wl=product;
	   },
	   getProductToAddToWlOnLogin:function(){
		   return product_wl;
	   },
	 //  productDetailService.delProductToAddToWlOnLogin(null);
	   delProductToAddToWlOnLogin:function(product){
		   product_wl=product;
	   },
	   navigateOnLoginToWIshlist:function(pid){
		   prodwl=pid;
		   return prodwl;
		},
		getProductIdOnLogin:function(){
			return prodwl;
		},
		
	  
		 getfromWhere: function(){
				return typeof $sessionStorage["fromWhere"] != "undefined" ? $sessionStorage["fromWhere"] : false;
			}
	};
	}]);
    
	return services;
});