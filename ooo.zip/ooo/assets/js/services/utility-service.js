/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("utilityService",['$q', 'stateService',function($q, stateService){
		return	{
			  getBreadCrum:function(level,breadCrumb){
		        	
		        },
		        isEqual: function(val1,val2){
		            return val1===val2;
		        },
		       
		        isEmptyObject:function(object){
		            return (object!==null  && object!=="" && object!==undefined);
		        },

		        //  Returns true if the object is undefined or null
		        isCheckEmpty:function(object){
		            return (object === undefined || object === null ||object==="");
		        },
		        isCheckEmptyArray:function(object){
		            return angular.isArray(object);
		        },
		        /**
		         * Shows or hides the accordion via the HTML id depending on the status
		         * @param status Accordion status (ACCORDION_NOT_STARTED, ACCORDION_CURRENT, ACCORDION_COMPLETE)
		         * @param htmlId HTML id of the accordion tab
		         */
		        expandOrCollapseAccordionBasedOnStatus: function(status, htmlId) {
		            var item = $("#" + htmlId);
		            if (status === constants.ACCORDION_CURRENT) {
		                item.show();
		            }else{
		                item.hide();
		            }
		        },
		        //  Returns true if the object is not undefined or not null
		        isObjectNotUndefinedOrNotNull:function(object){
		            return (!this.isObjectUndefinedOrNull(object));
		        },
		        /**
		         * Shows or hides the accordion via the HTML id depending on the status
		         * @param status Accordion status (MODAL_SHOW)
		         * @param htmlId HTML id of the accordion tab
		         */
		        modalExpandOrCollapse: function(status, htmlId) {
		            var item = $("#" + htmlId);
		            if (status===constants.MODAL_SHOW) {
		                item.modal('show');
		            }
		            else {
		                item.modal('hide');
		            }
		        }
		};
	}]);
    
	return services;
});