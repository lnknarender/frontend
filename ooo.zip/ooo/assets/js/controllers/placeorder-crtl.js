'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
	controllers.controller("placeorderCtrl", ['$rootScope','$scope', '$state','utilityService','setupAllSearchService','myCartService','stateService','$timeout','placeorderService','productDetailService', 'loginService','$sessionStorage','registrationUserService', function($rootScope, $scope, $state, utilityService,setupAllSearchService,myCartService,stateService,$timeout,placeorderService,productDetailService, loginService,$sessionStorage,registrationUserService) {
	
	    var vm = this;
	    vm.userInfo = loginService.getUserInfo();
        vm.shippingAddressShow=shippingAddressShow;
        //vm.onWalletSel= onWalletSel;
        vm.pickupShow=pickupShow;
        vm.orderContinue =orderContinue;
        vm.editProductsummary=editProductsummary;
        vm.shippingAddress=true;
        vm.pickup=false;
        vm.editShippingAddress=editShippingAddress;
        vm.submitOrder=submitOrder;
        vm.addNewAddress=addNewAddress;
        vm.newAddressHandler=newAddressHandler;
        vm.newSaveAddressHandler=newSaveAddressHandler;
        vm.newAddressContinue =newAddressContinue;
        vm.qtyDetails = [1,2,3,4,5,6,7,8,9,10];
        vm.newaddress={};
        vm.continueBtn=true;
        vm.paymentMode="DD";
        vm.newAddressAdded=false;
        vm.newShippingShowPanel= false;
        vm.isHybridMode=false;
        vm.hybridMode=hybridMode;
        vm.continueShopping=continueShopping;
        vm.pincode = "500082";
    	vm.deliveryAddress = {};
    	vm.shippingAddressdHandler=shippingAddressdHandler;
    	vm.ipickupHandler=ipickupHandler;
    	vm.shippingContinue=shippingContinue;
        vm.loginName = vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
        vm.isBuyNow=false;
        vm.orderPending = false;
		//vm.isOnlyWallet=false;
        //function onWalletSel(){
        //	if((vm.isHybridMode)&&parseFloat(vm.maxWallet.replace(',', ''))>=myCartService.orderAmount)
        //		vm.isOnlyWallet = true;
        //	else
        //		vm.isOnlyWallet = false;
        //}
        
        function callAddressDetails(){
                	return registrationUserService.getAddressDetails();
                }
        		function processAddressStateDataResponse(response){
                	vm.statesList = response.body.data;
                	//console.log(vm.statesList);
                // 	vm.districtList = response.body.data.districts;
                }
        vm.checkPinCodeStart = function(){
			var pin = vm.newaddress.pinCode;
			if(pin.charAt(0)=="0"){
				vm.pinValid = true;
			}else{
				vm.pinValid = false;
			}
		}
        vm.getTotal = function() {
        	var items = vm.cartDetails,
        		totAmount = 0,
        		item;
        	for(item = 0; item < items.length; item++) {
        		totAmount += parseFloat(items[item].subTotal, 10);
        	}
        	
        	return totAmount;
        };
        init();
      
        function shippingAddressdHandler(){
        	vm.shippingShowPanel = true;
        	vm.newShippingShowPanel= false;
        	vm.ipickShowPanel= false;
        	vm.shippingShow = vm.shippedAddress = vm.continueBtn =  true;
        	vm.newShippingShow = vm.ipickShow = vm.updateAddressSelected= false;
        }
        function ipickupHandler(){
        	vm.shippingShowPanel = false;
        	vm.newShippingShowPanel= false;
        	vm.ipickShowPanel= true;
        	vm.shippedAddress = vm.newShippingShow = vm.updateAddressSelected= false;
        	vm.ipickShow = vm.continueBtn = true;
        }
        function continueShopping(){
        	$state.go('myCart');
        }
        function shippingContinue(){
        	  getWalletRequest({'userName': vm.loginName
				}).then(processWalletResponse);
        	

        }
       function hybridMode(){
    	   vm.isHybridMode=!vm.isHybridMode;
       }
      function newSaveAddressHandler(){
    	  var request= angular.extend({},{
    		  loginName: vm.loginName, //stateService.get(constants.STATE_USER_NAME),
    		  address:{
    			  name:vm.newaddress.name,
        		  address: vm.newaddress.address,
        		  landmark:vm.newaddress.landmark,
        		  state:vm.newaddress.state,
        		  district:vm.newaddress.district,
        		  landLineNo: vm.newaddress.landLineNo,
        		  addressAttribute: 'SA',
        		  pinCode:+vm.newaddress.pinCode,
        		  country:vm.newaddress.country
    		  }
    		  
    		  
    	  });
    	  //processAddNewAddressResponse();
    	  addNewAddressRequest(request).then(processAddNewAddressResponse);
      }
      function addNewAddressRequest(request){
    	  return placeorderService.addNewAddress(request);
      }
      function processAddNewAddressResponse(response){
    	  var body = response.body;
    	  if(body.applicationStatusCode===1023){
    		  vm.shippingShowPanel = true;
    		  vm.newShippingShowPanel= false;
    		  vm.ipickShowPanel= false;
    		  vm.newAddressId=body.data[0];
    		  vm.newaddress.shipId = body.data[0];
    		  vm.newaddress.addressAttribute = 'SA';
    		  vm.newAddressSelected=false;
        	  $sessionStorage["isShipping"]=true;
        	  vm.shippedAddress=true;
        	  vm.newshippedAddress=true;
        	  vm.continueBtn=true;
        	  for(var addr=0,_addrlen=vm.shipping.length;addr<_addrlen;addr++){
        		  vm.shipping[addr].isDefaultShip=false;
        	  }
        	  vm.newaddress.state= placeorderService.getStatedName(vm.statesList,vm.newaddress.state);
        	  vm.newaddress.isDefaultShip = true;
       		  vm.shipping.push(vm.newaddress);
       		  vm.deliveryAddress = {};
       		  vm.deliveryToThis = true;
       		  vm.deliveryAddressId = body.data[0];
       		  vm.deliveryAddress = angular.copy(vm.newaddress);
       		  vm.newaddress = {};
       		vm.cancelEditAddressHandler();
    	  }else{
    		  vm.addNewAddressFailed=true;
    	  }
    	  
      }
      function newAddressHandler(){
    	  vm.shippingShowPanel = false;
    	  vm.newShippingShowPanel= true;
    	  vm.ipickShowPanel= false;
    	  vm.newAddressSelected=true;
    	  vm.shippedAddress=false;
    	  vm.continueBtn=false;
    	  vm.updateAddressSelected=false;
    	  vm.shippingShow = vm.ipickShow = false;
      	  vm.newShippingShow = true;
      	  vm.onlyShipping =  true;
      	//vm.onlyShipping =true;
      }
     function shippingAddressShow(){
    	 $sessionStorage["isShipping"]=true;
     	 vm.shippedAddress=true;
     	 vm.newAddressSelected=false;
     	 vm.updateAddressSelected=false;
    	 $sessionStorage["isIPickup"]=false;
    	 
     }
    
         function pickupShow(){
        	 $sessionStorage["isShipping"]=false;
         	vm.shippedAddress=false;
        	 $sessionStorage["isIPickup"]=true;
     }
         function addNewAddress(){
        	 
         }
    function editShippingAddress(){
    	vm.tabs.productsummaryCompleted=false;
    	vm.tabs.shippingAddressCompleted=false;
    	vm.tabs.editShippingAddress = false;
    	vm.tabs.editProductsummary = true;
    	vm.shippingSummaryShow=false;
    	defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    }
    function editProductsummary(){
    	vm.showSummarySection=true;
    	vm.showSummaryReview=false;
    	vm.shippingSummaryShow=false;
    	
    	vm.cancelEditAddressHandler();
    	  
    	defaultValues(vm,'productsummary',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
     }
    function defaultValues(vm,active,productsummary,shippingaddress,paymentmethod){
    	vm.tabs=vm.tabs||{};
    	 vm.tabs.active=active;
    	angular.extend(vm,{
    		accordionStatus:{
    			shippingaddress:shippingaddress,
        		productsummary:productsummary,
        		paymentmethod:paymentmethod
    		}
    		
    	});
    	placeorderService.expandOrCollapseAccordion(vm.accordionStatus);
    	
    }
    function getShippingAddress(vm){
    	
    	for(var i=0;i<vm.shipping.length;i++) {
  			if(vm.shipping[i].isDefaultShip){
  				vm.deliveryAddressId = vm.shipping[i].shipId;
  				vm.deliveryToThis=true;
  				vm.deliveryAddress = vm.shipping[i];
  			}
  			
  			
  		}
    }
    function orderContinue(){
    	var isBoth = $sessionStorage["isBoth"];
    	vm.tabs.productsummaryCompleted=true;
    	vm.tabs.active = 'shippingAddress';
    	vm.showSummaryReview=true;
    	vm.showSummarySection=false;
    	if(isBoth){
    		   vm.shippingShowPanel = true;
    		   if(vm.onlyShipping && !vm.shippingResponse){
    			   placeorderService.getShippingAddresses(vm.loginName).then(function(response) {
    				   vm.shippingResponse=true;
    		    		vm.shipping = response.body.data;
    		    		vm.stores = $sessionStorage["storeSelected"];
    		    		vm.shippingShow=vm.onlyShipping=vm.shippedAddress=true;
    		    		getShippingAddress(vm);
    		    		defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    		    	});
    		   }else{
    			   vm.stores = $sessionStorage["storeSelected"];
		    		vm.shippingShow=vm.onlyShipping=vm.shippedAddress=true;
		    		defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    		   }
    	}else if(vm.onlyShipping){
    		vm.shippingShowPanel = true;
    		if(!vm.shippingResponse){
        		vm.shippingResponse=true;
        		placeorderService.getShippingAddresses(vm.loginName).then(function(response) {
    	    		vm.shipping = response.body.data;
    	    		vm.shippingShow=vm.onlyShipping=vm.shippedAddress=true;
    	    		getShippingAddress(vm);
    	    		defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    	    	});
    		}else{
    			vm.shippingShow=vm.onlyShipping=vm.shippedAddress=true;
	    		defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    		}
    		
    	}else{
    		vm.ipickShow = vm.onlyipickup=true;
    		vm.stores = $sessionStorage["storeSelected"];
    		defaultValues(vm,'shippingAddress',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    	}
   
    	
    }
    function getWalletRequest(request){
    	return placeorderService.getUserWallet(request);
    }
    function processWalletResponse(response){
    	vm.shippingSummaryShow=true;
    	vm.tabs.active == 'paymentmethod';
    	
    	defaultValues(vm,'paymentmethod',constants.ACCORDION_SUCCESS,constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT);
	    vm.tabs.productsummaryCompleted=true;
    	vm.paymentshow='pod';
    	vm.paymenttype='DD';
    	var walletObj= response.body.data[0];
    	/*for(var wlt=0,wltLen=walletObj.length;wlt<wltLen;wlt++){
    		if(walletObj[wlt].usage==='farminput'){
    			vm.maxWallet=walletObj[wlt].walletAmount||0;
    		}
    	}*/
    	vm.maxWallet=walletObj['farminput']||0;
    }
 function newAddressContinue(){
    	vm.newAddressOption=true;
    	vm.shippingAddressOption=false;
    	defaultValues(vm,'productsummary',constants.ACCORDION_SUCCESS,constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED);
    	vm.tabs.shippingAddressCompleted=true;
    	vm.tabs.editShippingAddress=true;
    }
	 function getProdcutSummary(request){
		 return placeorderService.getProdcutSummary(request);
	 }
	 function processProductSummaryResponse(response){
		 var body= response.body;
		 $rootScope.dataLoading = false;
		 $rootScope.dataStillLoading = false;
		 if(body.applicationStatusCode===1028){
			 var data=[body.data[0]];
			 vm.cartDetails=data;
			 for(var add=0; add<vm.cartDetails.length;add++){
				 if(vm.cartDetails[add].deliveryMode == "IPICKUP"){
					 vm.cartDetails.iPickupAddressDetails = vm.cartDetails[add].store;
					 break;
				 }
			 }
			 vm.cartDetails[0].product.productImgPath = connection.store+"images/"+vm.cartDetails[0].product.productImgPath;
			 /*$scope.gridOptions.data = vm.cartDetails;
   			 $timeout(function() {
   			 	$(window).resize();
   			 	$(window).resize();
			 }, 600);*/
		     
			 vm.shippingAddressOption=true;
 	    	vm.newAddressOption=false;
 	    	vm.tabs.shippingAddressCompleted=true;
 	    	vm.tabs.editShippingAddress=true;
 	    	vm.showSummarySection=true;
 	    	if($sessionStorage["isIPickup"]){
 	    		vm.ipickup_stores=data[0].store;
 	    	}
 	    	vm.totProductAmount = vm.userAmount =myCartService.orderAmount=data[0].subTotal.toFixed(2);
 	    	if(!vm.deliveryToThis) {
 			 	vm.deliveryToThis = false;
 				vm.deliveryAddressId = vm.userInfo.shippingAddress.shipId;
 				vm.deliveryAddress = vm.userInfo.shippingAddress;    		
 			}
 	    	vm.totProductAmount = vm.getTotal();
 	    	defaultValues(vm,'productsummary',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
		 }
		
	 }
   

    
    /** START: Grid options **/
    
/*    $scope.getTableHeight = function() {
        var rowHeight = 120; // your row height
        var headerHeight = 12; // your header height
        return {
           height: $scope.gridOptions.data ? ($scope.gridOptions.data.length * rowHeight + headerHeight) + "px" : "167px"
        };
    };
     
	
	
	$scope.gridOptions.onRegisterApi = function(gridApi){
        //set gridApi on scope
        $scope.gridApi = gridApi;
        gridApi.edit.on.afterCellEdit($scope,function(rowEntity, colDef, newValue, oldValue){
        	var newValue = parseInt(newValue, 10);
          if(newValue != oldValue) {
        	  var oldTotal = rowEntity.subTotal,
        	  diff = 0;
        	  rowEntity.subTotal = parseFloat(rowEntity.discountedPrice * newValue, 10);
          }
          $scope.$apply();
        });
        
        gridApi.rowEdit.on.saveRow($scope, $scope.saveRow);
    };
    
    $scope.saveRow = function (rowEntity) {
        var promise = $q.defer();
        $scope.gridApi.rowEdit.setSavePromise(rowEntity, promise.promise);
        promise.resolve();
    };*/
    function initialSetup(){
    	/*vm.cartDetails = myCartService.cartDetails;
    	vm.onlyShipping = myCartService.isShipping;
    	vm.onlyipickup = myCartService.isIPickup;
    	vm.userAmount = myCartService.orderAmount;*/
    	vm.cartDetails = $sessionStorage["cartDetails"];
    	vm.onlyShipping = $sessionStorage["isShipping"];
    	vm.onlyipickup = $sessionStorage["isIPickup"];
    	vm.userAmount = $sessionStorage["orderAmount"];
    	
    	productDetailService.isShipping = productDetailService.isShipping ? productDetailService.isShipping : $sessionStorage["isShipping"];
        productDetailService.isIpickUp = productDetailService.isIpickUp ? productDetailService.isIpickUp : $sessionStorage["isIPickup"];
        productDetailService.shipAddressId = (productDetailService.isShipping || $sessionStorage["isShipping"])?vm.userInfo.shippingAddress.shipId:null;
        productDetailService.productDetails = productDetailService.productDetails ? productDetailService.productDetails : $sessionStorage["pd_productDetails"];
        productDetailService.quantity = productDetailService.quantity ? +productDetailService.quantity : +$sessionStorage["pd_quantity"];
        productDetailService.storeSelected = productDetailService.storeSelected ? productDetailService.storeSelected: $sessionStorage["pd_storeSelected"];
        
       
    	orderDetails();
    	
    }
    function orderDetails(){
		//if(stateService.get(constants.STATE_USER_ACTION)===constants.BUYNOW_ACTION){
    	if($sessionStorage[constants.STATE_USER_ACTION] === constants.BUYNOW_ACTION){
			//productDetailService.productDetails= productDetails;
    	    productDetailService.isShipping = productDetailService.isShipping ? productDetailService.isShipping : $sessionStorage["isShipping"];
    	    productDetailService.isIpickUp = productDetailService.isIpickUp ? productDetailService.isIpickUp : $sessionStorage["isIPickup"];
    	    
			var request= angular.extend({},{
			         isShipping:productDetailService.isShipping,
    				 isIpickUp:productDetailService.isIpickUp,
    				 shipAddressId:productDetailService.shipAddressId,
    				 product:{
    				 	productId:productDetailService.productDetails.productId,
    				 	productQuantity:productDetailService.quantity,
    				 	storeId:productDetailService.storeSelected.storeId,
    				 	pinCode:productDetailService.storeSelected.pinCode,
    				 	distanceFromStore:productDetailService.storeSelected.distance
    				 }
			});
			$rootScope.dataLoading = true;
			$rootScope.dataStillLoading = true;
			getProdcutSummary(request).then(processProductSummaryResponse);
		}else{
			/*vm.shippingAddressOption=true;
	    	vm.newAddressOption=false;
	    	vm.tabs.shippingAddressCompleted=true;
	    	vm.tabs.editShippingAddress=true;
	    	vm.tabs.editProductsummary=false;*/
	    	defaultValues(vm,'productsummary',constants.ACCORDION_CURRENT,constants.ACCORDION_NOTSTARTED,constants.ACCORDION_NOTSTARTED);
	    	vm.showSummarySection=true;
	    	/*$scope.gridOptions.data = vm.cartDetails;*/
	    	for(var add=0; add<vm.cartDetails.length;add++){
				 if(vm.cartDetails[add].deliveryMode == "IPICKUP"){
					 vm.cartDetails.iPickupAddressDetails = vm.cartDetails[add].store;
					 break;
				 }
			 }
   			/*$timeout(function() {
   				$(window).resize();
   				$(window).resize();
			}, 600);*/
   			if(!vm.deliveryToThis) {
   			 	vm.deliveryToThis = false;
   				vm.deliveryAddressId = vm.userInfo.shippingAddress.shipId;
   				vm.deliveryAddress = vm.userInfo.shippingAddress;    		
   			}
   	    	vm.totProductAmount = vm.getTotal();
		}
		
    }
  
	/** END: Grid options**/
    function init(){
    	//vm.shipping = stateService.get(constants.USER_SHIPPING_ADDRESS);
    	vm.orderPending = $sessionStorage["cartDetails"].length > 0;
    	vm.tabs=vm.tabs||{};
    	vm.tabs.editProductsummary=false;
/*    	$scope.gridOptions = {
                enableColumnMenu: false,
    		    rowEditWaitInterval: -1,
    		    rowHeight: 100,
                columnDefs: [
                    { field:"product.productImgPath", name: 'Image', enableCellEdit: false, enableColumnMenu: false,
                    	cellTemplate: '<img class="origo-list-image" alt="Embedded Image" src="assets/{{row.entity.product.productImgPath}}"</img>'
                    },
                    { field:"product.productName", name: 'Product Name', enableCellEdit: false, enableColumnMenu: false },
                    { field:"quantity", name: 'Quantity', enableCellEdit: false, enableColumnMenu: false,
                    	headerCellTemplate: '<div class="ui-grid-cell-contents"><span>Quantity</span><span class="wlt-promo-edit-info">(Double click to edit quantity)</span></div>',
                    },
                    { field:"discountedPrice", name: 'Price', enableCellEdit: false, enableColumnMenu: false },
                    { field:"shippingCharges", name: 'Shipping Charges', enableCellEdit: false, enableColumnMenu: false },
                    { field:"subTotal", name: 'Sub-Total', enableCellEdit: false, enableColumnMenu: false },
                ]
            };*/
    	if(vm.orderPending) {
        	initialSetup();
        	callAddressDetails().then(processAddressStateDataResponse);    		
    	} else {
    		angular.element("#origo-orderexists").hide();
    	}
    }
    

    
   
    
    vm.removeShippingAddress = function(toRemoveAddress) {
    	var request= angular.extend({},{
  		    /*loginName:stateService.get(constants.STATE_USER_NAME),*/
  		    shipId: toRemoveAddress.shipId
  	  	});
    	$rootScope.dataLoading = true;
    	placeorderService.removeAddress(request).then(function(response) {
    		var body = response.body;
    		$rootScope.dataLoading = false;
	      	if(body.applicationStatusCode===1040){
	      		for(var i=0;i<vm.shipping.length;i++) {
	      			if(vm.shipping[i].addressAttribute==="VA"){
	      				vm.deliveryAddressId = vm.userInfo.shippingAddress.shipId;
	      				vm.shipping[i].isDefaultShip=true;
	      				vm.deliveryToThis=true;
	      			}else{
	      				vm.shipping[i].isDefaultShip=false;
	      			}
	      			
	      			if(vm.shipping[i].shipId === toRemoveAddress.shipId) {
	      				vm.shipping.splice(i, 1);
	      				break;
	      			}
	      		}
	      		vm.cancelEditAddressHandler();
	      	} else {
	      		vm.removeAddressFailed=true;
	      		$timeout(function() {
	      			vm.removeAddressFailed=false;
	      		}, 5000);
	      	}
    	});
    };
    
    vm.cancelEditAddressHandler = function() {
    	vm.shippingShowPanel = true;
    	vm.newShippingShowPanel= false;
    	vm.ipickShowPanel= false;
    	vm.updateAddressSelected = vm.newShippingShow= false;
    	vm.newAddressSelected = false;
    	vm.shippedAddress =vm.shippedAddress = true;
    	vm.shippingShow = vm.shippedAddress = vm.continueBtn =  true;
    	vm.newShippingShow = vm.ipickShow = vm.updateAddressSelected= false;
    };
    
    vm.editInlineShippingAddress = function(address) {
    	var stateindex;
    	//vm.continueOrder=true;
    	vm.editedShippingId = address.shipId;
    	vm.updateaddress = new Object();
    	vm.updateAddressSelected = true;
    	 vm.continueBtn=false;
    	vm.shippedAddress = false;
    	vm.updateaddress = _.extend(vm.updateaddress, address);
    	//console.log("Here print:"+vm.updateaddress.state);
    	for(var i=0;i<vm.statesList.length;i++){if(vm.statesList[i].state == address.state){stateindex = i; break;}}
    	vm.updateaddress.state=stateindex.toString();
    	vm.updateaddress.district = address.district;
    };
    
    vm.updateSaveAddressHandler = function(updateAddress) {
    	updateAddress.addressAttribute = updateAddress.addressAttribute==='VD'?'DS':updateAddress.addressAttribute;
    	var request= angular.extend({},{
  		    	shipId: updateAddress.shipId,
  		    	addressAttribute: updateAddress.addressAttribute,
  			    name: updateAddress.name,
      		    address: updateAddress.address,
      		    landmark: updateAddress.landmark,
      		    landLineNo: updateAddress.landLineNo,
      		    state: updateAddress.state,
      		    district: updateAddress.district,
      		    pinCode: updateAddress.pinCode,
      		    country: updateAddress.country
  		 });

    	placeorderService.updateAddress(request).then(function(response) {
    		var body = response.body,stateindex;
	      	if(body.applicationStatusCode===1041){
	        	for( var addr = 0; addr < vm.shipping.length; addr++) {
					if(vm.shipping[addr].shipId == vm.editedShippingId) {
						vm.shipping[addr] = angular.copy(vm.updateaddress);
						if(vm.shipping[addr].isDefaultShip){
							vm.deliveryAddress = vm.shipping[addr];	
						}
							
							vm.shipping[addr].state =vm.statesList[vm.updateaddress.state].state;
						break;
					}
				}
	        	
	          	vm.updateAddressSelected = false;
	        	vm.shippedAddress = true;
	        	vm.cancelEditAddressHandler();
	      	} else {
	      		vm.updateAddressFailed=true;
	      		$timeout(function() {
	      			vm.updateAddressFailed=false;
	      		}, 5000);
	      	}
    		
    	});
    };
    
    vm.deliveryToAddress = function(deliveryAddress) {
    	//$('div').removeClass('color-change');
    
    	vm.deliveryAddress = {};
    	vm.deliveryToThis = true;
    	vm.deliveryAddressId = deliveryAddress.shipId;
    	vm.deliveryAddress = angular.copy(deliveryAddress);
    	for( var addr = 0; addr < vm.shipping.length; addr++) {
			if(vm.shipping[addr].shipId == deliveryAddress.shipId) {
				vm.shipping[addr].isDefaultShip=true;
			}else{
			vm.shipping[addr].isDefaultShip=false;
			}
	   }
    	//angular.element("#"+deliveryAddress.shipId).addClass('color-change');
    };
    
    function submitOrder(){
  	 var request = createRequest();
  	//processSubmitOrderResponse();
  	$rootScope.dataLoading = true;
  	submitOrderRequest(request).then(processSubmitOrderResponse);
    }
    function submitOrderRequest(request){
    	return placeorderService.submitOrderRequest(request);
    }
    function processSubmitOrderResponse(response){
    	$rootScope.dataLoading = false;
    	if(response.body.applicationStatusCode=1027){
    		vm.orderresponse = response.body.data[0];
    		stateService.set(constants.ORDER_FULL_RESPONSE,vm.orderresponse);
    		vm.orderresponseproduct = response.body.data[0].userOrderDetailsDTO;
    		stateService.set(constants.ORDER_USERDETAIL_RESPONSE,vm.orderresponseproduct);
    		$sessionStorage["orderDetailsOnSuccess"] = {orderDetails:response.body.data[0].userOrderDetailsDTO , isBuyNow : vm.isBuyNow};
    		$sessionStorage["cartDetails"] = [];
    		$state.go('ordersuccess');
    	}else{
    		
    	}
    	
    }
    function createRequest(){
    	
    	 var shipAddresId,isBuyNow=($sessionStorage[constants.STATE_USER_ACTION]===constants.BUYNOW_ACTION)?true:false,cartProductDTO=null;
    	 if($sessionStorage["isShipping"]){
    		 if(vm.deliveryToThis){
    			 vm.shipAddresId= vm.deliveryAddressId;
    		 }else{
    			 vm.shipAddresId= vm.userInfo.shippingAddress.shipId;
    		 }
    	 }
    	 
    	var deliveryModeDTO=angular.extend({},{
    		isShippingAddress: $sessionStorage["isShipping"],
			isIpickUp: $sessionStorage["isIPickup"],
			shipAddressId:vm.shipAddresId,
    	});
    	if(isBuyNow){
    		 vm.isBuyNow=true;
    		 cartProductDTO=angular.extend({},{
    			productId:vm.cartDetails[0].product.productId,
    			productQuantity: vm.cartDetails[0].quantity,
    			storeId: +productDetailService.storeSelected.storeId,
    			pinCode:productDetailService.storeSelected.pinCode,
			 	distanceFromStore:productDetailService.storeSelected.distance,
    			deliveryModeDTO:deliveryModeDTO
    		   });
    	}else{
    		 cartProductDTO=angular.extend({},{
     			deliveryModeDTO:deliveryModeDTO
     		   });
    	}
    	var paymentMode =vm.paymentshow==="cod"?"COD":vm.paymenttype;
 		//paymentMode = vm.isHybridMode?(parseFloat(vm.maxWallet.replace(',', ''))>vm.userAmount?"":paymentMode):paymentMode;
    	    paymentMode = vm.isHybridMode?(parseFloat(vm.maxWallet.replace(',', ''))>vm.userAmount?"":paymentMode):paymentMode;
    	    if(utilityService.isCheckEmpty(paymentMode)){
    	    	vm.isHybridMode=false;
    	    }
    	    		
    	var paymentModeObj=angular.extend({},{
    		paymentMode:paymentMode,
    	    isHybridMode:vm.isHybridMode,
    	    usage:'farminput',
    	    
    	});
    	var request=angular.extend({},{
    		loginName: vm.loginName, //stateService.get(constants.STATE_USER_NAME),
    		isBuyNow: isBuyNow,
    		paymentModeDTO: paymentModeObj,
    		cartProductDTO:cartProductDTO
    		
    	});
    	return request;
    }

  
}]);
});