/*global define */
define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */

	services.factory('stateService', function () {
	    var data = {};
	    return{
	        set: function (key, value) {
	            data[key] = value;
	            return data[key];
	        },
	        get: function (key) {
	            return data[key];
	        },
	        reset: function (key) {
	            if (key) {
	                delete data[key];
	            } else {
	                data = {};
	            }
	        }
	    };
	});
    
	return services;
});