/**
 * 
 */

define(['angular', 'services-module','underscore'], function(angular, services,underscore) {
	'use strict';
	
	/* Services */
services.factory("userWishlistService",['$q', 'ajaxService', 'urlService',function($q, ajaxService, urlService){
	
	var demandToShare=null;
	var updation=false;
	return {
		/*
		getSubmittedDemands:function(wlDetails){
			var url = urlService.getUserWLItems();
			 return ajaxService.doGet(url,wlDetails);
		},*/
		 getSubmittedDemands:function(wlDetails){
			 var url = urlService.getUserDemands();
			 return ajaxService.doGet(url,wlDetails);
		 },
		 sendSubmit:function(demand){
			 var url = urlService.sendSubmitDemand();
			 return ajaxService.doPost(url,{},demand);
			 
		 },
		 deleteDemand:function(demDetails){
			 var url = urlService.delDemand();
			 return ajaxService.doDelete(url,demDetails);
		 },
		 sendDemandToSD:function(demand,value){
			 updation=value;
			 demandToShare=demand;
		 },
		 retrieveDemandInSD:function(){
			 return demandToShare;
		 },
		 retrieveUpdationstatus:function(){
			 return updation;
		 },
		 sendViewDemandToSD:function(demand){
			 return demand;
		 },
		 //to get products in wishlist
		 getProductsOfWL:function(wlDetails){
			 var url = urlService.getUserWishlistItems();
			 return ajaxService.doGet(url,wlDetails);
		 },
		 //to delete item from wishlist
		 deleteItemFromWL:function(delItem){
			 var url = urlService.delItemFromWL();
			 return ajaxService.doDelete(url,delItem);
		 }
	    
		
	};
	}]);
    
	return services;
});