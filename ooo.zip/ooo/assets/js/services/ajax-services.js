/*global define */
define(['angular', 'services-module', 'underscore'], function(angular, services, underscore) {
    'use strict';

    /* Services */
    services.factory("ajaxService", ['$http', '$q', '$timeout', 'urlService', 'stateService', '$sessionStorage', '$state', '$rootScope', function($http, $q, $timeout, urlService, stateService, $sessionStorage, $state, $rootScope) {
        var config = {
            //withCredentials: true, commented this as IE8 doesn't support this property when native xml http is disabaled.
            timeout: 60000
        };

        function doPerform(method, url, params, postData, def, $sessionStorage, retry, attachment) {
            /*  if (IframeHelper.busy) {
              	console.log("postData");
                  $timeout(function () {
                      doPerform(method, url, params, postData, def);
                  }, 500);
              } else {*/

            var userInfo = (typeof $sessionStorage["userInfo"] != "undefined") ? $sessionStorage["userInfo"] : false,
                token = userInfo.origoToken;
            if (attachment) {
                x = postData;
                console.log("postData" + postData);
                $http.post(url, postData, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })

                .success(function() {
                    def.resolve(data);
                })

                .error(function() {});
            } else {

                $http({
                    method: method,
                    url: url,
                    cache: false,
                    params: params,
                    data: postData,
                    headers: {
                        'origoToken': token
                    },
                    //withCredentials: config.withCredentials,
                    timeout: config.timeout
                }).
                success(function(data, status, headers, config) {
                    def.resolve(data);
                }).
                error(function(data, status, headers, config) {
                    def.reject(data);
                    if (status == 401) {
                        console.log("Erooorrrrrrrrrrrrrrrrrrr Session timed out");
                        $rootScope.showSessionTimeOutError = true;
                        if (typeof $sessionStorage["userInfo"] != "undefined") {
                            $sessionStorage.$reset(); // Remove localstorage data
                        }
                        angular.element('#loginuser').show();
                        angular.element('#loginuserdevide').show();
                        angular.element('#signuser').show();
                        angular.element('#userLoggedIn').hide();
                        angular.element('#signeduser').text("");
                        //angular.element('#logoutuser').text("");angular.element('#userLoggedIn').show();
                        //angular.element('#signedinuserdevide').hide();
                        angular.element('#cartcounterlist').text(0);
                        // 	stateService.set(constants.STATE_TOKEN,'');
                        stateService.reset();
                        //  loginService.logout();
                        $rootScope.dataLoading = false;
                        $rootScope.dataStillLoading = false;

                        $state.go('login');
                    }
                    /*  if (data && data.refresh && !retry) {
                          IframeHelper.refresh(function () {
                              doPerform(method, url, params, postData, def, true);
                          }, urlService.getSecurePath() +  urlService.getAccessTokenUrl());
                      } else {
                          def.reject(data);
                      }*/
                });
            }
            //   }
        }


        return {
            doGet: function(url, params) {
                var deferred = $q.defer(),
                	timeStamp = new Date().getTime();
                params = params || {};
                params["_t"] = timeStamp;
                doPerform("GET", url, params, null, deferred, $sessionStorage);
                return deferred.promise;
            },
            doDelete: function(url, params) {
                var deferred = $q.defer();
                doPerform("DELETE", url, params, null, deferred, $sessionStorage);
                return deferred.promise;
            },
            doPost: function(url, params, data) {
                var deferred = $q.defer();
                doPerform("POST", url, params, data, deferred, $sessionStorage);
                return deferred.promise;
            },
            doPostForAttachment: function(url, params, data) {
                var deferred = $q.defer();
                doPerform("POST", url, params, data, deferred, $sessionStorage, null, true);
                return deferred.promise;

            },
            doPut: function(url, params, data) {
                var deferred = $q.defer();
                doPerform("PUT", url, params, data, deferred, $sessionStorage);
                return deferred.promise;
            }
        };
    }]);

    return services;
});