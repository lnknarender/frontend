'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("storeLocatorCtrl", ['$scope','$state','$rootScope', 'setupAllSearchService','$window','$stateParams','$timeout', function($scope,$state, $rootScope,setupAllSearchService,$window,$stateParams,$timeout) {
	
    var vm = this;
    //$scope.loading=true;
    //initializing method
    init();
    function init() {
         vm.waitingForPageToLoad = false;
         var locator= $stateParams.type;
         vm.state=$stateParams.state,vm.district=$stateParams.district;
         $('input:radio[name="radioGroup"][value="'+locator+'"]').prop('checked', true);
         angular.element("#state").val(vm.state);
         angular.element("#district").val(vm.district);
         var findLocators=angular.extend({},{
     		storeType:locator,
     		state:vm.state,
     		district:vm.district,
     		pincode:500032
     	});
        vm.warehouse = false;
     	if(locator!='ST'){
     		vm.warehouse = true;
     	}
     	$rootScope.dataLoading = true;
     	$rootScope.dataStillLoading = true;
         callWareHouseLocationsDetails(findLocators).then(processWareHouseLocationsResponse);
         vm.storeDetails = true;
         vm.map_grid = true;
         //vm.limit="2";
    }
  //getting store locator details with findLocators object
    function callWareHouseLocationsDetails(findLocators){
    	return setupAllSearchService.getAllWareHouseLocationsDetails(findLocators);
    }
    function processWareHouseLocationsResponse(response){
    	vm.storesLocation = response;
    	$rootScope.dataLoading = false;
    	$rootScope.dataStillLoading = false;
    	vm.storesLocation.body.data[0].forEach(function(value,index){
    		vm.storesLocation.body.data[0][index].imgPath = connection.storeImage+vm.storesLocation.body.data[0][index].imgPath;
    	});
    	$scope.loading=false;
    	vm.waitingForPageToLoad = true;
    	if(response.body.data[0].length===0){
       		if(vm.warehouse){
       			vm.storeDetails = false;
       		}else{
       			vm.storeDetails = false;
       		}
       		return false;
       	}else{
       		$timeout(mapsIntegration, 200);
       	}
       	if(response.body.applicationStatusCode===2017|| response.body.applicationStatusCode===2019) {
       		vm.storeDetails = false;
       	}
     }
  //Show map view details
    vm.showStores = function(){
       	if(vm.map_grid){
       		//return;
       	}
       	vm.map_grid = true;
       	
       	var mapView = angular.element( document.querySelector( '#mapView' ) );
       	mapView.addClass('mapview-active');
       	mapView.removeClass('mapview');
       	var gridView = angular.element( document.querySelector( '#gridView' ) );
       	gridView.addClass('gridview');
       	gridView.removeClass('gridview-active');
    };
  //Google maps API integration
    function mapsIntegration(){
    	var defaultLoc = vm.storesLocation.body.data[0][0];
    	var mapOptions = {
    			zoom: 8,
    	        center: new google.maps.LatLng(defaultLoc.lattitude, defaultLoc.longitude),
    	        mapTypeId: google.maps.MapTypeId.TERRAIN
    	}
    	   	
    	vm.map = new google.maps.Map(document.getElementById('sl_map'), mapOptions);
    	
        vm.markers = [];
        
        var infoWindow = new google.maps.InfoWindow();
        
        var createMarker = function (info){
            
            var marker = new google.maps.Marker({
                map: vm.map,
                position: new google.maps.LatLng(info.lattitude, info.longitude),
                title: info.name1,
                label:'O'
            });
            //marker.content = '<div class="infoWindowContent"><p>Contact: ' + info.phone_number + '</p><p>Weekdays: '+info.wd_open_time+' to '+info.wd_close_time+'</p><p>Weekends: '+info.we_open_time+' to '+info.we_close_time+'</p></div>';
            
            google.maps.event.addListener(marker, 'click', function(){
                //infoWindow.setContent('<h5>' + marker.title + '</h5>' + marker.content);
            	infoWindow.setContent('<h5>' + marker.title + '</h5>');
                infoWindow.open(vm.map, marker);
            });
            
            vm.markers.push(marker);
            return marker;
        }  
        
        for (var i = 0;  i < vm.storesLocation.body.data[0].length;  i++){
            var markerDetails = createMarker(vm.storesLocation.body.data[0][i]);
            vm.storesLocation.body.data[0][i].marker = markerDetails;
        }
    }
  //Show grid view details
    vm.showGrid = function(){
    	if(!vm.map_grid){
       		return;
       	}
       	vm.map_grid = false;
       	var mapView = angular.element( document.querySelector( '#mapView' ) );
       	mapView.addClass('mapview');
       	mapView.removeClass('mapview-active');
       	var gridView = angular.element( document.querySelector( '#gridView' ) );
       	gridView.addClass('gridview-active');
       	gridView.removeClass('gridview');
    };
  //Show map marker description click on store details
    vm.openInfoWindow = function(e, selectedMarker){
        e.preventDefault();
        google.maps.event.trigger(selectedMarker, 'click');
    };
	
	}]);
});