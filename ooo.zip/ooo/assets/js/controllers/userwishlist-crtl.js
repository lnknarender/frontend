/**
 * 
 */
define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("userWishlistCtrl", ['$rootScope','$scope','$state','userWishlistService','utilityService','loginService','stateService','productDetailService','myCartService', 
                                         function($rootScope,$scope,$state,userWishlistService,utilityService,loginService,stateService,productDetailService,myCartService) {
	var vm=this;
	var userName,quantity_item;
	var itemsInWL=[];
	vm.noItemsInWL=false;
	vm.itemAvailable=false;
	vm.prodAvailableAtPin=false;
	vm.noStores=false;
	vm.chooseShipMode=false;
	vm.quantityNotAvail=false;
	var item_actions;
	vm.showWishlistItems=function(){
	//not on click- but on init send request to get all the wishlist products and populate
		var wlDetails={loginName:userName,uniq:new Date().toString()};
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		callGetProductsAddedToWL(wlDetails).then(callGetProductsAddedToWLResponse);
	
	}
	init();
	function init(){
		//$scope.loading=true;
		//send a request to get wishlist-added items.
		userName=loginService.getUserInfo().userName;//stateService.get(constants.STATE_USER_NAME);
		vm.showWishlistItems();
	}
	function callGetProductsAddedToWL(wlDetails){
		//call a service to call- service
		return userWishlistService.getProductsOfWL(wlDetails);
	}
	function callGetProductsAddedToWLResponse(response){
		var res=response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		if(res.applicationStatusCode==1043){
			//$scope.loading=false;
			for(var item=0;item<res.data.length;item++){
				res.data[item].imageUrl=connection.store+"images/"+res.data[item].imageUrl;
			}
			vm.userItems=res.data;	
			vm.itemAvailable=true;
		}
		if(res.applicationStatusCode==1044){
			vm.userItems=res.data;
			if(vm.userItems==null){
				//$scope.loading=false;
				vm.itemAvailable=false;
				vm.noItemsInWL=true;
			}
		}
		
	}
	vm.goToHomePage=function(){
		$state.go('start');
	}
	vm.showWLItem=function(item){
		//on click of div of item navigate to productDetails pg and on initialization load the contents and change text as addes to wishlist
		 $state.go('productdetails',{"id":item.productId});
	}
	vm.deleteItemFromWl=function(item){
		//var del_wl_confirm=confirm("Are you sure you want to delete?");
		//if(del_wl_confirm==true){
		var delItem={
				category:item.category,
				wishListId:item.wishListId,
				uniq:new Date().toString()
		};
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		callDeleteItemFromWL(delItem).then(callDeleteItemFromWLResponse);
	//	}
	}
	function callDeleteItemFromWL(delItem){
		return userWishlistService.deleteItemFromWL(delItem);
	}
	function callDeleteItemFromWLResponse(response){
		var res=response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		if(res.applicationStatusCode==1036){
			vm.showWishlistItems();
		}
	}
	vm.checkQunatity=function(item){
		item.isStoreNotAvl,item.quantityNotAvail,item.chooseShipMode= false;
		if(item.storeId==null){
			item.isStoreNotAvl=true;
	
		}
		else{
			if(!item.available){
				item.quantityNotAvail=true;
			}else{
				item.chooseShipMode=true;
				item.shippingIpickup="shipping";
			}
		}	
	}
	vm.addToCart=function(item){
		item_actions=item;
		var ship,iPick;
		var ip=stateService.get(constants.USER_SHIPPING_ADDRESS);
		if(item.shippingIpickup=='shipping'){
			ship=true
			iPick=false;
		}else if(item.shippingIpickup=='ipickup'){
			ship=false;
			iPick=true;
		}
		var request={
				loginName:userName,
				product:{
					productId:item.productId,
					productQuantity:item.quantity,
					storeId:item.storeId,
					pinCode:item.pincode,
					distanceFromStore:item.distance,
					deliveryModeDTO:{
								isShippingAddress:ship,
								isIpickUp:iPick,
							}
				},
		uniq:new Date().toString()
		};
		//add To cart and delete from wishlist
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		addToCartRequest(request).then(addToCartResponse);
	}
	function addToCartRequest(request){
		return myCartService.addProductDetailsToCart(request);
	}
	function addToCartResponse(response){
		var res=response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
		item_actions.productAlreadyExist=false;
		if(res.applicationStatusCode===1014){
			//delete product from wishlist and increment count of cart
			vm.deleteItemFromWl(item_actions);
			setCartCounter(item_actions.productId);
			item_actions=null;
			  //vm.addtocardttbn=true;
		}
		else if(res.applicationStatusCode===2029){
			var  errorCodes= res.errorCodes;
			for(var i=0,len=errorCodes.length;i<len;i++){
				if(errorCodes[i].errcode===2029){
					item_actions.productAlreadyExist=true;
				}else if(errorCodes[i].errcode===2030){
					item_actions.productAlreadyExist=true;
				}else if(errorCodes[i].errcode===2041){
					item_actions.productAlreadyExist=true;
				}
			}
		}
		item_actions=null;
	}
	function setCartCounter(id){
    	var prdLen = loginService.getUserInfo().productsIDS;
    	prdLen.push(id);
		angular.element('#cartcounterlist').text(prdLen.length);
 }
}]);

});
