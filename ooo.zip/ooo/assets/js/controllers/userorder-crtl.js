'use strict';

define(['angular',
        'controllers-module',
		'underscore'
        ], function(angular, controllers, underscore) {  

		// Add Attribute Controller
controllers.controller("userOrdersCtrl", ['$rootScope','$scope','$state','userOrdersService','utilityService','loginService','stateService','$timeout','$window',
                                         function($rootScope,$scope,$state,userOrdersService,utilityService,loginService,stateService,$timeout,$window) {
	

	
	var vm=this;
	var active_orders,orders_requested,history_orders;
	vm.userInfo = loginService.getUserInfo();
	var userName= vm.userInfo.userName; //stateService.get(constants.STATE_USER_NAME);
	vm.ordersNotFound=false;
	
	vm.orderresponse1;
	vm.address1;
	vm.order;
	vm.orderResponse2;
	vm.both=false;
	vm.shipAddress;
	vm.storeAddress;
	vm.ship=false;
	vm.store=false;
	 vm.parmentAdddress = vm.userInfo.parmentAdddress;
	$scope.gridOptions = {  	
		 enableColumnMenu: false,
		 paginationPageSizes: [5, 10, 15,20],
         paginationPageSize: 10,
		  enableFiltering: true,	
		  useExternalFiltering: true,
		  onRegisterApi: function(gridApi){
	             $scope.gridApi = gridApi;
	             $scope.gridApi.core.on.filterChanged($scope, function() {
	               $timeout(function() {
	                  var tempArray = [],
	                  	  grid = $scope.gridApi.grid; 
	                  var search_key_col1 = grid.columns[0].filters[0].term,
	                  	  search_key_col2 = grid.columns[1].filters[0].term;
	                  if((search_key_col1!=null && search_key_col1!=undefined) || (search_key_col2!=null && search_key_col2!=undefined) ){
	                         vm.tempArray = [];
	                         var noOfRows=vm.orders_requested.length; 
	                         for(var order=0;order<noOfRows;order++){
	                                var current_order=[],
	                                	filterCol2 = (search_key_col2 != null && search_key_col2 != undefined ),
	                                	filterCol1 = (search_key_col1 != null && search_key_col1 != undefined );
                                	if(filterCol2) {
                                		if(vm.orders_requested[order].orderId.indexOf(search_key_col2) > -1) {
                                			vm.tempArray.push(vm.orders_requested[order]);
    	                                	current_order = vm.orders_requested[order].userOrderDetailsDTO;                                			
                                		}
	                                } else {
	                                	current_order = vm.orders_requested[order].userOrderDetailsDTO;
	                                }
                                	
	                                if( filterCol1 ) {
	                                	for(var co_product=0;co_product<current_order.length;co_product++){
		                                       var prod_contains=current_order[co_product].productTable.productName.toLowerCase().indexOf(search_key_col1.toLowerCase());
		                                       if(prod_contains>-1){
		                                              if(vm.tempArray.length>0){
		                                                     if(vm.tempArray[vm.tempArray.length-1].orderId!=vm.orders_requested[order].orderId){
		                                                        vm.tempArray.push(vm.orders_requested[order]);
		                                                     }
		                                              }else{
		                                                  vm.tempArray.push(vm.orders_requested[order]);
		                                              }
		                                       }
		                                }
	                                } 
	                         }
	                         $scope.gridOptions.data = vm.tempArray;
	                  }else{
	                         $scope.gridOptions.data=vm.orders_requested;
	                  }
	             })//onfilter
	             }, 2000);
	            },

		 columnDefs: [ 
		  /*{ field: 'userOrderDetailsDTO',displayName:'origo.wishlist.products', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: false, enableSorting: false, width:'10%',enableFiltering:false,
			  cellTemplate: "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD' data-toggle='tooltip' title='{{field.productTable.productName}}'><img  width=\"80px\"  height=\"80px\" ng-src\='{{field.productTable.productImgPath}}\' lazy-src/></div></div>" },*/	
		 { field: 'userOrderDetailsDTO', displayName:'origo.submitdemand.prodName', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableSorting: true, enableHiding: false , width:'20%',enableFiltering: true,
			 cellTemplate: "<div class='ui-grid-cell-contents'><div ng-repeat='field in COL_FIELD' data-toggle='tooltip' title='{{field.productTable.productName}}'>{{field.productTable.productName}}</div></div>" },	
	      { field: 'orderId',  displayName:'origo.orders.orderNumber', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableHiding: false ,enableSorting: true,width:'15%',enableFiltering: true},	
	      { field: 'orderStatus',  displayName:'origo.wallet.status', headerCellFilter:'translate', enableCellEdit:false, enableColumnMenu: true, enableHiding: false , enableSorting: true,width:'15%',enableFiltering:false},
	      { field: 'orderDate',  displayName:'origo.orders.orderDate', headerCellFilter:'translate', enableCellEdit:false, enableColumnMenu: true, enableHiding: false , enableSorting: true,width:'15%',enableFiltering: false,sort: { direction: 'desc', priority: 0 }},	     
	      { field: 'amountTotal', displayName:'origo.orders.total', headerCellFilter:'translate', type:'number', enableCellEdit: false, enableColumnMenu: true, enableHiding: false , enableSorting: true,width:'10%',enableFiltering:false},
	      { field: 'tpaymentMode.paymentDesc', displayName:'origo.order.payment.mode', headerCellFilter:'translate', enableCellEdit: false, enableColumnMenu: true, enableHiding: false , enableSorting: true, width:'15%',enableFiltering:false},
			{ field: 'actions', displayName:'origo.demand.actions', headerCellFilter:'translate',enableCellEdit:false, enableColumnMenu: false, enableHiding: false , enableSorting: false,width:'10%',enableFiltering:false,
			     cellTemplate: 
			     		'<a class="ui-grid-cell-contents" data-toggle="modal" data-target="#viewOrders" ng-click="grid.appScope.vm.viewOrder(row.entity)">View</a>' }
	     
	  ]
	  };
		vm.viewOrder = function(order){
			vm.ship=false;
			vm.store=false;
		vm.order= order;
		vm.deliveryBoth = false;
		vm.orderresponse=vm.order;
		if(vm.order.shippingAddress!=null){
			vm.shipAddress = vm.order.shippingAddress.address;
			vm.ship=true;
		}
		
		//console.log(order);
		for(var i =0;i<vm.order.userOrderDetailsDTO.length;i++){
			/*if(vm.order.shippingAddress!=null){
				vm.shipAddress =vm.order.shippingAddress;
				vm.address = vm.order.shippingAddress.address;
				vm.ship=true;
			}*/
			if(vm.order.userOrderDetailsDTO[i].productTable.storeLocatorDTO!=null && vm.order.userOrderDetailsDTO[i].deliveryType!='SHIPPING'){
				
				vm.storeAddress = vm.order.userOrderDetailsDTO[i].productTable.storeLocatorDTO;
				vm.store=true;
			}
			
		}
		 var ipickup = false,shipping=false;
		vm.product = vm.order.userOrderDetailsDTO;
		for(var _prod=0,_prodLen=vm.product.length;_prod<_prodLen;_prod++){
			var deliveryType = vm.product[_prod].deliveryType;
			if(deliveryType==="SHIPPING"){
				   shipping=true;
				   vm.shippingaddress = vm.order.shippingAddress.address;
				   vm.billTo = vm.billToAddress = vm.address = vm.order.shippingAddress.address;
			}else{
				 vm.locatorDTOItem = true;
				   ipickup=true;
				   var _address = vm.product[_prod].locatorDTO;
				   vm.billTo = vm.userInfo.parmentAdddress;
				   if(vm.ipickupAddress==null){
					    vm.ipickupAddress = {};
					    vm.address={};
					     vm.ipickupAddress.name = vm.address.name =_address.name;
					     vm.ipickupAddress.address = vm.address.address =_address.address;
					    //vm.address.landmark = 
					    vm.ipickupAddress.district = vm.address.district = _address.district;
					    vm.ipickupAddress.state = vm.address.state = _address.state;
					    vm.ipickupAddress.country =  vm.address.country = "INDIA";
					    vm.ipickupAddress.pinCode =  vm.address.pinCode = _address.pincode;
					    vm.ipickupAddress.wd_open_time = vm.address.wd_open_time = _address.wd_open_time;
					    vm.ipickupAddress.wd_close_time= vm.address.wd_close_time=_address.wd_close_time;
					    vm.ipickupAddress.we_open_time = vm.address.we_open_time =_address.we_open_time;
					    vm.ipickupAddress.we_close_time = vm.address.we_close_time =_address.we_close_time;
				   }
			}
		   
		}
		
		if(shipping && ipickup){
			vm.deliveryBoth = !vm.deliveryBoth;
			vm.address = vm.billToAddress;
		
		}
	}
	vm.showActiveOrders=function(){
		vm.orders_requested=null;
		//$scope.loading=true;
		vm.ordersNotFound=false;
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		//on load of page give a call and initialize array of objects and iterate over it to show active orders
		var loginDetails={loginName:userName,ordertype:"Active"};
		callGetActiveOrders(loginDetails).then(processGetActiveOrdersResponse);
		angular.element("#activeOrder").addClass("order_active_heading");	
		angular.element("#historyOrders").removeClass("order_active_heading");	
	}
	function callGetActiveOrders(loginDetails){
		return userOrdersService.getActiveOrders(loginDetails);
	}
	function processGetActiveOrdersResponse(response){
		var res = response.body;
		
	    	if(res.applicationStatusCode==2048){
	    		vm.ordersNotFound=false;
	    		var products= res.data;
	    		for(var prod=0;prod<products.length;prod++){
					products.actions;
				}
	    		
	    		for(var prod=0;prod<products.length;prod++){
	    			var prodItem=products[prod].userOrderDetailsDTO;
	    		for(var img=0,_imgLen=prodItem.length;img<_imgLen;img++){
	    			prodItem[img].productTable.productImgPath = connection.store+"images/"+prodItem[img].productTable.productImgPath;
	    		}
	    		}
	    		vm.orders_requested=products;
	    		 $scope.gridOptions.data = vm.orders_requested;
	    			$timeout(function() {
	    	    		$(window).resize();
	    	    		}, 100);
	    		//$scope.loading=false;
	    			$rootScope.dataLoading = false;
	    			$rootScope.dataStillLoading = false;
	    	}
	    	if(res.applicationStatusCode==2049){
	    		vm.ordersNotFound=true;
	    		//$scope.loading=false;
	    		$rootScope.dataLoading = false;
	    		$rootScope.dataStillLoading = false;
	    	}
	}
	function init(){
	vm.type_order='Active';
	vm.showActiveOrders();
	}
	init();
	vm.goToHomePage=function(){
		$state.go('start');	
	}	
	vm.showHistoryOrders=function(){
		//$scope.loading=true;
		vm.orders_requested=null;
		vm.ordersNotFound=false;
		var histDetails={loginName:userName,ordertype:"History"};
		$rootScope.dataLoading = true;
		$rootScope.dataStillLoading = true;
		callGetHistoryOrders(histDetails).then(processGetHistoryOrdersResponse);
		angular.element("#activeOrder").removeClass("order_active_heading");
		angular.element("#historyOrders").addClass("order_active_heading");	
	}
	function callGetHistoryOrders(histDetails){
		return userOrdersService.getHistoryOrders(histDetails);
	}
	function processGetHistoryOrdersResponse(response){
		var res = response.body;
		$rootScope.dataLoading = false;
		$rootScope.dataStillLoading = false;
    	if(res.applicationStatusCode==2048){
    		vm.ordersNotFound=false;
    		vm.orders_requested=res.data;
    		$scope.gridOptions.data = vm.orders_requested;
    		$timeout(function() {
    		$(window).resize();
    		}, 600);
    		//$scope.loading=false;
    	}
    	if(res.applicationStatusCode==2049){
	    		vm.ordersNotFound=true;
	    		//$scope.loading=false;
    	}
	}
	vm.downloadInvoice= function(){
		//console.log("download");
		angular.element("#table_div").css("height","100%");
		$rootScope.dataLoading = true;
		 var pdf = new jsPDF();

		    var specialElementHandlers = {
		    '#table_div': function (element, renderer) {
		        return true;
		        }
		    };

		    pdf.addHTML($('#table_div').get(0), function() {
		    	var filename = 'invoice_'+vm.order.orderId+'.pdf';
		        pdf.save(filename);
		    });
		    
		    $timeout(function() {
		    	angular.element("#table_div").css("height","0px");
		    	$rootScope.dataLoading = false;
		    }, 200);
	}
	
	vm.filteredOrders=function(){
		 var orders_searched=[];
		if(vm.search_value!=""){			
	 		for(var i=0;i<vm.orders_requested.length;i++){
	 			var pid=vm.orders_requested[i].orderId.indexOf(vm.search_value);
	 			//var udDTO=vm.orders_requested[i].userOrderDetailsDTO;
	 			/*for(var j=0;j<udDTO.length;j++){
	 				pname=vm.udDTO[j].productName.toLowerCase().indexOf(vm.search_value.toLowerCase());
	 			}*/
	 			//var pname=$scope.active_orders[i].productName.toLowerCase().indexOf($scope.search_value.toLowerCase());

	 			//var pid=$scope.active_orders[i].order_id.toLowerCase().indexOf($scope.search_value.toLowerCase());
	 			//var pname=vm.orders_requested[i].userOrderDetailsDTO[0].productName.toLowerCase().indexOf(vm.search_value.toLowerCase());

	 		//if((pname>-1)||(pid>-1)){
	 			if(pid>-1){
	 		orders_searched.push($scope.active_orders[i]);
	 		}
	 		}
	 		//vm.orders_requested=orders_searched;
	 		
		}else{
			//vm.orders_requested=vm.orders_requested;
		}

	}

	vm.convert = function(i){
        var i = parseInt(i);
        var units =["","One","Two","Three","Four",
               "Five","Six","Seven","Eight","Nine","Ten",
               "Eleven","Twelve","Thirteen","Fourteen","Fifteen",
               "Sixteen","Seventeen","Eighteen","Nineteen"];
        var tens = ["","","Twenty","Thirty","Forty","Fifty",
               "Sixty","Seventy","Eighty","Ninety"];
		if( i < 20)  return units[i];
		if( i < 100) return tens[parseInt(i/10)] + ((i % 10 > 0)? " " + vm.convert(i % 10):"");
		if( i < 1000) return units[parseInt(i/100)] + " Hundred " + ((i % 100 > 0)?"  " + vm.convert(i % 100):"");
		if( i < 10000) return units[parseInt(i/1000)] + " Thousand" + ((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
		if(i >10000&&i<20000) return units[parseInt(i/1000)] +" Thousand " +((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
		if(i<100000) return tens[parseInt(i/10000)]+" "+units[parseInt((i/1000)%10)] +"Thousand" +((i % 1000 > 0)?" " + vm.convert(i % 1000):"");
		if(i<2000000) return units[parseInt(i/100000)]+" Lakh "+vm.convert(i%100000);
		if(i<10000000) return tens[parseInt(i/1000000)]+" "+ units[parseInt((i/100000)%10)]+" Lakh "+vm.convert(i%100000);
        
 }


	vm.convertToNumberName = function(){
		var rupees;
		var paise;
		var i= vm.orderresponse.amountTotal + (vm.orderresponse.amountTotal *0.05);
		console.log("Rupeee"+i);
			i = Math.round(i*100)/100;
		var number = (i.toString()).split('.');
		console.log(number);
		rupees = vm.convert(parseInt(number[0]));
		if(number.length>1){
		paise = vm.convert(parseInt(number[1]));
		rupees= rupees + ' rupees and ' + paise +'  paise only.' ;
		}
		return rupees+'/-';
		 
	}
	vm.exportToExcel = function(){
	var gridRows = $scope.gridApi.grid.rows;
	var ordersTable ="<tr><th  style='background-color:yellow'>Product name</th> <th style='background-color:yellow'>Order Number </th> <th style='background-color:yellow'>Status</th> <th style='background-color:yellow'>Order Date </th> <th style='background-color:yellow'>Total </th> <th style='background-color:yellow'>Payment Mode</th></tr>";
	for(var i =0 ;i<gridRows.length;i++){
		var entity = gridRows[i].entity;
		ordersTable+="<tr>";
		ordersTable+="<td>"
		for(var j=0;j<entity.userOrderDetailsDTO.length;j++){
			var productName = entity.userOrderDetailsDTO[j].productTable.productName;
			ordersTable+=productName;
			if(entity.userOrderDetailsDTO.length>1){
				ordersTable+=", ";
			}
		}
		ordersTable+="</td>"
		ordersTable+="<td>"+entity.orderId+ "</td>";
		ordersTable+="<td>"+entity.orderStatus+"</td>";
		ordersTable+="<td>" +entity.orderDate +"</td>";
		ordersTable+="<td> Rs. " + entity.amountTotal +"</td>";
		ordersTable+="<td>"+entity.tpaymentMode.paymentDesc+"</td>";
		ordersTable+="</tr>"
	}
	var uri = 'data:application/vnd.ms-excel;base64,', 
		template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>', 
		base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }, 
		format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
    var ctx = {worksheet: 'Order Details' || 'Worksheet', table: ordersTable};
    $window.open(uri+base64(format(template,ctx)));
}
}
]);
});